-- ============================================================
-- CWCSM - Schema additions #5
-- Run this in phpMyAdmin on wine_cellar_management.
-- (Supersedes schema_additions_3.sql — same columns, but safe
-- to re-run since it uses IF NOT EXISTS.)
--
-- Adds:
--   1. wine_varietals.image_path  - picture upload for varietals
--   2. created_at timestamps on the modules shown in the
--      dashboard's "Recent Updates" table
-- ============================================================

USE `wine_cellar_management`;

ALTER TABLE `wine_varietals`
  ADD COLUMN IF NOT EXISTS `image_path` VARCHAR(255) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP;

ALTER TABLE `cellar_inventory`
  ADD COLUMN IF NOT EXISTS `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP;

ALTER TABLE `tasting_notes`
  ADD COLUMN IF NOT EXISTS `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP;

ALTER TABLE `vineyards`
  ADD COLUMN IF NOT EXISTS `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP;

ALTER TABLE `supplier`
  ADD COLUMN IF NOT EXISTS `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP;

ALTER TABLE `certifications`
  ADD COLUMN IF NOT EXISTS `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP;

ALTER TABLE `sommelier_certifications`
  ADD COLUMN IF NOT EXISTS `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP;

ALTER TABLE `account`
  ADD COLUMN IF NOT EXISTS `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP;
