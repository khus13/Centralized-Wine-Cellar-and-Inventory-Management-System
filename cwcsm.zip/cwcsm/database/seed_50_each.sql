-- ============================================================
-- CWCSM - Seed data: 50 of each entity
-- Run AFTER all schema files. Password for all seeded accounts: Test@1234
-- ============================================================
USE `wine_cellar_management`;

-- Additional regions for vineyard variety
INSERT IGNORE INTO `regions` (`region_name`, `country`) VALUES
('Champagne', 'France'), ('Burgundy', 'France'), ('Loire Valley', 'France'),
('Piedmont', 'Italy'), ('Veneto', 'Italy'), ('Sicily', 'Italy'),
('Sonoma Valley', 'United States'), ('Willamette Valley', 'United States'), ('Finger Lakes', 'United States'),
('Margaret River', 'Australia'), ('Hunter Valley', 'Australia'), ('Yarra Valley', 'Australia'),
('Marlborough', 'New Zealand'), ('Hawke''s Bay', 'New Zealand'),
('Stellenbosch', 'South Africa'), ('Franschhoek', 'South Africa'),
('Douro Valley', 'Portugal'), ('Alentejo', 'Portugal'),
('Mosel', 'Germany'), ('Rheingau', 'Germany'),
('Maipo Valley', 'Chile'), ('Casablanca Valley', 'Chile'),
('Cafayate', 'Argentina'), ('Uco Valley', 'Argentina');

-- Additional varietals
INSERT IGNORE INTO `wine_varietals` (`varietal_name`, `color_type`, `min_typical_aging_yrs`, `max_typical_aging_yrs`, `food_pairing_template`, `entry_temperature_celsius`) VALUES
('Riesling', 'White', 2, 12, 'Asian cuisine, pork, spicy dishes', 8.0),
('Tempranillo', 'Red', 3, 15, 'Lamb, chorizo, Manchego cheese', 16.0),
('Nebbiolo', 'Red', 5, 20, 'Truffle dishes, braised meats, aged Parmesan', 17.5),
('Sangiovese', 'Red', 3, 12, 'Pasta, pizza, tomato sauces, grilled meats', 16.5),
('Grüner Veltliner', 'White', 1, 5, 'Schnitzel, white asparagus, fresh salads', 9.5),
('Grenache', 'Red', 2, 8, 'Roasted vegetables, lamb stew, Mediterranean dishes', 15.0),
('Viognier', 'White', 1, 4, 'Lobster, foie gras, apricot tart', 11.0),
('Zinfandel', 'Red', 2, 8, 'BBQ, pizza, spicy sausage', 16.0),
('Chenin Blanc', 'White', 2, 10, 'Pork belly, Thai curry, fruit desserts', 10.0),
('Malbec', 'Red', 3, 10, 'Steak, empanadas, dark chocolate', 17.0),
('Gewürztraminer', 'White', 1, 5, 'Dim sum, Munster cheese, gingerbread', 10.0),
('Mourvèdre', 'Red', 4, 15, 'Game, wild boar, herb-crusted lamb', 17.0),
('Albariño', 'White', 1, 3, 'Seafood, ceviche, tapas', 8.5),
('Prosecco', 'Sparkling', 1, 2, 'Appetizers, brunch, fresh fruit', 6.0);

-- 50 Vineyards (across various regions)
INSERT INTO `vineyards` (`vineyard_name`, `region_id`, `established_year`, `contact_phone`, `is_active`) VALUES
('Château Margaux', 1, 1590, '+33 5 57 88 83 83', 1),
('Domaine de la Romanée-Conti', 8, 1760, '+33 3 80 62 48 80', 1),
('Penfolds Estate', 5, 1844, '+61 8 8301 5400', 1),
('Opus One Winery', 3, 1979, '+1 707 944 9442', 1),
('Bodega Catena Zapata', 6, 1902, '+54 261 413 1100', 1),
('Antinori nel Chianti Classico', 2, 1385, '+39 055 235 9700', 1),
('Cloudy Bay', 19, 1985, '+64 3 520 9140', 1),
('Torres Winery', 4, 1870, '+34 938 177 400', 1),
('Quinta do Noval', 23, 1715, '+351 254 730 430', 1),
('Dr. Loosen Estate', 25, 1805, '+49 6531 3426', 1),
('Klein Constantia', 21, 1685, '+27 21 794 5188', 1),
('Viña Montes', 27, 1988, '+56 72 281 7815', 1),
('Henschke Cellars', 5, 1868, '+61 8 8564 8223', 1),
('Silver Oak Cellars', 3, 1972, '+1 707 942 7082', 1),
('Château Lafite Rothschild', 1, 1234, '+33 5 56 73 18 18', 1),
('Marchesi di Barolo', 10, 1807, '+39 0173 564 400', 1),
('Villa Maria Estate', 20, 1961, '+64 9 255 0660', 1),
('Kanonkop Estate', 21, 1910, '+27 21 884 4656', 1),
('Domaine Zind-Humbrecht', 7, 1620, '+33 3 89 27 02 05', 1),
('Robert Mondavi Winery', 3, 1966, '+1 707 226 1395', 1),
('Gaja Winery', 10, 1859, '+39 0173 635 158', 1),
('Felton Road', 19, 1991, '+64 3 445 0885', 1),
('Vega Sicilia', 4, 1864, '+34 983 680 147', 1),
('Cape Point Vineyards', 22, 1996, '+27 21 789 0900', 1),
('Château Pétrus', 1, 1770, '+33 5 57 51 17 96', 1),
('Tyrrell''s Wines', 17, 1858, '+61 2 4993 7000', 1),
('Errazuriz Winery', 28, 1870, '+56 2 203 6688', 1),
('Trimbach Estate', 7, 1626, '+33 3 89 73 60 30', 1),
('Château Mouton Rothschild', 1, 1853, '+33 5 56 73 20 20', 1),
('Bodegas Muga', 4, 1932, '+34 941 311 825', 1),
('Leeuwin Estate', 16, 1974, '+61 8 9759 0000', 1),
('Concha y Toro', 27, 1883, '+56 2 476 5000', 1),
('Craggy Range', 20, 1997, '+64 6 873 7126', 1),
('Château Cheval Blanc', 1, 1832, '+33 5 57 55 55 55', 1),
('Brancott Estate', 19, 1976, '+64 3 520 6975', 1),
('Yalumba Winery', 5, 1849, '+61 8 8561 3200', 1),
('Sassicaia', 2, 1968, '+39 0565 762 003', 1),
('Bodega Norton', 6, 1895, '+54 261 490 9700', 1),
('Weingut Knoll', 26, 1825, '+43 2711 2355', 1),
('Ridge Vineyards', 3, 1962, '+1 408 867 3233', 1),
('Planeta Winery', 12, 1995, '+39 0925 80009', 1),
('Graham''s Port', 23, 1820, '+351 223 776 300', 1),
('Cullen Wines', 16, 1971, '+61 8 9755 5277', 1),
('Domaine Leflaive', 8, 1920, '+33 3 80 21 30 13', 1),
('Zuccardi Valle de Uco', 30, 2000, '+54 261 441 0000', 1),
('Schloss Johannisberg', 26, 817, '+49 6722 70090', 1),
('Te Mata Estate', 20, 1896, '+64 6 877 4399', 1),
('De Toren Winery', 21, 1994, '+27 21 881 3119', 1),
('Stag''s Leap Wine Cellars', 3, 1970, '+1 707 944 2020', 1),
('Dönnhoff Estate', 25, 1750, '+49 6751 2038', 1);

-- Password hash for Test@1234
SET @pwd = '$2y$10$YKHfK1h8zKHmQ8CfOj5lMONqGHfBbWqpx5J1CRXM.JQpQV2rE4Uy6';

-- 50 Sommelier accounts
DELIMITER //
DROP PROCEDURE IF EXISTS seed_sommeliers//
CREATE PROCEDURE seed_sommeliers()
BEGIN
  DECLARE i INT DEFAULT 1;
  DECLARE fnames VARCHAR(1000) DEFAULT 'Elena,Marco,Sofia,Luca,Isabella,Matteo,Giulia,Alessandro,Chiara,Francesco,Valentina,Andrea,Beatrice,Giovanni,Camilla,Lorenzo,Federica,Davide,Arianna,Stefano,Martina,Roberto,Eleonora,Simone,Aurora,Nicolò,Sara,Gabriele,Alice,Leonardo,Clara,Tommaso,Ginevra,Filippo,Viola,Riccardo,Greta,Edoardo,Bianca,Alberto,Marta,Pietro,Ludovica,Diego,Serena,Giacomo,Carolina,Emanuele,Diana,Daniele';
  DECLARE lnames VARCHAR(1000) DEFAULT 'Rossi,Bianchi,Moretti,Romano,Colombo,Ferrari,Esposito,Conti,De Luca,Mancini,Barbieri,Fontana,Santoro,Ricci,Marini,Gallo,Leone,Martinelli,Rinaldi,Caruso,Costa,Giordano,Parisi,Lombardi,Grasso,Ferrara,Pellegrini,Fabbri,Monti,Sala,Marchetti,Valentini,Orlando,Barone,Serra,Bruno,Longo,D''Angelo,Vitale,Amato,Battaglia,De Rosa,Neri,Bernardi,Palumbo,Messina,Russo,Gentile,Sartori,Marchese';
  DECLARE fname VARCHAR(50);
  DECLARE lname VARCHAR(50);
  DECLARE uname VARCHAR(50);
  DECLARE aid INT;
  WHILE i <= 50 DO
    SET fname = TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(fnames, ',', i), ',', -1));
    SET lname = TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(lnames, ',', i), ',', -1));
    SET uname = CONCAT(LOWER(fname), '.', LOWER(REPLACE(lname, ' ', '')), '.som');
    IF NOT EXISTS (SELECT 1 FROM account WHERE username = uname) THEN
      INSERT INTO account (first_name, last_name, username, password, email, phone_number)
      VALUES (fname, lname, uname, @pwd, CONCAT(uname, '@cwcsm.local'), CONCAT('+1-555-', LPAD(1000 + i, 4, '0')));
      SET aid = LAST_INSERT_ID();
      INSERT INTO sommelier (account_id, hire_date) VALUES (aid, DATE_SUB(CURDATE(), INTERVAL FLOOR(RAND() * 1800) DAY));
    END IF;
    SET i = i + 1;
  END WHILE;
END//
DELIMITER ;
CALL seed_sommeliers();
DROP PROCEDURE IF EXISTS seed_sommeliers;

-- 50 Cellar Manager accounts
DELIMITER //
DROP PROCEDURE IF EXISTS seed_managers//
CREATE PROCEDURE seed_managers()
BEGIN
  DECLARE i INT DEFAULT 1;
  DECLARE fnames VARCHAR(1000) DEFAULT 'Henri,Marie,Jean,Colette,Pierre,Yvette,Claude,Monique,Philippe,Simone,Jacques,Brigitte,René,Isabelle,Louis,Nathalie,Marcel,Sandrine,André,Valérie,Michel,Sylvie,Paul,Cécile,Thierry,Christine,Gérard,Hélène,Bernard,Corinne,Raymond,Catherine,Dominique,Odette,Yves,Mireille,Roger,Gisèle,Alain,Élise,Daniel,Fabienne,Éric,Joëlle,Serge,Solange,Patrick,Liliane,Francis,Marguerite';
  DECLARE lnames VARCHAR(1000) DEFAULT 'Dubois,Laurent,Moreau,Lefèvre,Simon,Michel,Garcia,David,Bertrand,Thomas,Robert,Richard,Petit,Durand,Leroy,Roux,Vincent,Fournier,Morel,Girard,André,Mercier,Dupont,Lambert,Bonnet,Faure,Blanc,Guérin,Muller,Henry,Rousseau,Nicolas,Perrin,Robin,Morin,Mathieu,Clément,Gauthier,Chevalier,Duval,Lemaire,Renard,Picard,Lacroix,Caron,Arnaud,Giraud,Bailly,Masson,Deschamps';
  DECLARE fname VARCHAR(50);
  DECLARE lname VARCHAR(50);
  DECLARE uname VARCHAR(50);
  DECLARE aid INT;
  WHILE i <= 50 DO
    SET fname = TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(fnames, ',', i), ',', -1));
    SET lname = TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(lnames, ',', i), ',', -1));
    SET uname = CONCAT(LOWER(fname), '.', LOWER(REPLACE(lname, ' ', '')), '.mgr');
    IF NOT EXISTS (SELECT 1 FROM account WHERE username = uname) THEN
      INSERT INTO account (first_name, last_name, username, password, email, phone_number)
      VALUES (fname, lname, uname, @pwd, CONCAT(uname, '@cwcsm.local'), CONCAT('+1-555-', LPAD(2000 + i, 4, '0')));
      SET aid = LAST_INSERT_ID();
      INSERT INTO cellar_manager (account_id, hire_date) VALUES (aid, DATE_SUB(CURDATE(), INTERVAL FLOOR(RAND() * 1800) DAY));
    END IF;
    SET i = i + 1;
  END WHILE;
END//
DELIMITER ;
CALL seed_managers();
DROP PROCEDURE IF EXISTS seed_managers;

-- 50 Suppliers (distributed across vineyards and varietals)
DELIMITER //
DROP PROCEDURE IF EXISTS seed_suppliers//
CREATE PROCEDURE seed_suppliers()
BEGIN
  DECLARE i INT DEFAULT 1;
  DECLARE vcount INT;
  DECLARE varcount INT;
  DECLARE vid INT;
  DECLARE varid INT;
  DECLARE cname VARCHAR(100);
  DECLARE contact_names VARCHAR(2000) DEFAULT 'Antonio Ferreira,Sophie Blanc,Hans Weber,Carlos Mendez,Yuki Tanaka,Maria Gutierrez,James Worthington,Anke Schmidt,Liam O''Sullivan,Fatima Alves,Pietro Marchetti,Ingrid Larsen,Raj Patel,Emilia Nowak,Chen Wei,Rosa Santiago,Thomas Keller,Anika van der Berg,David Chambers,Luisa Reyes,Sven Nilsson,Priya Sharma,Miguel Torres,Eva Lindström,Omar Hassan,Beatriz Campos,Nils Andersen,Sakura Morimoto,Giuseppe Ferro,Helga Braun,Javier Ortega,Aisha Khan,Viktor Petrović,Camille Moreau,Kofi Mensah,Iris van Dijk,Rui Costa,Svetlana Ivanova,Jean-Luc Picard,Amara Diallo,Kenji Yamamoto,Frida Gustafsson,Tomás Silva,Leila Abbasi,Wolfgang Müller,Constance Beaumont,Amir Nazari,Elina Korhonen,Mateo Salazar,Brigitte Fontaine';
  SELECT COUNT(*) INTO vcount FROM vineyards WHERE is_deleted = 0;
  SELECT COUNT(*) INTO varcount FROM wine_varietals WHERE is_deleted = 0;
  WHILE i <= 50 DO
    SET cname = TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(contact_names, ',', i), ',', -1));
    SELECT vineyard_id INTO vid FROM vineyards WHERE is_deleted = 0 ORDER BY RAND() LIMIT 1;
    SELECT varietal_id INTO varid FROM wine_varietals WHERE is_deleted = 0 ORDER BY RAND() LIMIT 1;
    INSERT INTO supplier (vineyard_id, varietal_id, supplier_contact_name, lead_time_days)
    VALUES (vid, varid, cname, 5 + FLOOR(RAND() * 45));
    SET i = i + 1;
  END WHILE;
END//
DELIMITER ;
CALL seed_suppliers();
DROP PROCEDURE IF EXISTS seed_suppliers;

SELECT 'Seeding complete: 50 sommeliers, 50 cellar managers, 50 vineyards, 50 suppliers' AS status;
