-- ============================================================
-- CWCSM - Schema additions
-- Run this AFTER cwcsm_schema.sql. Adds the one column the
-- original schema was missing: a bottle image for the Wine
-- Cellar module's image-upload requirement.
-- ============================================================

USE `wine_cellar_management`;

ALTER TABLE `cellar_inventory`
  ADD COLUMN `image_path` VARCHAR(255) DEFAULT NULL AFTER `last_inventory_check_date`;
