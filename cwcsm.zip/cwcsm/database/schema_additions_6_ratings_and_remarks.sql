-- ============================================================
-- CWCSM - Schema additions #6
-- Run this in phpMyAdmin on wine_cellar_management AFTER the
-- earlier schema_additions files. Safe to re-run (uses IF NOT
-- EXISTS on MariaDB / XAMPP).
--
-- Adds:
--   1. tasting_notes.remarks - free-text field where a Sommelier
--      can record the reasoning behind their review.
--   2. wine_ratings - a Sommelier's overall rating (1-5) + written
--      report for a specific bottle. One row per (bottle, sommelier);
--      editing simply updates that row.
--   3. supplier_ratings - a Cellar Manager's rating (1-5) + report
--      for a supplier. One row per (supplier, manager).
-- ============================================================

USE `wine_cellar_management`;

-- 1. Tasting note remarks -------------------------------------
ALTER TABLE `tasting_notes`
  ADD COLUMN IF NOT EXISTS `remarks` TEXT DEFAULT NULL AFTER `flavor_notes`;

-- 2. Wine ratings / reports (by Sommeliers) -------------------
CREATE TABLE IF NOT EXISTS `wine_ratings` (
  `wine_rating_id` int(11) NOT NULL AUTO_INCREMENT,
  `bottle_id` int(11) NOT NULL,
  `sommelier_id` int(11) NOT NULL,
  `rating` int(11) NOT NULL,
  `report` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`wine_rating_id`),
  UNIQUE KEY `uq_wine_rating` (`bottle_id`, `sommelier_id`),
  KEY `wr_bottle` (`bottle_id`),
  KEY `wr_sommelier` (`sommelier_id`),
  CONSTRAINT `wine_ratings_ibfk_1` FOREIGN KEY (`bottle_id`) REFERENCES `cellar_inventory` (`bottle_id`) ON DELETE CASCADE,
  CONSTRAINT `wine_ratings_ibfk_2` FOREIGN KEY (`sommelier_id`) REFERENCES `sommelier` (`sommelier_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- 3. Supplier ratings / reports (by Cellar Managers) ----------
CREATE TABLE IF NOT EXISTS `supplier_ratings` (
  `supplier_rating_id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_id` int(11) NOT NULL,
  `manager_id` int(11) NOT NULL,
  `rating` int(11) NOT NULL,
  `report` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`supplier_rating_id`),
  UNIQUE KEY `uq_supplier_rating` (`supplier_id`, `manager_id`),
  KEY `sr_supplier` (`supplier_id`),
  KEY `sr_manager` (`manager_id`),
  CONSTRAINT `supplier_ratings_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `supplier` (`supplier_id`) ON DELETE CASCADE,
  CONSTRAINT `supplier_ratings_ibfk_2` FOREIGN KEY (`manager_id`) REFERENCES `cellar_manager` (`manager_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
