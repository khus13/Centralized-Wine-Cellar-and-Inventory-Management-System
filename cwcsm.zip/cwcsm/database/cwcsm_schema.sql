-- ============================================================
-- CWCSM - Centralized Wine Cellar & Sommelier Management System
-- Full schema (based on wine_cellar_management.sql) + additions
-- Import this single file in phpMyAdmin / MySQL. It creates the
-- database, all tables, keys, and seeds the Admin account.
-- ============================================================

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

CREATE DATABASE IF NOT EXISTS `wine_cellar_management` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `wine_cellar_management`;

-- ------------------------------------------------------------
-- account
-- ------------------------------------------------------------
CREATE TABLE `account` (
  `account_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone_number` varchar(20) NOT NULL,
  PRIMARY KEY (`account_id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ------------------------------------------------------------
-- admin  (Admin accounts are seeded directly in the DB, no public registration)
-- ------------------------------------------------------------
CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `account_id` int(11) NOT NULL,
  PRIMARY KEY (`admin_id`),
  UNIQUE KEY `account_id` (`account_id`),
  CONSTRAINT `admin_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `account` (`account_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ------------------------------------------------------------
-- regions
-- ------------------------------------------------------------
CREATE TABLE `regions` (
  `region_id` int(11) NOT NULL AUTO_INCREMENT,
  `region_name` varchar(100) NOT NULL,
  `country` varchar(100) NOT NULL,
  PRIMARY KEY (`region_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ------------------------------------------------------------
-- vineyards  (+ image_path for Admin-uploaded photo)
-- ------------------------------------------------------------
CREATE TABLE `vineyards` (
  `vineyard_id` int(11) NOT NULL AUTO_INCREMENT,
  `vineyard_name` varchar(100) NOT NULL,
  `region_id` int(11) NOT NULL,
  `established_year` int(11) NOT NULL,
  `contact_phone` varchar(20) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `image_path` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`vineyard_id`),
  KEY `region_id` (`region_id`),
  CONSTRAINT `vineyards_ibfk_1` FOREIGN KEY (`region_id`) REFERENCES `regions` (`region_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ------------------------------------------------------------
-- wine_varietals
-- ------------------------------------------------------------
CREATE TABLE `wine_varietals` (
  `varietal_id` int(11) NOT NULL AUTO_INCREMENT,
  `varietal_name` varchar(100) NOT NULL,
  `color_type` varchar(30) NOT NULL,
  `min_typical_aging_yrs` int(11) NOT NULL,
  `max_typical_aging_yrs` int(11) NOT NULL,
  `food_pairing_template` text NOT NULL,
  `entry_temperature_celsius` decimal(4,1) NOT NULL,
  PRIMARY KEY (`varietal_id`),
  UNIQUE KEY `varietal_name` (`varietal_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ------------------------------------------------------------
-- supplier
-- ------------------------------------------------------------
CREATE TABLE `supplier` (
  `supplier_id` int(11) NOT NULL AUTO_INCREMENT,
  `vineyard_id` int(11) NOT NULL,
  `varietal_id` int(11) NOT NULL,
  `supplier_contact_name` varchar(100) NOT NULL,
  `lead_time_days` int(11) NOT NULL,
  PRIMARY KEY (`supplier_id`),
  KEY `vineyard_id` (`vineyard_id`),
  KEY `varietal_id` (`varietal_id`),
  CONSTRAINT `supplier_ibfk_1` FOREIGN KEY (`vineyard_id`) REFERENCES `vineyards` (`vineyard_id`),
  CONSTRAINT `supplier_ibfk_2` FOREIGN KEY (`varietal_id`) REFERENCES `wine_varietals` (`varietal_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ------------------------------------------------------------
-- cellar_manager
-- ------------------------------------------------------------
CREATE TABLE `cellar_manager` (
  `manager_id` int(11) NOT NULL AUTO_INCREMENT,
  `account_id` int(11) NOT NULL,
  `hire_date` date NOT NULL,
  PRIMARY KEY (`manager_id`),
  UNIQUE KEY `account_id` (`account_id`),
  CONSTRAINT `cellar_manager_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `account` (`account_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ------------------------------------------------------------
-- cellar_inventory
-- ------------------------------------------------------------
CREATE TABLE `cellar_inventory` (
  `bottle_id` int(11) NOT NULL AUTO_INCREMENT,
  `vineyard_id` int(11) NOT NULL,
  `varietal_id` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `manager_id` int(11) NOT NULL,
  `vintage_year` int(11) NOT NULL,
  `storage_bin_number` varchar(20) NOT NULL,
  `purchase_date` date NOT NULL,
  `purchase_price` decimal(10,2) NOT NULL,
  `inventory_status` varchar(30) NOT NULL,
  `last_inventory_check_date` date NOT NULL,
  PRIMARY KEY (`bottle_id`),
  KEY `vineyard_id` (`vineyard_id`),
  KEY `varietal_id` (`varietal_id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `manager_id` (`manager_id`),
  CONSTRAINT `cellar_inventory_ibfk_1` FOREIGN KEY (`vineyard_id`) REFERENCES `vineyards` (`vineyard_id`),
  CONSTRAINT `cellar_inventory_ibfk_2` FOREIGN KEY (`varietal_id`) REFERENCES `wine_varietals` (`varietal_id`),
  CONSTRAINT `cellar_inventory_ibfk_3` FOREIGN KEY (`supplier_id`) REFERENCES `supplier` (`supplier_id`),
  CONSTRAINT `cellar_inventory_ibfk_4` FOREIGN KEY (`manager_id`) REFERENCES `cellar_manager` (`manager_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ------------------------------------------------------------
-- sommelier  (+ photo_path for self-uploaded profile photo)
-- ------------------------------------------------------------
CREATE TABLE `sommelier` (
  `sommelier_id` int(11) NOT NULL AUTO_INCREMENT,
  `account_id` int(11) NOT NULL,
  `hire_date` date NOT NULL,
  `photo_path` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`sommelier_id`),
  UNIQUE KEY `account_id` (`account_id`),
  CONSTRAINT `sommelier_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `account` (`account_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ------------------------------------------------------------
-- certifications
-- ------------------------------------------------------------
CREATE TABLE `certifications` (
  `certification_id` int(11) NOT NULL AUTO_INCREMENT,
  `certification_name` varchar(100) NOT NULL,
  `issuing_body` varchar(100) NOT NULL,
  PRIMARY KEY (`certification_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ------------------------------------------------------------
-- sommelier_certifications  (+ certificate_file_path for uploaded PDF)
-- ------------------------------------------------------------
CREATE TABLE `sommelier_certifications` (
  `sommelier_certification_id` int(11) NOT NULL AUTO_INCREMENT,
  `sommelier_id` int(11) NOT NULL,
  `certification_id` int(11) NOT NULL,
  `date_issued` date NOT NULL,
  `expiration_date` date DEFAULT NULL,
  `certificate_file_path` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`sommelier_certification_id`),
  KEY `sommelier_id` (`sommelier_id`),
  KEY `certification_id` (`certification_id`),
  CONSTRAINT `sommelier_certifications_ibfk_1` FOREIGN KEY (`sommelier_id`) REFERENCES `sommelier` (`sommelier_id`) ON DELETE CASCADE,
  CONSTRAINT `sommelier_certifications_ibfk_2` FOREIGN KEY (`certification_id`) REFERENCES `certifications` (`certification_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ------------------------------------------------------------
-- tasting_notes
-- ------------------------------------------------------------
CREATE TABLE `tasting_notes` (
  `note_id` int(11) NOT NULL AUTO_INCREMENT,
  `bottle_id` int(11) NOT NULL,
  `sommelier_id` int(11) NOT NULL,
  `tasting_date` date NOT NULL,
  `aroma_notes` text NOT NULL,
  `flavor_notes` text NOT NULL,
  `body_rating` int(11) NOT NULL,
  `acidity_rating` int(11) NOT NULL,
  `tannin_rating` int(11) NOT NULL,
  `peak_drinking_start_year` int(11) NOT NULL,
  `peak_drinking_end_year` int(11) NOT NULL,
  PRIMARY KEY (`note_id`),
  KEY `bottle_id` (`bottle_id`),
  KEY `sommelier_id` (`sommelier_id`),
  CONSTRAINT `tasting_notes_ibfk_1` FOREIGN KEY (`bottle_id`) REFERENCES `cellar_inventory` (`bottle_id`) ON DELETE CASCADE,
  CONSTRAINT `tasting_notes_ibfk_2` FOREIGN KEY (`sommelier_id`) REFERENCES `sommelier` (`sommelier_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ------------------------------------------------------------
-- login_log
-- ------------------------------------------------------------
CREATE TABLE `login_log` (
  `login_id` int(11) NOT NULL AUTO_INCREMENT,
  `account_id` int(11) NOT NULL,
  `login_time` datetime NOT NULL,
  `logout_time` datetime DEFAULT NULL,
  `login_status` varchar(20) NOT NULL,
  PRIMARY KEY (`login_id`),
  KEY `account_id` (`account_id`),
  CONSTRAINT `login_log_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `account` (`account_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ============================================================
-- Seed data
-- ============================================================

-- Reference data: regions
INSERT INTO `regions` (`region_name`, `country`) VALUES
('Bordeaux', 'France'),
('Tuscany', 'Italy'),
('Napa Valley', 'United States'),
('Rioja', 'Spain'),
('Barossa Valley', 'Australia'),
('Mendoza', 'Argentina');

-- Reference data: wine_varietals
INSERT INTO `wine_varietals` (`varietal_name`, `color_type`, `min_typical_aging_yrs`, `max_typical_aging_yrs`, `food_pairing_template`, `entry_temperature_celsius`) VALUES
('Cabernet Sauvignon', 'Red', 5, 15, 'Red meat, aged cheese, roasted vegetables', 17.0),
('Pinot Noir', 'Red', 3, 10, 'Duck, salmon, mushroom dishes', 15.5),
('Chardonnay', 'White', 2, 8, 'Shellfish, poultry, creamy pasta', 10.0),
('Sauvignon Blanc', 'White', 1, 4, 'Goat cheese, salads, seafood', 9.0),
('Merlot', 'Red', 3, 12, 'Grilled meats, tomato-based dishes', 16.5),
('Syrah', 'Red', 4, 14, 'Smoked meats, game, hard cheese', 17.0);

-- Reference data: certifications (issuing bodies for sommelier credentials)
INSERT INTO `certifications` (`certification_name`, `issuing_body`) VALUES
('Certified Sommelier', 'Court of Master Sommeliers'),
('WSET Level 3 Award in Wines', 'Wine & Spirit Education Trust'),
('Advanced Sommelier', 'Court of Master Sommeliers'),
('Certified Specialist of Wine', 'Society of Wine Educators');

-- Seed Admin account (per requirement: admin is added directly to the DB, no public registration)
-- Default login -> username: admin | password: Admin@123
INSERT INTO `account` (`first_name`, `last_name`, `username`, `password`, `email`, `phone_number`) VALUES
('System', 'Administrator', 'admin', '$2b$12$y7L0H.gkBgmOQgpflZMZ5ee/3C0uVh2IZqy480Q9eLqNaSZO0M8Se', 'admin@cwcsm.local', '0000000000');

INSERT INTO `admin` (`account_id`) VALUES (LAST_INSERT_ID());

COMMIT;
