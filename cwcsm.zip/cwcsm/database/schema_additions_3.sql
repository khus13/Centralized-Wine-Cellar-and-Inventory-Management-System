-- ============================================================
-- CWCSM - Schema additions #3
-- Run this AFTER schema_additions_2.sql.
--
-- Adds:
--   1. wine_varietals.image_path - picture upload support for varietals.
--   2. created_at timestamps on the modules shown in the dashboard's new
--      "Recent Updates" table, so we can query what changed recently.
-- ============================================================

USE `wine_cellar_management`;

ALTER TABLE `wine_varietals`
  ADD COLUMN `image_path` VARCHAR(255) DEFAULT NULL,
  ADD COLUMN `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP;

ALTER TABLE `cellar_inventory`
  ADD COLUMN `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP;

ALTER TABLE `tasting_notes`
  ADD COLUMN `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP;

ALTER TABLE `vineyards`
  ADD COLUMN `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP;

ALTER TABLE `supplier`
  ADD COLUMN `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP;

ALTER TABLE `certifications`
  ADD COLUMN `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP;

ALTER TABLE `sommelier_certifications`
  ADD COLUMN `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP;

ALTER TABLE `account`
  ADD COLUMN `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP;
