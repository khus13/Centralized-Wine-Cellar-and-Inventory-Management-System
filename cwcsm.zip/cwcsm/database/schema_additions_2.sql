-- ============================================================
-- CWCSM - Schema additions #2
-- Run this AFTER cwcsm_schema.sql and schema_additions.sql.
--
-- Adds:
--   1. Soft-delete columns (is_deleted, deleted_at) to every module
--      that previously did a hard DELETE, so "delete" now archives
--      instead of destroying data.
--   2. account.photo_path + account.is_deleted/deleted_at, so every
--      role (not just Sommeliers) can have a profile photo, and Admin
--      can deactivate an account instead of only resetting its password.
--   3. Security question / answer columns, used by the new self-service
--      Forgot Password flow (replacing the old "email your admin" page).
-- ============================================================

USE `wine_cellar_management`;

ALTER TABLE `cellar_inventory`
  ADD COLUMN `is_deleted` TINYINT(1) NOT NULL DEFAULT 0,
  ADD COLUMN `deleted_at` DATETIME DEFAULT NULL;

ALTER TABLE `tasting_notes`
  ADD COLUMN `is_deleted` TINYINT(1) NOT NULL DEFAULT 0,
  ADD COLUMN `deleted_at` DATETIME DEFAULT NULL;

ALTER TABLE `vineyards`
  ADD COLUMN `is_deleted` TINYINT(1) NOT NULL DEFAULT 0,
  ADD COLUMN `deleted_at` DATETIME DEFAULT NULL;

ALTER TABLE `wine_varietals`
  ADD COLUMN `is_deleted` TINYINT(1) NOT NULL DEFAULT 0,
  ADD COLUMN `deleted_at` DATETIME DEFAULT NULL;

ALTER TABLE `supplier`
  ADD COLUMN `is_deleted` TINYINT(1) NOT NULL DEFAULT 0,
  ADD COLUMN `deleted_at` DATETIME DEFAULT NULL;

ALTER TABLE `certifications`
  ADD COLUMN `is_deleted` TINYINT(1) NOT NULL DEFAULT 0,
  ADD COLUMN `deleted_at` DATETIME DEFAULT NULL;

ALTER TABLE `sommelier_certifications`
  ADD COLUMN `is_deleted` TINYINT(1) NOT NULL DEFAULT 0,
  ADD COLUMN `deleted_at` DATETIME DEFAULT NULL;

ALTER TABLE `account`
  ADD COLUMN `photo_path` VARCHAR(255) DEFAULT NULL,
  ADD COLUMN `is_deleted` TINYINT(1) NOT NULL DEFAULT 0,
  ADD COLUMN `deleted_at` DATETIME DEFAULT NULL,
  ADD COLUMN `security_question` VARCHAR(255) DEFAULT NULL,
  ADD COLUMN `security_answer_hash` VARCHAR(255) DEFAULT NULL;
