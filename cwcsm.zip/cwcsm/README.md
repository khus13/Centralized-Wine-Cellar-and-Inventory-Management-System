# CWCSM — Centralized Wine Cellar and Sommelier Management System

A role-based PHP 8 / MySQL web app for managing a wine cellar: inventory, tasting
notes, sommelier profiles & certifications, vineyards, varietals, and suppliers.

## Stack
PHP 8+ (PDO, prepared statements) · MySQL · vanilla JS · Chart.js · flat, wine-themed
responsive UI. Lightweight MVC-inspired structure — see **Project Structure** below.

## 1. Setup (XAMPP)

1. Copy the whole `cwcsm` folder into `htdocs` (e.g. `C:\xampp\htdocs\cwcsm`).
2. Start **Apache** and **MySQL** in the XAMPP control panel.
3. Open phpMyAdmin → **Import** → run these three files **in order**:
   `database/cwcsm_schema.sql`, then `database/schema_additions.sql`, then
   `database/schema_additions_2.sql` (adds soft-delete/archive support,
   universal profile photos, and the security-question password reset).
4. Open `config/db.php` and check the constants match your setup:
   - `DB_PORT` — XAMPP's MySQL is usually `3306`. If you have another MySQL
     install running too and they conflict, one of them often ends up on
     `3307` — change this constant to match.
   - `DB_USER` / `DB_PASS` — default XAMPP is `root` with no password.
5. Visit `http://localhost/cwcsm/` in your browser.

**Default admin login:** username `admin`, password `Admin@123`
(seeded directly in the SQL — admins are never created through registration,
per the spec).

## 2. Project Structure

```
/config          — config/db.php (PDO connection)
/includes        — bootstrap.php, auth.php, middleware.php, functions.php,
                    header.php / sidebar.php / footer.php (shared layout)
/models          — one PHP class per entity, all PDO + prepared statements
/controllers     — POST handlers for each module (create/update/delete),
                    included at the top of the matching page before any HTML
/views/errors    — 403.php
/api             — search.php (AJAX global search), chart_data.php (dashboard JSON)
/assets/css      — style.css
/assets/js       — main.js (search, modals, filters), dashboard.js (Chart.js)
/uploads         — wines/ profiles/ vineyards/ certifications/ (PHP execution blocked here)
/database        — cwcsm_schema.sql, schema_additions.sql
```

Each top-level page (`wine_cellar.php`, `tasting_notes.php`, etc.) is a thin
controller+view: it requires `includes/bootstrap.php`, requires the matching
`controllers/*_controller.php` (which only runs on POST), then renders.

## 3. Roles & Permissions

| | Admin | Cellar Manager | Sommelier |
|---|---|---|---|
| Wine Cellar | Full CRUD | Full CRUD | Read only |
| Tasting Notes | Full CRUD | Read only | Create; edit/delete **own** only |
| Sommeliers / Certifications catalog | Full CRUD | Read only | Read + manage **own** certs & photo |
| Vineyards / Varietals / Suppliers | Full CRUD | Read only | Read only |
| Accounts / Login Audit | Full access | — | — |

Admins are **not** created through `register.php` — only Sommelier and Cellar
Manager can self-register. Seed additional admins directly in the `admin`
table (see the `INSERT` at the bottom of `cwcsm_schema.sql` for the pattern).

## 4. Security notes

- Passwords hashed with `password_hash()` / verified with `password_verify()`.
- All queries use PDO prepared statements.
- CSRF token required on every POST (`csrf_field()` / `csrf_verify()`).
- Session cookie is `HttpOnly`, `SameSite=Lax`; sessions expire after 30
  minutes of inactivity.
- File uploads are type + size validated, renamed to random hex filenames,
  and `uploads/.htaccess` blocks PHP execution inside that folder.
- Output is escaped with `sanitize()` (a `htmlspecialchars` wrapper) everywhere
  user-supplied data is echoed.
- Unhandled exceptions are caught by a global handler (`includes/bootstrap.php`)
  so the app never leaks a raw stack trace / file path — flip `APP_DEBUG` to
  `true` there while developing if you want to see real errors.

## 5. Known simplifications (student-project scope)

- "Forgot password" isn't self-service — the schema has no reset-token or
  security-question fields, so it points the user to ask an Admin, who can
  reset any account's password from **Accounts**.
- The registration form's "Registering As" dropdown only offers Sommelier /
  Cellar Manager, matching the spec ("Admins cannot register").
- Because `cellar_inventory.manager_id` is a required foreign key to
  `cellar_manager`, an Admin adding a bottle must pick which Cellar Manager
  it's recorded under (a dropdown appears only for Admins on the Add Wine
  form; Cellar Managers get their own ID filled in automatically).
