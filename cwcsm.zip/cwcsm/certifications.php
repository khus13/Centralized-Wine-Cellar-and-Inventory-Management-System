<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_login();
require_once __DIR__ . '/controllers/certification_controller.php';

$pageTitle = 'Certifications';
$showArchived = isset($_GET['archived']) && is_admin();
$allCertifications = $showArchived ? Certification::trashed() : Certification::all();
[$certifications, $pageMeta] = paginate($allCertifications, 12);
$canEdit = is_admin();

include __DIR__ . '/includes/header.php';
?>
<div class="page-header">
  <div>
    <h1>Certifications<?= $showArchived ? ' — Archived' : '' ?></h1>
    <p class="subtitle"><?= count($allCertifications) ?> certifications &middot; Certification catalog &amp; issuing bodies</p>
  </div>
  <div style="display:flex;gap:10px;">
    <?php if ($canEdit): ?><a class="btn btn-outline btn-sm" href="certifications.php<?= $showArchived ? '' : '?archived=1' ?>"><?= icon('archive') ?> <?= $showArchived ? 'Back to Active' : 'View Archived' ?></a><?php endif; ?>
    <?php if ($canEdit && !$showArchived): ?><button class="btn btn-primary" data-open-modal="addCertModal"><?= icon('plus') ?> Add Certification</button><?php endif; ?>
  </div>
</div>

<div class="toolbar">
  <div class="filter-bar"><input type="text" placeholder="Search certifications..." data-filter-input=".filterable-row" style="width:260px;"></div>
  <div class="view-toggle">
    <button type="button" data-view="grid"><?= icon('grid') ?> Grid</button>
    <button type="button" class="active" data-view="table"><?= icon('list') ?> Table</button>
  </div>
</div>

<?php if (!$certifications): ?>
  <div class="empty-state card"><div class="icon"><?= icon('certificate') ?></div><p><?= $showArchived ? 'No archived certifications.' : 'No certifications in the catalog yet.' ?></p></div>
<?php else: ?>

<div class="entity-grid" id="gridView" style="display:none;">
  <?php foreach ($certifications as $c): ?>
  <div class="entity-card filterable-row" data-filter-text="<?= sanitize($c['certification_name'] . ' ' . $c['issuing_body']) ?>">
    <div class="thumb"><?= icon('certificate') ?></div>
    <div class="body">
      <h4><?= sanitize($c['certification_name']) ?></h4>
      <div class="meta-row"><span><?= sanitize($c['issuing_body']) ?></span></div>
      <?php if (!$showArchived): ?><div class="meta-row"><span><?= (int) $c['holder_count'] ?> holder<?= $c['holder_count'] == 1 ? '' : 's' ?></span></div><?php endif; ?>
    </div>
    <?php if ($canEdit && !$showArchived): ?>
    <div class="footer-actions">
      <button class="btn btn-outline btn-sm" data-open-modal="editCert<?= $c['certification_id'] ?>"><?= icon('edit') ?> Edit</button>
      <form method="post" action="certifications.php" data-confirm="Archive this certification?"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="certification_id" value="<?= $c['certification_id'] ?>"><button type="submit" class="btn btn-danger btn-sm"><?= icon('archive') ?> Archive</button></form>
    </div>
    <?php elseif ($canEdit): ?>
    <div class="footer-actions">
      <form method="post" action="certifications.php"><?= csrf_field() ?><input type="hidden" name="action" value="restore"><input type="hidden" name="certification_id" value="<?= $c['certification_id'] ?>"><button type="submit" class="btn btn-outline btn-sm"><?= icon('restore') ?> Restore</button></form>
    </div>
    <?php endif; ?>
  </div>
  <?php endforeach; ?>
</div>

<div class="table-wrap" id="tableView">
  <table>
    <thead><tr><th>Certification Name</th><th>Issuing Body</th><?php if (!$showArchived): ?><th>Holders</th><?php endif; ?><?php if ($canEdit): ?><th></th><?php endif; ?></tr></thead>
    <tbody>
      <?php foreach ($certifications as $c): ?>
        <tr class="filterable-row" data-filter-text="<?= sanitize($c['certification_name'] . ' ' . $c['issuing_body']) ?>">
          <td><?= sanitize($c['certification_name']) ?></td>
          <td><?= sanitize($c['issuing_body']) ?></td>
          <?php if (!$showArchived): ?><td><?= (int) $c['holder_count'] ?></td><?php endif; ?>
          <?php if ($canEdit && !$showArchived): ?>
          <td class="table-actions">
            <button class="btn btn-outline btn-sm" data-open-modal="editCert<?= $c['certification_id'] ?>">Edit</button>
            <form method="post" action="certifications.php" data-confirm="Archive this certification from the catalog?">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="delete">
              <input type="hidden" name="certification_id" value="<?= $c['certification_id'] ?>">
              <button type="submit" class="btn btn-danger btn-sm">Archive</button>
            </form>
          </td>
          <?php elseif ($canEdit): ?>
          <td class="table-actions">
            <form method="post" action="certifications.php"><?= csrf_field() ?><input type="hidden" name="action" value="restore"><input type="hidden" name="certification_id" value="<?= $c['certification_id'] ?>"><button type="submit" class="btn btn-outline btn-sm">Restore</button></form>
          </td>
          <?php endif; ?>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

<?php if ($canEdit && !$showArchived): foreach ($certifications as $c): ?>
<div class="modal-overlay" id="editCert<?= $c['certification_id'] ?>">
  <div class="modal">
    <div class="modal-header"><h3>Edit Certification</h3><button class="modal-close" data-close-modal>&times;</button></div>
    <form method="post" action="certifications.php">
      <div class="modal-body">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="update">
        <input type="hidden" name="certification_id" value="<?= $c['certification_id'] ?>">
        <div class="field"><label>Certification Name <?= req() ?></label><input type="text" name="certification_name" value="<?= sanitize($c['certification_name']) ?>" required></div>
        <div class="field"><label>Issuing Body <?= req() ?></label><input type="text" name="issuing_body" value="<?= sanitize($c['issuing_body']) ?>" required></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline" data-close-modal>Cancel</button>
        <button type="submit" class="btn btn-primary">Save Changes</button>
      </div>
    </form>
  </div>
</div>
<?php endforeach; endif; ?>

<?= render_pagination($pageMeta) ?>

<?php endif; ?>

<?php if ($canEdit && !$showArchived): ?>
<div class="modal-overlay" id="addCertModal">
  <div class="modal">
    <div class="modal-header"><h3>Add Certification</h3><button class="modal-close" data-close-modal>&times;</button></div>
    <form method="post" action="certifications.php">
      <div class="modal-body">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="create">
        <div class="field"><label>Certification Name <?= req() ?></label><input type="text" name="certification_name" required></div>
        <div class="field"><label>Issuing Body <?= req() ?></label><input type="text" name="issuing_body" required></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline" data-close-modal>Cancel</button>
        <button type="submit" class="btn btn-primary">Add Certification</button>
      </div>
    </form>
  </div>
</div>
<?php endif; ?>

<?php include __DIR__ . '/includes/footer.php'; ?>
