<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_role('admin');

$pageTitle = 'Login Audit';

$filters = [
    'date'     => trim($_GET['date'] ?? ''),
    'username' => trim($_GET['username'] ?? ''),
    'role'     => trim($_GET['role'] ?? ''),
];
$logs = LoginAudit::all(array_filter($filters));
[$pagedLogs, $pageMeta] = paginate($logs, 20);

include __DIR__ . '/includes/header.php';
?>
<div class="page-header">
  <div><h1>Login Audit</h1><p class="subtitle">Track sign-ins across every account</p></div>
</div>

<form method="get" action="login_audit.php" class="toolbar">
  <div class="filter-bar">
    <input type="text" name="username" placeholder="Filter by username" value="<?= sanitize($filters['username']) ?>">
    <input type="date" name="date" value="<?= sanitize($filters['date']) ?>">
    <select name="role">
      <option value="">All Roles</option>
      <option value="admin" <?= $filters['role'] === 'admin' ? 'selected' : '' ?>>Admin</option>
      <option value="sommelier" <?= $filters['role'] === 'sommelier' ? 'selected' : '' ?>>Sommelier</option>
      <option value="cellar_manager" <?= $filters['role'] === 'cellar_manager' ? 'selected' : '' ?>>Cellar Manager</option>
    </select>
    <button type="submit" class="btn btn-outline btn-sm">Filter</button>
    <a href="login_audit.php" class="btn btn-outline btn-sm">Clear</a>
  </div>
</form>

<?php if (!$logs): ?>
  <div class="empty-state card"><div class="icon">&#128274;</div><p>No login activity matches these filters.</p></div>
<?php else: ?>
<div class="table-wrap">
  <table>
    <thead><tr><th>Username</th><th>Role</th><th>Login Time</th><th>Logout Time</th><th>Status</th></tr></thead>
    <tbody>
    <?php foreach ($pagedLogs as $l): ?>
      <tr>
        <td><?= sanitize($l['username']) ?> <span style="color:#5c4d4f;">(<?= sanitize($l['first_name'] . ' ' . $l['last_name']) ?>)</span></td>
        <td><span class="role-badge role-<?= sanitize($l['role']) ?>"><?= sanitize(str_replace('_', ' ', $l['role'])) ?></span></td>
        <td><?= date('M j, Y g:i A', strtotime($l['login_time'])) ?></td>
        <td><?= $l['logout_time'] ? date('M j, Y g:i A', strtotime($l['logout_time'])) : '—' ?></td>
        <td><span class="status-pill status-<?= $l['login_status'] === 'success' ? 'active' : 'inactive' ?>"><?= sanitize(ucfirst($l['login_status'])) ?></span></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?= render_pagination($pageMeta) ?>
<?php endif; ?>

<?php include __DIR__ . '/includes/footer.php'; ?>
