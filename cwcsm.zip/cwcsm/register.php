<?php
require_once __DIR__ . '/includes/bootstrap.php';

if (is_logged_in()) {
    redirect('dashboard.php');
}

$errors = [];
$old = ['first_name' => '', 'last_name' => '', 'username' => '', 'email' => '', 'security_question' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    $old['first_name'] = trim($_POST['first_name'] ?? '');
    $old['last_name']  = trim($_POST['last_name'] ?? '');
    $old['username']   = trim($_POST['username'] ?? '');
    $old['email']      = trim($_POST['email'] ?? '');
    $old['security_question'] = $_POST['security_question'] ?? '';
    $password          = $_POST['password'] ?? '';
    $confirm           = $_POST['confirm_password'] ?? '';
    $securityAnswer    = $_POST['security_answer'] ?? '';

    if ($old['first_name'] === '' || $old['last_name'] === '' || $old['username'] === '' || $old['email'] === '') {
        $errors[] = 'Please fill in all required fields.';
    }
    if (!filter_var($old['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Please enter a valid email address.';
    }
    if ($password !== $confirm) {
        $errors[] = 'Passwords do not match.';
    }

    if (!$errors) {
        // New accounts always start as Sommelier; an admin can promote later.
        [$ok, $err] = register_account($old['first_name'], $old['last_name'], $old['username'], $old['email'], $password, 'sommelier', $old['security_question'], $securityAnswer);
        if ($ok) {
            flash('success', 'Account created! You can now sign in.');
            redirect('login.php');
        } else {
            $errors[] = $err;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sign Up — CWCSM</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= asset_url('assets/css/style.css') ?>">
</head>
<body>
<div class="auth-shell">
  <div class="auth-panel" style="flex-basis:540px;">
    <div class="auth-panel-inner" style="max-width:440px;">
      <p class="logo">CWCSM</p>
      <p class="tagline">Centralized Wine Cellar and Sommelier Management</p>
      <p class="welcome">Looking forward to managing with you!</p>

      <div class="auth-tabs">
        <a href="login.php">Sign In</a>
        <a class="active" href="register.php">Sign Up</a>
      </div>

      <?php foreach ($errors as $e): ?>
        <div class="flash flash-error" style="margin-bottom:14px;"><?= sanitize($e) ?><button type="button" class="flash-close" data-dismiss-flash aria-label="Dismiss">&times;</button></div>
      <?php endforeach; ?>

      <form method="post" action="register.php">
        <?= csrf_field() ?>
        <div class="form-grid">
          <div class="field">
            <label for="first_name">First Name <?= req() ?></label>
            <input type="text" id="first_name" name="first_name" placeholder="First Name" required value="<?= sanitize($old['first_name']) ?>">
          </div>
          <div class="field">
            <label for="last_name">Last Name <?= req() ?></label>
            <input type="text" id="last_name" name="last_name" placeholder="Last Name" required value="<?= sanitize($old['last_name']) ?>">
          </div>
        </div>
        <div class="field">
          <label for="username">Username <?= req() ?></label>
          <input type="text" id="username" name="username" placeholder="Username" required value="<?= sanitize($old['username']) ?>">
        </div>
        <div class="field">
          <label for="email">Email <?= req() ?></label>
          <input type="email" id="email" name="email" placeholder="Email" required value="<?= sanitize($old['email']) ?>">
        </div>
        <div class="flash flash-info" style="margin-bottom:14px;">
          New accounts join as a <strong>Sommelier</strong>. An administrator can promote you to Cellar Manager or System Admin later.
        </div>
        <div class="form-grid">
          <div class="field">
            <label for="password">Password <?= req() ?></label>
            <input type="password" id="password" name="password" placeholder="Password" required minlength="8">
          </div>
          <div class="field">
            <label for="confirm_password">Confirm Password <?= req() ?></label>
            <input type="password" id="confirm_password" name="confirm_password" placeholder="Confirm Password" required minlength="8">
          </div>
        </div>
        <div class="field">
          <label for="security_question">Security Question <?= req() ?></label>
          <select id="security_question" name="security_question" required>
            <option value="" disabled selected>Used to reset your password later</option>
            <?php foreach (SECURITY_QUESTIONS as $q): ?>
              <option value="<?= sanitize($q) ?>" <?= $old['security_question'] === $q ? 'selected' : '' ?>><?= sanitize($q) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="field">
          <label for="security_answer">Your Answer <?= req() ?></label>
          <input type="text" id="security_answer" name="security_answer" placeholder="Answer" required>
        </div>
        <button type="submit" class="btn btn-primary auth-submit">Create Account</button>
      </form>

      <p class="auth-switch"><a href="login.php">Back to Login</a></p>
    </div>
  </div>
  <div class="auth-visual">
    <span class="brand-mark">CWCSM</span>
    <div>
      <p class="quote">"Precision in the cellar begins with the record on the page."</p>
      <p class="meta-line">Sommelier &amp; Cellar Manager sign-up</p>
    </div>
  </div>
</div>
<script src="<?= asset_url('assets/js/main.js') ?>"></script>
</body>
</html>
