<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_login();
require_role(['cellar_manager', 'admin']);

$pageTitle = 'Vineyard & Supplier Insights';

$db = getDB();

// Vineyard performance: avg tasting scores per vineyard
$vineyardPerf = $db->query(
    "SELECT v.vineyard_id, v.vineyard_name, r.region_name, r.country,
            COUNT(DISTINCT ci.bottle_id) AS bottle_count,
            COUNT(tn.note_id) AS note_count,
            ROUND(AVG(tn.body_rating), 1) AS avg_body,
            ROUND(AVG(tn.acidity_rating), 1) AS avg_acidity,
            ROUND(AVG(tn.tannin_rating), 1) AS avg_tannin,
            ROUND((AVG(tn.body_rating) + AVG(tn.acidity_rating) + AVG(tn.tannin_rating)) / 3, 1) AS overall_avg,
            COALESCE((SELECT ROUND(AVG(wr.rating),1) FROM wine_ratings wr JOIN cellar_inventory ci2 ON ci2.bottle_id = wr.bottle_id WHERE ci2.vineyard_id = v.vineyard_id), 0) AS avg_wine_rating,
            COALESCE(SUM(ci.purchase_price), 0) AS total_value
     FROM vineyards v
     JOIN regions r ON r.region_id = v.region_id
     JOIN cellar_inventory ci ON ci.vineyard_id = v.vineyard_id AND ci.is_deleted = 0
     JOIN tasting_notes tn ON tn.bottle_id = ci.bottle_id AND tn.is_deleted = 0
     WHERE v.is_deleted = 0
     GROUP BY v.vineyard_id, v.vineyard_name, r.region_name, r.country
     ORDER BY overall_avg DESC"
)->fetchAll();

[$pagedVineyards, $vpMeta] = paginate($vineyardPerf, 12, 'vp');

// Supplier performance: avg supplier ratings + delivery stats
$supplierPerf = $db->query(
    "SELECT s.supplier_id, s.supplier_contact_name, v.vineyard_name, wv.varietal_name,
            s.lead_time_days,
            COUNT(DISTINCT ci.bottle_id) AS bottles_supplied,
            COALESCE((SELECT ROUND(AVG(sr.rating),1) FROM supplier_ratings sr WHERE sr.supplier_id = s.supplier_id), 0) AS avg_supplier_rating,
            COALESCE((SELECT COUNT(*) FROM supplier_ratings sr2 WHERE sr2.supplier_id = s.supplier_id), 0) AS rater_count,
            COALESCE((SELECT ROUND(AVG(wr2.rating),1) FROM wine_ratings wr2 JOIN cellar_inventory ci2 ON ci2.bottle_id = wr2.bottle_id WHERE ci2.supplier_id = s.supplier_id), 0) AS avg_wine_quality
     FROM supplier s
     JOIN vineyards v ON v.vineyard_id = s.vineyard_id
     JOIN wine_varietals wv ON wv.varietal_id = s.varietal_id
     LEFT JOIN cellar_inventory ci ON ci.supplier_id = s.supplier_id AND ci.is_deleted = 0
     WHERE s.is_deleted = 0
     GROUP BY s.supplier_id, s.supplier_contact_name, v.vineyard_name, wv.varietal_name, s.lead_time_days
     ORDER BY avg_supplier_rating DESC, avg_wine_quality DESC"
)->fetchAll();

[$pagedSuppliers, $spMeta] = paginate($supplierPerf, 15, 'sp');

include __DIR__ . '/includes/header.php';
?>
<div class="page-header">
  <div>
    <h1>Vineyard &amp; Supplier Insights</h1>
    <p class="subtitle">Determine which vineyards produce the best wines based on tasting notes and ratings</p>
  </div>
</div>

<!-- Vineyard Performance -->
<div class="card" style="margin-bottom:16px;">
  <h3>Vineyard Performance by Tasting Notes</h3>
  <p style="font-size:12px;color:var(--ink-muted);margin-bottom:12px;">Ranked by average tasting score across all bottles from each vineyard.</p>

  <?php if (!$vineyardPerf): ?>
    <p style="color:var(--ink-muted);font-size:13px;">No tasting data available yet.</p>
  <?php else: ?>
    <div class="compare-grid">
      <?php foreach ($pagedVineyards as $vp): ?>
        <div class="compare-card">
          <div class="compare-title"><?= sanitize($vp['vineyard_name']) ?></div>
          <div class="compare-sub"><?= sanitize($vp['region_name'] . ', ' . $vp['country']) ?> · <?= (int) $vp['bottle_count'] ?> bottles · <?= (int) $vp['note_count'] ?> notes</div>
          <div class="compare-stats">
            <div class="compare-stat"><span class="stat-label">Body</span><span class="stat-val"><?= $vp['avg_body'] ?></span></div>
            <div class="compare-bar"><div class="fill" style="width:<?= ($vp['avg_body']/5)*100 ?>%"></div></div>
            <div class="compare-stat"><span class="stat-label">Acidity</span><span class="stat-val"><?= $vp['avg_acidity'] ?></span></div>
            <div class="compare-bar"><div class="fill" style="width:<?= ($vp['avg_acidity']/5)*100 ?>%"></div></div>
            <div class="compare-stat"><span class="stat-label">Tannin</span><span class="stat-val"><?= $vp['avg_tannin'] ?></span></div>
            <div class="compare-bar"><div class="fill" style="width:<?= ($vp['avg_tannin']/5)*100 ?>%"></div></div>
            <div class="compare-stat" style="margin-top:6px;padding-top:6px;border-top:1px solid var(--border);"><span class="stat-label" style="font-weight:700;">Overall Score</span><span class="stat-val"><?= $vp['overall_avg'] ?> / 5</span></div>
            <?php if ($vp['avg_wine_rating'] > 0): ?>
              <div class="compare-stat"><span class="stat-label">Avg Wine Rating</span><span class="stat-val"><?= star_rating((int) round($vp['avg_wine_rating'])) ?> <?= $vp['avg_wine_rating'] ?></span></div>
            <?php endif; ?>
            <div class="compare-stat"><span class="stat-label">Inventory Value</span><span class="stat-val"><?= money((float) $vp['total_value']) ?></span></div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
    <?= render_pagination($vpMeta) ?>
  <?php endif; ?>
</div>

<!-- Supplier Performance -->
<div class="card">
  <h3>Supplier Performance</h3>
  <p style="font-size:12px;color:var(--ink-soft);margin-bottom:12px;">Supplier ratings from Cellar Managers alongside the quality of wines they supply.</p>

  <?php if (!$supplierPerf): ?>
    <p style="color:var(--ink-soft);font-size:13px;">No supplier data available yet.</p>
  <?php else: ?>
    <div class="table-wrap" style="margin-top:10px;">
      <table>
        <thead><tr><th>Supplier</th><th>Vineyard</th><th>Varietal</th><th>Lead Time</th><th>Bottles</th><th>Supplier Rating</th><th>Wine Quality</th></tr></thead>
        <tbody>
        <?php foreach ($pagedSuppliers as $sp): ?>
          <tr>
            <td><?= sanitize($sp['supplier_contact_name']) ?></td>
            <td><?= sanitize($sp['vineyard_name']) ?></td>
            <td><?= sanitize($sp['varietal_name']) ?></td>
            <td><?= (int) $sp['lead_time_days'] ?> days</td>
            <td><?= (int) $sp['bottles_supplied'] ?></td>
            <td><?= $sp['avg_supplier_rating'] > 0 ? avg_stars((float)$sp['avg_supplier_rating'], (int)$sp['rater_count']) : '<span style="color:var(--ink-soft);">Not rated</span>' ?></td>
            <td><?= $sp['avg_wine_quality'] > 0 ? star_rating((int) round($sp['avg_wine_quality'])) . ' ' . $sp['avg_wine_quality'] : '<span style="color:var(--ink-soft);">—</span>' ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?= render_pagination($spMeta) ?>
  <?php endif; ?>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
