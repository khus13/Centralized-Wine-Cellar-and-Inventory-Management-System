<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_login();

require_once __DIR__ . '/controllers/wine_rating_controller.php'; // handles rating POSTs first
require_once __DIR__ . '/controllers/wine_controller.php'; // handles POST, redirects back

$pageTitle = 'Wine Cellar';
$showArchived = isset($_GET['archived']) && can_manage_inventory();
$allBottles = $showArchived ? Inventory::trashed() : Inventory::all();

// Highlight jump: if the search bar sent a highlight param and the item is on
// a different page, redirect to that page automatically.
$highlightId = $_GET['highlight'] ?? null;
if ($highlightId && !isset($_GET['page'])) {
    $targetPage = page_of_item($allBottles, 'bottle_id', $highlightId, 12);
    if ($targetPage && $targetPage > 1) {
        redirect('wine_cellar.php?highlight=' . urlencode($highlightId) . '&page=' . $targetPage);
    }
}

[$bottles, $pageMeta] = paginate($allBottles, 12);
$vineyards = Vineyard::all();
$varietals = Varietal::all();
$suppliers = Supplier::all();
$managers = can_manage_inventory() ? CellarManager::all() : [];
$canEdit = can_manage_inventory();
$missingDeps = $canEdit && (!$vineyards || !$varietals || !$suppliers);

include __DIR__ . '/includes/header.php';
?>
<div class="page-header">
  <div>
    <h1>Wine Cellar<?= $showArchived ? ' — Archived' : '' ?></h1>
    <p class="subtitle"><?= count($bottles) ?> bottle<?= count($bottles) === 1 ? '' : 's' ?> <?= $showArchived ? 'archived' : 'in inventory' ?></p>
  </div>
  <div style="display:flex;gap:10px;">
    <?php if ($canEdit): ?>
      <a class="btn btn-outline btn-sm" href="wine_cellar.php<?= $showArchived ? '' : '?archived=1' ?>"><?= icon('archive') ?> <?= $showArchived ? 'Back to Active' : 'View Archived' ?></a>
    <?php endif; ?>
    <?php if ($canEdit && !$showArchived): ?>
      <button class="btn btn-primary" <?= $missingDeps ? 'disabled' : '' ?> data-open-modal="addWineModal"><?= icon('plus') ?> Add Wine</button>
    <?php endif; ?>
  </div>
</div>

<?php if ($missingDeps && !$showArchived): ?>
  <div class="flash flash-info" style="margin-bottom:18px;">
    Before you can add a wine, make sure you have at least one <strong>Vineyard</strong>, <strong>Wine Varietal</strong>, and <strong>Supplier</strong> set up.
    <?php if (!$vineyards): ?><a href="vineyards.php">Add a vineyard →</a><?php endif; ?>
    <?php if (!$varietals): ?> <a href="varietals.php">Add a varietal →</a><?php endif; ?>
    <?php if (!$suppliers): ?> <a href="suppliers.php">Add a supplier →</a><?php endif; ?>
  </div>
<?php endif; ?>

<div class="toolbar">
  <div class="filter-bar">
    <input type="text" placeholder="Search vineyard, varietal, bin #..." data-filter-input=".filterable-row" style="width:260px;">
  </div>
  <div class="view-toggle">
    <button type="button" class="active" data-view="grid"><?= icon('grid') ?> Grid</button>
    <button type="button" data-view="table"><?= icon('list') ?> Table</button>
  </div>
</div>

<?php if (!$bottles): ?>
  <div class="empty-state card">
    <div class="icon"><?= icon('wine') ?></div>
    <p><?= $showArchived ? 'No archived bottles.' : 'No bottles in the cellar yet.' ?></p>
  </div>
<?php else: ?>

<div class="entity-grid" id="gridView">
  <?php foreach ($bottles as $b): ?>
    <div class="entity-card filterable-row" data-item-id="<?= $b['bottle_id'] ?>" data-filter-text="<?= sanitize($b['vineyard_name'] . ' ' . $b['varietal_name'] . ' ' . $b['storage_bin_number']) ?>">
      <div class="thumb">
        <?php if (!empty($b['image_path'])): ?>
          <img src="<?= sanitize(upload_url($b['image_path'])) ?>" alt="<?= sanitize($b['vineyard_name']) ?>">
        <?php else: ?>
          <?= icon('wine') ?>
        <?php endif; ?>
      </div>
      <div class="body">
        <h4><?= sanitize($b['vineyard_name']) ?></h4>
        <div class="meta-row"><span><?= sanitize($b['varietal_name']) ?></span><span>Vintage <?= (int) $b['vintage_year'] ?></span></div>
        <div class="meta-row"><span>Bin <?= sanitize($b['storage_bin_number']) ?></span><span><?= money((float) $b['purchase_price']) ?></span></div>
        <div style="margin-top:8px;">
          <span class="status-pill status-<?= sanitize(strtolower(str_replace(' ', '_', $b['inventory_status']))) ?>"><?= sanitize($b['inventory_status']) ?></span>
        </div>
      </div>
      <div class="footer-actions">
        <button class="btn btn-outline btn-sm" data-open-modal="viewWine<?= $b['bottle_id'] ?>">View</button>
        <?php if ($canEdit && !$showArchived): ?>
          <button class="btn btn-outline btn-sm" data-open-modal="editWine<?= $b['bottle_id'] ?>"><?= icon('edit') ?> Edit</button>
          <form method="post" action="wine_cellar.php" data-confirm="Archive this bottle? You can restore it later from the Archived view." style="display:inline;">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="bottle_id" value="<?= $b['bottle_id'] ?>">
            <button type="submit" class="btn btn-danger btn-sm"><?= icon('archive') ?> Archive</button>
          </form>
        <?php elseif ($canEdit && $showArchived): ?>
          <form method="post" action="wine_cellar.php" style="display:inline;">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="restore">
            <input type="hidden" name="bottle_id" value="<?= $b['bottle_id'] ?>">
            <button type="submit" class="btn btn-outline btn-sm"><?= icon('restore') ?> Restore</button>
          </form>
        <?php endif; ?>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<div class="table-wrap" id="tableView" style="display:none;">
  <table>
    <thead>
      <tr><th>Vineyard</th><th>Varietal</th><th>Vintage</th><th>Bin</th><th>Purchase Price</th><th>Status</th><th>Recorded By</th><th></th></tr>
    </thead>
    <tbody>
      <?php foreach ($bottles as $b): ?>
        <tr class="filterable-row" data-filter-text="<?= sanitize($b['vineyard_name'] . ' ' . $b['varietal_name'] . ' ' . $b['storage_bin_number']) ?>">
          <td><?= sanitize($b['vineyard_name']) ?></td>
          <td><?= sanitize($b['varietal_name']) ?></td>
          <td><?= (int) $b['vintage_year'] ?></td>
          <td><?= sanitize($b['storage_bin_number']) ?></td>
          <td><?= money((float) $b['purchase_price']) ?></td>
          <td><span class="status-pill status-<?= sanitize(strtolower(str_replace(' ', '_', $b['inventory_status']))) ?>"><?= sanitize($b['inventory_status']) ?></span></td>
          <td><?= sanitize($b['manager_first_name'] . ' ' . $b['manager_last_name']) ?></td>
          <td class="table-actions">
            <button class="btn btn-outline btn-sm" data-open-modal="viewWine<?= $b['bottle_id'] ?>">View</button>
            <?php if ($canEdit && !$showArchived): ?>
              <button class="btn btn-outline btn-sm" data-open-modal="editWine<?= $b['bottle_id'] ?>">Edit</button>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

<?php foreach ($bottles as $b): ?>
  <!-- View modal -->
  <div class="modal-overlay" id="viewWine<?= $b['bottle_id'] ?>">
    <div class="modal">
      <div class="modal-header"><h3><?= sanitize($b['vineyard_name']) ?> — <?= sanitize($b['varietal_name']) ?></h3><button class="modal-close" data-close-modal>&times;</button></div>
      <div class="modal-body">
        <?php if (!empty($b['image_path'])): ?><img src="<?= sanitize(upload_url($b['image_path'])) ?>" style="border-radius:8px;margin-bottom:14px;max-height:220px;object-fit:cover;width:100%;"><?php endif; ?>
        <p><strong>Vintage:</strong> <?= (int) $b['vintage_year'] ?></p>
        <p><strong>Storage Bin:</strong> <?= sanitize($b['storage_bin_number']) ?></p>
        <p><strong>Purchase Price:</strong> <?= money((float) $b['purchase_price']) ?></p>
        <p><strong>Purchase Date:</strong> <?= format_date($b['purchase_date']) ?></p>
        <p><strong>Status:</strong> <?= sanitize($b['inventory_status']) ?></p>
        <p><strong>Supplier:</strong> <?= sanitize($b['supplier_contact_name']) ?></p>
        <p><strong>Last Checked:</strong> <?= format_date($b['last_inventory_check_date']) ?></p>
        <p><strong>Recorded By:</strong> <?= sanitize($b['manager_first_name'] . ' ' . $b['manager_last_name']) ?></p>
        <p><strong>Tasting Notes:</strong> <?= TastingNote::countForBottle((int) $b['bottle_id']) ?></p>

        <?php
          $wineRatings = WineRating::forBottle((int) $b['bottle_id']);
          $ratingSummary = WineRating::summaryForBottle((int) $b['bottle_id']);
        ?>
        <div class="rating-block">
          <h4>Wine Ratings <?= $ratingSummary['count'] > 0 ? avg_stars($ratingSummary['avg'], $ratingSummary['count']) : '' ?></h4>
          <?php if ($wineRatings): ?>
            <?php foreach ($wineRatings as $wr): ?>
              <div class="rating-entry">
                <div class="who"><?= sanitize($wr['first_name'] . ' ' . $wr['last_name']) ?> — <?= star_rating((int) $wr['rating']) ?></div>
                <?php if ($wr['report']): ?><div class="report"><?= sanitize($wr['report']) ?></div><?php endif; ?>
              </div>
            <?php endforeach; ?>
          <?php else: ?>
            <p class="rating-empty">No ratings yet.</p>
          <?php endif; ?>
        </div>

        <?php if (is_sommelier()): ?>
          <?php $myWR = WineRating::forBottleBySommelier((int) $b['bottle_id'], (int) current_user()['profile_id']); ?>
          <div style="margin-top:14px;padding-top:12px;border-top:1px solid var(--border-soft);">
            <h4 style="font-size:13px;text-transform:uppercase;letter-spacing:.5px;color:var(--ink-soft);margin-bottom:8px;">Your Rating</h4>
            <form method="post" action="wine_cellar.php" style="display:flex;flex-direction:column;gap:10px;">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="rate_wine">
              <input type="hidden" name="bottle_id" value="<?= $b['bottle_id'] ?>">
              <div class="field">
                <label>Rating (1–5) <?= req() ?></label>
                <input type="number" name="rating" min="1" max="5" value="<?= $myWR ? (int) $myWR['rating'] : 4 ?>" required>
              </div>
              <div class="field">
                <label>Report / Notes</label>
                <textarea name="report" rows="2" placeholder="Why did you rate it this way?"><?= sanitize($myWR['report'] ?? '') ?></textarea>
              </div>
              <div style="display:flex;gap:8px;">
                <button type="submit" class="btn btn-primary btn-sm"><?= $myWR ? 'Update Rating' : 'Submit Rating' ?></button>
                <?php if ($myWR): ?>
                  <form method="post" action="wine_cellar.php" style="display:inline;" data-confirm="Remove your rating for this wine?">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="delete_wine_rating">
                    <input type="hidden" name="bottle_id" value="<?= $b['bottle_id'] ?>">
                    <button type="submit" class="btn btn-danger btn-sm">Remove Rating</button>
                  </form>
                <?php endif; ?>
              </div>
            </form>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <?php if ($canEdit && !$showArchived): ?>
  <!-- Edit modal -->
  <div class="modal-overlay" id="editWine<?= $b['bottle_id'] ?>">
    <div class="modal modal-lg">
      <div class="modal-header"><h3>Edit Wine</h3><button class="modal-close" data-close-modal>&times;</button></div>

      <?php if (!empty($b['image_path'])): ?>
      <div style="padding:16px 22px 0;display:flex;align-items:center;gap:12px;">
        <img src="<?= sanitize(upload_url($b['image_path'])) ?>" style="height:56px;width:56px;object-fit:cover;border-radius:6px;">
        <form method="post" action="wine_cellar.php" data-confirm="Remove this bottle's photo?">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="remove_image">
          <input type="hidden" name="bottle_id" value="<?= $b['bottle_id'] ?>">
          <button type="submit" class="btn btn-outline remove-image-btn btn-sm"><?= icon('trash') ?> Remove Image</button>
        </form>
      </div>
      <?php endif; ?>

      <form method="post" action="wine_cellar.php" enctype="multipart/form-data">
        <div class="modal-body">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="update">
          <input type="hidden" name="bottle_id" value="<?= $b['bottle_id'] ?>">
          <div class="form-grid">
            <div class="field"><label>Vineyard <?= req() ?></label>
              <select name="vineyard_id" required>
                <?php foreach ($vineyards as $v): ?><option value="<?= $v['vineyard_id'] ?>" <?= $v['vineyard_id'] == $b['vineyard_id'] ? 'selected' : '' ?>><?= sanitize($v['vineyard_name']) ?></option><?php endforeach; ?>
              </select>
            </div>
            <div class="field"><label>Varietal <?= req() ?></label>
              <select name="varietal_id" required>
                <?php foreach ($varietals as $v): ?><option value="<?= $v['varietal_id'] ?>" <?= $v['varietal_id'] == $b['varietal_id'] ? 'selected' : '' ?>><?= sanitize($v['varietal_name']) ?></option><?php endforeach; ?>
              </select>
            </div>
            <div class="field"><label>Supplier <?= req() ?></label>
              <select name="supplier_id" required>
                <?php foreach ($suppliers as $s): ?><option value="<?= $s['supplier_id'] ?>" <?= $s['supplier_id'] == $b['supplier_id'] ? 'selected' : '' ?>><?= sanitize($s['supplier_contact_name']) ?></option><?php endforeach; ?>
              </select>
            </div>
            <div class="field"><label>Vintage Year <?= req() ?></label><input type="number" name="vintage_year" value="<?= (int) $b['vintage_year'] ?>" min="1900" max="2100" required></div>
            <div class="field"><label>Storage Bin <?= req() ?></label><input type="text" name="storage_bin_number" value="<?= sanitize($b['storage_bin_number']) ?>" required></div>
            <div class="field"><label>Purchase Price <?= req() ?></label><input type="number" step="0.01" name="purchase_price" value="<?= $b['purchase_price'] ?>" required></div>
            <div class="field"><label>Purchase Date <?= req() ?></label><input type="date" name="purchase_date" value="<?= sanitize($b['purchase_date']) ?>" required></div>
            <div class="field"><label>Last Inventory Check</label><input type="date" name="last_inventory_check_date" value="<?= sanitize($b['last_inventory_check_date']) ?>" required></div>
            <div class="field"><label>Status</label>
              <select name="inventory_status">
                <?php foreach (['In Stock', 'Reserved', 'Sold', 'Out of Stock'] as $st): ?>
                  <option value="<?= $st ?>" <?= $b['inventory_status'] === $st ? 'selected' : '' ?>><?= $st ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="field field-span-2">
              <label><?= empty($b['image_path']) ? 'Bottle Image' : 'Replace Bottle Image' ?></label>
              <input type="file" name="bottle_image" accept="image/*">
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline" data-close-modal>Cancel</button>
          <button type="submit" class="btn btn-primary">Save Changes</button>
        </div>
      </form>
    </div>
  </div>
  <?php endif; ?>
<?php endforeach; ?>

<?php endif; ?>

<?= render_pagination($pageMeta) ?>

<?php if ($canEdit && !$missingDeps): ?>
<!-- Add Wine modal -->
<div class="modal-overlay" id="addWineModal">
  <div class="modal modal-lg">
    <div class="modal-header"><h3>Add Wine to Cellar</h3><button class="modal-close" data-close-modal>&times;</button></div>
    <form method="post" action="wine_cellar.php" enctype="multipart/form-data">
      <div class="modal-body">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="create">
        <div class="form-grid">
          <div class="field"><label>Vineyard <?= req() ?></label>
            <select name="vineyard_id" required>
              <option value="" disabled selected>Select vineyard</option>
              <?php foreach ($vineyards as $v): ?><option value="<?= $v['vineyard_id'] ?>"><?= sanitize($v['vineyard_name']) ?></option><?php endforeach; ?>
            </select>
          </div>
          <div class="field"><label>Varietal <?= req() ?></label>
            <select name="varietal_id" required>
              <option value="" disabled selected>Select varietal</option>
              <?php foreach ($varietals as $v): ?><option value="<?= $v['varietal_id'] ?>"><?= sanitize($v['varietal_name']) ?></option><?php endforeach; ?>
            </select>
          </div>
          <div class="field"><label>Supplier <?= req() ?></label>
            <select name="supplier_id" required>
              <option value="" disabled selected>Select supplier</option>
              <?php foreach ($suppliers as $s): ?><option value="<?= $s['supplier_id'] ?>"><?= sanitize($s['supplier_contact_name']) ?></option><?php endforeach; ?>
            </select>
          </div>
          <?php if (is_admin()): ?>
          <div class="field"><label>Recorded By (Cellar Manager)</label>
            <select name="manager_id" required>
              <option value="" disabled selected>Select cellar manager</option>
              <?php foreach ($managers as $m): ?><option value="<?= $m['manager_id'] ?>"><?= sanitize($m['first_name'] . ' ' . $m['last_name']) ?></option><?php endforeach; ?>
            </select>
            <?php if (!$managers): ?><span class="hint">No Cellar Managers registered yet — register one from the Sign Up page first.</span><?php endif; ?>
          </div>
          <?php endif; ?>
          <div class="field"><label>Vintage Year <?= req() ?></label><input type="number" name="vintage_year" min="1900" max="2100" required></div>
          <div class="field"><label>Storage Bin <?= req() ?></label><input type="text" name="storage_bin_number" placeholder="e.g. A-14" required></div>
          <div class="field"><label>Purchase Price <?= req() ?></label><input type="number" step="0.01" name="purchase_price" required></div>
          <div class="field"><label>Purchase Date <?= req() ?></label><input type="date" name="purchase_date" required></div>
          <div class="field"><label>Last Inventory Check</label><input type="date" name="last_inventory_check_date" value="<?= date('Y-m-d') ?>" required></div>
          <div class="field"><label>Status</label>
            <select name="inventory_status">
              <?php foreach (['In Stock', 'Reserved', 'Sold', 'Out of Stock'] as $st): ?><option value="<?= $st ?>"><?= $st ?></option><?php endforeach; ?>
            </select>
          </div>
          <div class="field field-span-2"><label>Bottle Image (optional)</label><input type="file" name="bottle_image" accept="image/*"></div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline" data-close-modal>Cancel</button>
        <button type="submit" class="btn btn-primary">Add Wine</button>
      </div>
    </form>
  </div>
</div>
<?php endif; ?>

<?php include __DIR__ . '/includes/footer.php'; ?>
