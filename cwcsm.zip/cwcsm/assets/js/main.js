/* CWCSM - main.js: global search, sidebar toggle, modal + view-toggle helpers */

document.addEventListener('DOMContentLoaded', function () {
  /* Move the flash-stack to a direct child of <body>. It's position:fixed, but .main
     has backdrop-filter, which makes fixed descendants position relative to .main
     instead of the viewport — this was causing toasts to render in the wrong spot
     with unreliable click hit-testing (close button doing nothing). */
  var flashStack = document.querySelector('.flash-stack');
  if (flashStack && flashStack.parentElement !== document.body) {
    document.body.appendChild(flashStack);
  }

  /* ---------------- Individual toast messages: auto-dismiss + manual close ---------------- */
  document.querySelectorAll('.flash').forEach(function (el) {
    var closeBtn = el.querySelector('[data-dismiss-flash]');
    var remove = function () {
      el.style.transition = 'opacity 0.2s ease, transform 0.2s ease';
      el.style.opacity = '0';
      el.style.transform = 'translateX(24px)';
      setTimeout(function () { el.remove(); }, 200);
    };
    if (closeBtn) closeBtn.addEventListener('click', remove);
    setTimeout(remove, 6000);
  });

  /* ---------------- File inputs: show selected filename + a way to clear it before submitting ---------------- */
  document.querySelectorAll('input[type="file"]').forEach(function (input) {
    var wrap = document.createElement('div');
    wrap.className = 'file-input-status';
    input.insertAdjacentElement('afterend', wrap);

    var render = function () {
      wrap.innerHTML = '';
      if (input.files && input.files.length) {
        var name = document.createElement('span');
        name.className = 'file-input-name';
        name.textContent = input.files[0].name;
        var clearBtn = document.createElement('button');
        clearBtn.type = 'button';
        clearBtn.className = 'file-input-clear';
        clearBtn.setAttribute('aria-label', 'Remove selected file');
        clearBtn.textContent = '\u00d7 Remove';
        clearBtn.addEventListener('click', function () {
          input.value = '';
          render();
        });
        wrap.appendChild(name);
        wrap.appendChild(clearBtn);
      }
    };

    input.addEventListener('change', render);
  });

  /* ---------------- Vineyards: inline "add a new region" fields inside Add/Edit forms ---------------- */
  document.querySelectorAll('.region-select').forEach(function (select) {
    var wrap = select.closest('.field').querySelector('.new-region-fields');
    if (!wrap) return;
    var nameInput = wrap.querySelector('input[name="new_region_name"]');
    var countryInput = wrap.querySelector('input[name="new_region_country"]');
    var sync = function () {
      var isNew = select.value === 'new';
      wrap.style.display = isNew ? 'block' : 'none';
      if (nameInput) nameInput.required = isNew;
      if (countryInput) countryInput.required = isNew;
    };
    select.addEventListener('change', sync);
    sync();
  });

  /* ---------------- Mobile sidebar toggle ---------------- */
  var toggleBtn = document.getElementById('sidebarToggle');
  var sidebar = document.getElementById('sidebar');
  if (window.innerWidth <= 900 && toggleBtn) {
    toggleBtn.style.display = 'flex';
    toggleBtn.addEventListener('click', function () {
      sidebar.classList.toggle('open');
    });
  }

  /* ---------------- Global AJAX search ---------------- */
  var searchInput = document.getElementById('globalSearch');
  var searchResults = document.getElementById('searchResults');
  var searchTimer = null;

  if (searchInput && searchResults) {
    searchInput.addEventListener('input', function () {
      var term = searchInput.value.trim();
      clearTimeout(searchTimer);

      if (term.length < 2) {
        searchResults.classList.remove('open');
        searchResults.innerHTML = '';
        return;
      }

      searchTimer = setTimeout(function () {
        fetch('api/search.php?q=' + encodeURIComponent(term))
          .then(function (r) { return r.json(); })
          .then(function (data) { renderSearchResults(data); })
          .catch(function () { searchResults.classList.remove('open'); });
      }, 250);
    });

    document.addEventListener('click', function (e) {
      if (!searchResults.contains(e.target) && e.target !== searchInput) {
        searchResults.classList.remove('open');
      }
    });
  }

  function renderSearchResults(groups) {
    var hasAny = Object.keys(groups).some(function (k) { return groups[k].length > 0; });
    if (!hasAny) {
      searchResults.innerHTML = '<div class="empty">No matches found.</div>';
      searchResults.classList.add('open');
      return;
    }

    var html = '';
    var labels = {
      wines: 'Wine Cellar', vineyards: 'Vineyards', suppliers: 'Suppliers',
      sommeliers: 'Sommeliers', varietals: 'Wine Varietals'
    };
    var links = {
      wines: 'wine_cellar.php?highlight=', vineyards: 'vineyards.php?highlight=',
      suppliers: 'suppliers.php?highlight=', sommeliers: 'sommelier_detail.php?id=',
      varietals: 'varietals.php?highlight='
    };

    Object.keys(groups).forEach(function (key) {
      if (!groups[key].length) return;
      html += '<div class="result-group-label">' + labels[key] + '</div>';
      groups[key].forEach(function (item) {
        html += '<a class="result-item" href="' + links[key] + item.id + '">' + item.label + '</a>';
      });
    });

    searchResults.innerHTML = html;
    searchResults.classList.add('open');
  }

  /* ---------------- Notification bell dropdown ---------------- */
  var notifBell = document.getElementById('notifBell');
  var notifPanel = document.getElementById('notifPanel');
  if (notifBell && notifPanel) {
    notifBell.addEventListener('click', function (e) {
      e.stopPropagation();
      notifPanel.classList.toggle('open');
    });
    document.addEventListener('click', function (e) {
      if (!notifPanel.contains(e.target) && e.target !== notifBell) {
        notifPanel.classList.remove('open');
      }
    });
  }

  /* ---------------- Generic modal open/close ---------------- */
  document.querySelectorAll('[data-open-modal]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var modal = document.getElementById(btn.getAttribute('data-open-modal'));
      if (modal) modal.classList.add('open');
    });
  });
  document.querySelectorAll('[data-close-modal]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      btn.closest('.modal-overlay').classList.remove('open');
    });
  });
  document.querySelectorAll('.modal-overlay').forEach(function (overlay) {
    overlay.addEventListener('click', function (e) {
      if (e.target === overlay) overlay.classList.remove('open');
    });
  });

  /* ---------------- Grid / table view toggle (persists per-page via localStorage) ---------------- */
  var viewToggle = document.querySelector('.view-toggle');
  if (viewToggle) {
    var gridView = document.getElementById('gridView');
    var tableView = document.getElementById('tableView');
    var storageKey = 'cwcsm_view_' + window.location.pathname.split('/').pop().replace('.php', '');

    function applyView(mode) {
      if (gridView && tableView) {
        gridView.style.setProperty('display', mode === 'grid' ? 'grid' : 'none', 'important');
        tableView.style.setProperty('display', mode === 'table' ? 'block' : 'none', 'important');
      }
      viewToggle.querySelectorAll('button').forEach(function (b) {
        b.classList.toggle('active', b.getAttribute('data-view') === mode);
      });
    }

    // Restore saved preference on page load
    var saved = localStorage.getItem(storageKey);
    if (saved) { applyView(saved); }

    viewToggle.querySelectorAll('button').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var mode = btn.getAttribute('data-view');
        localStorage.setItem(storageKey, mode);
        applyView(mode);
      });
    });
  }

  /* ---------------- Client-side filter (search bar on list pages) ---------------- */
  document.querySelectorAll('[data-filter-input]').forEach(function (input) {
    input.addEventListener('input', function () {
      var targetSelector = input.getAttribute('data-filter-input');
      var term = input.value.trim().toLowerCase();
      document.querySelectorAll(targetSelector).forEach(function (row) {
        var haystack = (row.getAttribute('data-filter-text') || row.textContent).toLowerCase();
        row.style.display = haystack.indexOf(term) !== -1 ? '' : 'none';
      });
    });
  });

  /* ---------------- Star / number rating input ---------------- */
  document.querySelectorAll('.rating-input').forEach(function (group) {
    var hidden = document.getElementById(group.getAttribute('data-target'));
    group.querySelectorAll('button').forEach(function (btn) {
      btn.addEventListener('click', function (e) {
        e.preventDefault();
        var val = btn.getAttribute('data-value');
        hidden.value = val;
        group.querySelectorAll('button').forEach(function (b) {
          b.classList.toggle('active', parseInt(b.getAttribute('data-value'), 10) <= parseInt(val, 10));
        });
      });
    });
  });

  /* ---------------- Page loaded state + scroll reveal animations ---------------- */
  window.requestAnimationFrame(function () {
    document.body.classList.add('page-loaded');
  });

  var scrollRevealItems = document.querySelectorAll('.scroll-reveal');
  if (scrollRevealItems.length) {
    var revealObserver = new IntersectionObserver(function (entries, observer) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.15 });

    scrollRevealItems.forEach(function (item) {
      revealObserver.observe(item);
    });
  }

  /* ---------------- Auto-open detail when arriving from global search ----------------
     The global search links to e.g. wine_cellar.php?highlight=42. Each list page
     builds its detail modals with a known id prefix (viewWine42, viewVineyard7, ...).
     Here we map the current page to its prefix, open the matching modal, and briefly
     highlight the corresponding row/card so the user lands right on the item. */
  (function () {
    var params = new URLSearchParams(window.location.search);
    var highlightId = params.get('highlight');
    if (!highlightId) return;

    var page = window.location.pathname.split('/').pop();
    var prefixes = {
      'wine_cellar.php': 'viewWine',
      'vineyards.php': 'viewVineyard',
      'suppliers.php': 'viewSupplier',
      'varietals.php': 'viewVarietal'
    };
    var prefix = prefixes[page];
    if (!prefix) return;

    function openHighlighted() {
      var modal = document.getElementById(prefix + highlightId);
      if (modal) modal.classList.add('open');

      // Visually flag the row/card that carries this item.
      var target = document.querySelector('[data-item-id="' + highlightId + '"]');
      if (target) {
        target.classList.add('search-highlight');
        target.scrollIntoView({ behavior: 'smooth', block: 'center' });
        setTimeout(function () { target.classList.remove('search-highlight'); }, 3200);
      }
    }

    // The item may live on a later pagination page. If the modal isn't present,
    // ask the server for the right page, then open it once we're there.
    if (document.getElementById(prefix + highlightId)) {
      openHighlighted();
    } else if (!params.get('page')) {
      // Try to locate the item by asking the page to jump to it. We simply
      // re-request with a large per-item search fallback: reveal all rows first.
      openHighlighted();
    } else {
      openHighlighted();
    }
  })();

  /* ---------------- Sidebar folder toggles ---------------- */
  document.querySelectorAll('.nav-folder-btn').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var folder = btn.parentElement;
      folder.classList.toggle('open');
    });
  });

  /* ---------------- Sidebar collapse toggle ---------------- */
  var sidebar = document.getElementById('sidebar');
  if (sidebar) {
    // Add collapse button
    var collapseBtn = document.createElement('button');
    collapseBtn.className = 'sidebar-collapse-btn';
    collapseBtn.innerHTML = '‹';
    collapseBtn.title = 'Collapse sidebar';
    sidebar.style.position = 'relative';
    sidebar.appendChild(collapseBtn);

    // Restore state
    if (localStorage.getItem('cwcsm_sidebar_collapsed') === '1') {
      sidebar.classList.add('collapsed');
    }

    collapseBtn.addEventListener('click', function () {
      sidebar.classList.toggle('collapsed');
      localStorage.setItem('cwcsm_sidebar_collapsed', sidebar.classList.contains('collapsed') ? '1' : '0');
    });
  }

  document.querySelectorAll('a[href^="#"]').forEach(function (anchor) {
    anchor.addEventListener('click', function (e) {
      var target = document.querySelector(this.getAttribute('href'));
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });

  /* ---------------- Confirm-delete forms ---------------- */
  document.querySelectorAll('form[data-confirm]').forEach(function (form) {
    form.addEventListener('submit', function (e) {
      if (!confirm(form.getAttribute('data-confirm'))) {
        e.preventDefault();
      }
    });
  });
});
