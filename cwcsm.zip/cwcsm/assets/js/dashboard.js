/* CWCSM - dashboard.js: fetches api/chart_data.php and renders the 4 dashboard charts */

document.addEventListener('DOMContentLoaded', function () {
  var palette = ['#7e00436f', '#e336cf6f', '#8e1db382', '#ababab', '#969696', '#7f7f7f', '#686868', '#505050'];

  fetch('api/chart_data.php')
    .then(function (r) { return r.json(); })
    .then(function (data) {
      renderBar('inventoryByVineyardChart', data.inventoryByVineyard, 'Inventory Value ($)');
      renderPie('varietalDistributionChart', data.varietalDistribution);
      renderLine('certExpiringChart', data.certExpiring, 'Certifications Expiring');
      renderArea('monthlyNotesChart', data.monthlyNotes, 'Tasting Notes Created');
    })
    .catch(function (err) { console.error('Chart data failed to load', err); });

  function renderBar(canvasId, dataset, label) {
    var el = document.getElementById(canvasId);
    if (!el) return;
    if (!dataset.labels.length) { showEmpty(el); return; }
    new Chart(el, {
      type: 'bar',
      data: {
        labels: dataset.labels,
        datasets: [{ label: label, data: dataset.values, backgroundColor: '#7e00436f', borderRadius: 6, maxBarThickness: 42 }]
      },
      options: baseOptions()
    });
  }

  function renderPie(canvasId, dataset) {
    var el = document.getElementById(canvasId);
    if (!el) return;
    if (!dataset.labels.length) { showEmpty(el); return; }
    new Chart(el, {
      type: 'pie',
      data: { labels: dataset.labels, datasets: [{ data: dataset.values, backgroundColor: palette, borderColor: palette }] },
      options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'right', labels: { boxWidth: 12, font: { size: 11 } } } } }
    });
  }

  function renderLine(canvasId, dataset, label) {
    var el = document.getElementById(canvasId);
    if (!el) return;
    new Chart(el, {
      type: 'line',
      data: {
        labels: dataset.labels,
        datasets: [{ label: label, data: dataset.values, borderColor: '#7e00436f', backgroundColor: '#d9d9d9', tension: 0.35, pointRadius: 4 }]
      },
      options: baseOptions()
    });
  }

  function renderArea(canvasId, dataset, label) {
    var el = document.getElementById(canvasId);
    if (!el) return;
    new Chart(el, {
      type: 'line',
      data: {
        labels: dataset.labels,
        datasets: [{
          label: label, data: dataset.values, borderColor: '#e6e6e6',
          backgroundColor: 'rgba(255,255,255,0.12)', fill: true, tension: 0.35, pointRadius: 3
        }]
      },
      options: baseOptions()
    });
  }

  function baseOptions() {
    return {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: {
        x: { grid: { display: false }, ticks: { color: '#e6e6e6' } },
        y: { beginAtZero: true, grid: { color: 'rgba(255,255,255,0.08)' }, ticks: { color: '#d9d9d9' } }
      }
    };
  }

  function showEmpty(canvasEl) {
    var wrap = canvasEl.closest('.chart-card');
    if (wrap) {
      var note = document.createElement('p');
      note.style.cssText = 'color:#5c4d4f;font-size:13px;text-align:center;padding:40px 0;';
      note.textContent = 'No data available yet.';
      canvasEl.replaceWith(note);
    }
  }
});
