<?php
require_once __DIR__ . '/includes/bootstrap.php';
if (is_logged_in()) {
    redirect('dashboard.php');
}

$step = 'find'; // find -> answer -> done
$error = null;
$question = null;
$username = trim($_POST['username'] ?? $_GET['u'] ?? '');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $formAction = $_POST['form_action'] ?? '';

    if ($formAction === 'find_question') {
        $account = $username !== '' ? Account::findByUsername($username) : null;

        if (!$account || (int) $account['is_active'] === 0 || empty($account['security_question'])) {
            $error = 'We couldn\'t find a self-service reset for that username. Please contact your administrator to have your password reset from the Accounts page.';
            $step = 'find';
        } else {
            $_SESSION['pwreset_account_id'] = (int) $account['account_id'];
            $question = $account['security_question'];
            $step = 'answer';
        }
    } elseif ($formAction === 'verify_and_reset') {
        $accountId = (int) ($_SESSION['pwreset_account_id'] ?? 0);
        $account = $accountId ? Account::findById($accountId) : null;
        $answer = $_POST['security_answer'] ?? '';
        $newPassword = $_POST['new_password'] ?? '';
        $confirm = $_POST['confirm_password'] ?? '';

        if (!$account) {
            $error = 'Your session expired. Please start over.';
            $step = 'find';
        } elseif (!password_verify(strtolower(trim($answer)), $account['security_answer_hash'] ?? '')) {
            $error = 'That answer doesn\'t match what we have on file.';
            $question = $account['security_question'];
            $step = 'answer';
            $username = $account['username'];
        } elseif (strlen($newPassword) < 8) {
            $error = 'New password must be at least 8 characters.';
            $question = $account['security_question'];
            $step = 'answer';
            $username = $account['username'];
        } elseif ($newPassword !== $confirm) {
            $error = 'New password and confirmation do not match.';
            $question = $account['security_question'];
            $step = 'answer';
            $username = $account['username'];
        } else {
            Account::updatePassword($accountId, password_hash($newPassword, PASSWORD_DEFAULT));
            unset($_SESSION['pwreset_account_id']);
            $step = 'done';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Forgot Password — CWCSM</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= APP_URL ?>assets/css/style.css">
</head>
<body>
<div class="auth-shell">
  <div class="auth-panel">
    <div class="auth-panel-inner">
      <p class="logo">CWCSM</p>
      <p class="tagline">Centralized Wine Cellar and Sommelier Management</p>

      <?php if ($error): ?>
        <div class="flash flash-error" style="margin:18px 0;"><?= sanitize($error) ?></div>
      <?php endif; ?>

      <?php if ($step === 'find'): ?>
        <h3 style="margin-top:18px;">Forgot your password?</h3>
        <p class="welcome">Enter your username and we'll ask your security question.</p>
        <form method="post" action="forgot_password.php">
          <?= csrf_field() ?>
          <input type="hidden" name="form_action" value="find_question">
          <div class="field"><label>Username</label><input type="text" name="username" value="<?= sanitize($username) ?>" required autofocus></div>
          <button type="submit" class="btn btn-primary auth-submit">Continue</button>
        </form>

      <?php elseif ($step === 'answer'): ?>
        <h3 style="margin-top:18px;">Security question</h3>
        <p class="welcome"><?= sanitize($question) ?></p>
        <form method="post" action="forgot_password.php">
          <?= csrf_field() ?>
          <input type="hidden" name="form_action" value="verify_and_reset">
          <div class="field"><label>Your Answer</label><input type="text" name="security_answer" required autofocus></div>
          <div class="field"><label>New Password</label><input type="password" name="new_password" minlength="8" required></div>
          <div class="field"><label>Confirm New Password</label><input type="password" name="confirm_password" minlength="8" required></div>
          <button type="submit" class="btn btn-primary auth-submit">Reset Password</button>
        </form>

      <?php else: ?>
        <h3 style="margin-top:18px;">Password reset</h3>
        <p class="welcome">Your password has been changed. You can sign in with it now.</p>
        <a class="btn btn-primary auth-submit" href="login.php" style="display:flex;">Back to Login</a>
      <?php endif; ?>

      <p class="auth-switch"><a href="login.php">Back to Login</a></p>
    </div>
  </div>
  <div class="auth-visual">
    <span class="brand-mark">CWCSM</span>
    <div>
      <p class="quote">"A good cellar keeper always knows who to call — but here, you can reset it yourself."</p>
      <p class="meta-line">Security-question reset</p>
    </div>
  </div>
</div>
</body>
</html>