<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Access Denied — CWCSM</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= APP_URL ?>assets/css/style.css">
</head>
<body style="display:flex;align-items:center;justify-content:center;min-height:100vh;background:var(--cream, #f6f1e9);">
  <div class="card" style="max-width:420px;text-align:center;">
    <h2>403 — Access Denied</h2>
    <p style="color:#5c4d4f;">Your role doesn't have permission to view this page.</p>
    <a class="btn btn-primary" href="<?= APP_URL ?>dashboard.php" style="margin-top:12px;">Back to Dashboard</a>
  </div>
</body>
</html>
