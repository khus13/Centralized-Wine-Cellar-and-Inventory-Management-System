<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_login();
require_once __DIR__ . '/controllers/supplier_rating_controller.php'; // handles rating POSTs first
require_once __DIR__ . '/controllers/supplier_controller.php';

$pageTitle = 'Suppliers';
$showArchived = isset($_GET['archived']) && is_admin();
$allSuppliers = $showArchived ? Supplier::trashed() : Supplier::all();

$highlightId = $_GET['highlight'] ?? null;
if ($highlightId && !isset($_GET['page'])) {
    $targetPage = page_of_item($allSuppliers, 'supplier_id', $highlightId, 12);
    if ($targetPage && $targetPage > 1) {
        redirect('suppliers.php?highlight=' . urlencode($highlightId) . '&page=' . $targetPage);
    }
}

[$suppliers, $pageMeta] = paginate($allSuppliers, 12);
$vineyards = Vineyard::all();
$varietals = Varietal::all();
$canEdit = is_admin();
$missingDeps = $canEdit && (!$vineyards || !$varietals);

include __DIR__ . '/includes/header.php';
?>
<div class="page-header">
  <div><h1>Suppliers<?= $showArchived ? ' — Archived' : '' ?></h1><p class="subtitle"><?= count($allSuppliers) ?> supplier relationship<?= count($allSuppliers) === 1 ? '' : 's' ?></p></div>
  <div style="display:flex;gap:10px;">
    <?php if ($canEdit): ?><a class="btn btn-outline btn-sm" href="suppliers.php<?= $showArchived ? '' : '?archived=1' ?>"><?= icon('archive') ?> <?= $showArchived ? 'Back to Active' : 'View Archived' ?></a><?php endif; ?>
    <?php if ($canEdit && !$showArchived): ?><button class="btn btn-primary" <?= $missingDeps ? 'disabled' : '' ?> data-open-modal="addSupplierModal"><?= icon('plus') ?> Add Supplier</button><?php endif; ?>
  </div>
</div>

<?php if ($missingDeps && !$showArchived): ?>
  <div class="flash flash-info" style="margin-bottom:18px;">
    Add at least one <strong>Vineyard</strong> and <strong>Wine Varietal</strong> before adding a supplier.
    <?php if (!$vineyards): ?><a href="vineyards.php">Add a vineyard →</a><?php endif; ?>
    <?php if (!$varietals): ?> <a href="varietals.php">Add a varietal →</a><?php endif; ?>
  </div>
<?php endif; ?>

<div class="toolbar">
  <div class="filter-bar"><input type="text" placeholder="Search suppliers..." data-filter-input=".filterable-row" style="width:260px;"></div>
  <div class="view-toggle">
    <button type="button" data-view="grid"><?= icon('grid') ?> Grid</button>
    <button type="button" class="active" data-view="table"><?= icon('list') ?> Table</button>
  </div>
</div>

<?php if (!$suppliers): ?>
  <div class="empty-state card"><div class="icon"><?= icon('truck') ?></div><p><?= $showArchived ? 'No archived suppliers.' : 'No suppliers on file yet.' ?></p></div>
<?php else: ?>

<div class="entity-grid" id="gridView" style="display:none;">
  <?php foreach ($suppliers as $s): ?>
  <div class="entity-card filterable-row" data-item-id="<?= $s['supplier_id'] ?>" data-filter-text="<?= sanitize($s['supplier_contact_name'] . ' ' . $s['vineyard_name']) ?>">
    <div class="thumb"><?= icon('truck') ?></div>
    <div class="body">
      <h4><?= sanitize($s['supplier_contact_name']) ?></h4>
      <div class="meta-row"><span><?= sanitize($s['vineyard_name']) ?></span><span><?= sanitize($s['varietal_name']) ?></span></div>
      <div class="meta-row"><span>Lead time: <?= (int) $s['lead_time_days'] ?> days</span></div>
      <?php $srSummary = SupplierRating::summaryForSupplier((int) $s['supplier_id']); ?>
      <?php if ($srSummary['count'] > 0): ?><div class="meta-row"><span><?= avg_stars($srSummary['avg'], $srSummary['count']) ?></span></div><?php endif; ?>
    </div>
    <div class="footer-actions">
      <button class="btn btn-outline btn-sm" data-open-modal="viewSupplier<?= $s['supplier_id'] ?>">View</button>
      <?php if ($canEdit && !$showArchived): ?>
        <button class="btn btn-outline btn-sm" data-open-modal="editSupplier<?= $s['supplier_id'] ?>"><?= icon('edit') ?> Edit</button>
        <form method="post" action="suppliers.php" data-confirm="Archive this supplier?"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="supplier_id" value="<?= $s['supplier_id'] ?>"><button type="submit" class="btn btn-danger btn-sm"><?= icon('archive') ?> Archive</button></form>
      <?php elseif ($canEdit && $showArchived): ?>
        <form method="post" action="suppliers.php"><?= csrf_field() ?><input type="hidden" name="action" value="restore"><input type="hidden" name="supplier_id" value="<?= $s['supplier_id'] ?>"><button type="submit" class="btn btn-outline btn-sm"><?= icon('restore') ?> Restore</button></form>
      <?php endif; ?>
    </div>
  </div>
  <?php endforeach; ?>
</div>

<div class="table-wrap" id="tableView">
  <table>
    <thead><tr><th>Contact Name</th><th>Associated Vineyard</th><th>Varietal</th><th>Lead Time</th><?php if ($canEdit): ?><th></th><?php endif; ?></tr></thead>
    <tbody>
    <?php foreach ($suppliers as $s): ?>
      <tr class="filterable-row" data-filter-text="<?= sanitize($s['supplier_contact_name'] . ' ' . $s['vineyard_name']) ?>">
        <td><?= sanitize($s['supplier_contact_name']) ?></td>
        <td><?= sanitize($s['vineyard_name']) ?></td>
        <td><?= sanitize($s['varietal_name']) ?></td>
        <td><?= (int) $s['lead_time_days'] ?> days</td>
        <?php if ($canEdit && !$showArchived): ?>
        <td class="table-actions">
          <button class="btn btn-outline btn-sm" data-open-modal="editSupplier<?= $s['supplier_id'] ?>">Edit</button>
          <form method="post" action="suppliers.php" data-confirm="Archive this supplier?">
            <?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="supplier_id" value="<?= $s['supplier_id'] ?>">
            <button type="submit" class="btn btn-danger btn-sm">Archive</button>
          </form>
        </td>
        <?php elseif ($canEdit): ?>
        <td class="table-actions">
          <form method="post" action="suppliers.php"><?= csrf_field() ?><input type="hidden" name="action" value="restore"><input type="hidden" name="supplier_id" value="<?= $s['supplier_id'] ?>"><button type="submit" class="btn btn-outline btn-sm">Restore</button></form>
        </td>
        <?php endif; ?>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>

<?php if ($canEdit && !$showArchived): foreach ($suppliers as $s): ?>
<div class="modal-overlay" id="editSupplier<?= $s['supplier_id'] ?>">
  <div class="modal">
    <div class="modal-header"><h3>Edit Supplier</h3><button class="modal-close" data-close-modal>&times;</button></div>
    <form method="post" action="suppliers.php">
      <div class="modal-body">
        <?= csrf_field() ?><input type="hidden" name="action" value="update"><input type="hidden" name="supplier_id" value="<?= $s['supplier_id'] ?>">
        <div class="field"><label>Contact Name <?= req() ?></label><input type="text" name="supplier_contact_name" value="<?= sanitize($s['supplier_contact_name']) ?>" required></div>
        <div class="field"><label>Vineyard</label><select name="vineyard_id" required><?php foreach ($vineyards as $v): ?><option value="<?= $v['vineyard_id'] ?>" <?= $v['vineyard_id'] == $s['vineyard_id'] ? 'selected' : '' ?>><?= sanitize($v['vineyard_name']) ?></option><?php endforeach; ?></select></div>
        <div class="field"><label>Varietal</label><select name="varietal_id" required><?php foreach ($varietals as $v): ?><option value="<?= $v['varietal_id'] ?>" <?= $v['varietal_id'] == $s['varietal_id'] ? 'selected' : '' ?>><?= sanitize($v['varietal_name']) ?></option><?php endforeach; ?></select></div>
        <div class="field"><label>Lead Time (days)</label><input type="number" name="lead_time_days" value="<?= (int) $s['lead_time_days'] ?>" required></div>
      </div>
      <div class="modal-footer"><button type="button" class="btn btn-outline" data-close-modal>Cancel</button><button type="submit" class="btn btn-primary">Save Changes</button></div>
    </form>
  </div>
</div>
<?php endforeach; endif; ?>

<?php // View + Rating modals for each supplier ?>
<?php foreach ($suppliers as $s): ?>
<div class="modal-overlay" id="viewSupplier<?= $s['supplier_id'] ?>">
  <div class="modal">
    <div class="modal-header"><h3><?= sanitize($s['supplier_contact_name']) ?></h3><button class="modal-close" data-close-modal>&times;</button></div>
    <div class="modal-body">
      <p><strong>Associated Vineyard:</strong> <?= sanitize($s['vineyard_name']) ?></p>
      <p><strong>Varietal:</strong> <?= sanitize($s['varietal_name']) ?></p>
      <p><strong>Lead Time:</strong> <?= (int) $s['lead_time_days'] ?> days</p>

      <?php
        $sRatings = SupplierRating::forSupplier((int) $s['supplier_id']);
        $sSummary = SupplierRating::summaryForSupplier((int) $s['supplier_id']);
      ?>
      <div class="rating-block">
        <h4>Supplier Ratings <?= $sSummary['count'] > 0 ? avg_stars($sSummary['avg'], $sSummary['count']) : '' ?></h4>
        <?php if ($sRatings): ?>
          <?php foreach ($sRatings as $sr): ?>
            <div class="rating-entry">
              <div class="who"><?= sanitize($sr['first_name'] . ' ' . $sr['last_name']) ?> — <?= star_rating((int) $sr['rating']) ?></div>
              <?php if ($sr['report']): ?><div class="report"><?= sanitize($sr['report']) ?></div><?php endif; ?>
            </div>
          <?php endforeach; ?>
        <?php else: ?>
          <p class="rating-empty">No ratings yet.</p>
        <?php endif; ?>
      </div>

      <?php if (is_cellar_manager()): ?>
        <?php $mySR = SupplierRating::forSupplierByManager((int) $s['supplier_id'], (int) current_user()['profile_id']); ?>
        <div style="margin-top:14px;padding-top:12px;border-top:1px solid var(--border-soft);">
          <h4 style="font-size:13px;text-transform:uppercase;letter-spacing:.5px;color:var(--ink-soft);margin-bottom:8px;">Your Rating</h4>
          <form method="post" action="suppliers.php" style="display:flex;flex-direction:column;gap:10px;">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="rate_supplier">
            <input type="hidden" name="supplier_id" value="<?= $s['supplier_id'] ?>">
            <div class="field">
              <label>Rating (1–5) <?= req() ?></label>
              <input type="number" name="rating" min="1" max="5" value="<?= $mySR ? (int) $mySR['rating'] : 4 ?>" required>
            </div>
            <div class="field">
              <label>Report / Notes</label>
              <textarea name="report" rows="2" placeholder="Delivery reliability, quality, communication..."><?= sanitize($mySR['report'] ?? '') ?></textarea>
            </div>
            <div style="display:flex;gap:8px;">
              <button type="submit" class="btn btn-primary btn-sm"><?= $mySR ? 'Update Rating' : 'Submit Rating' ?></button>
              <?php if ($mySR): ?>
                <form method="post" action="suppliers.php" style="display:inline;" data-confirm="Remove your rating for this supplier?">
                  <?= csrf_field() ?>
                  <input type="hidden" name="action" value="delete_supplier_rating">
                  <input type="hidden" name="supplier_id" value="<?= $s['supplier_id'] ?>">
                  <button type="submit" class="btn btn-danger btn-sm">Remove Rating</button>
                </form>
              <?php endif; ?>
            </div>
          </form>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php endforeach; ?>

<?= render_pagination($pageMeta) ?>

<?php endif; ?>

<?php if ($canEdit && !$showArchived && !$missingDeps): ?>
<div class="modal-overlay" id="addSupplierModal">
  <div class="modal">
    <div class="modal-header"><h3>Add Supplier</h3><button class="modal-close" data-close-modal>&times;</button></div>
    <form method="post" action="suppliers.php">
      <div class="modal-body">
        <?= csrf_field() ?><input type="hidden" name="action" value="create">
        <div class="field"><label>Contact Name <?= req() ?></label><input type="text" name="supplier_contact_name" required></div>
        <div class="field"><label>Vineyard</label><select name="vineyard_id" required><option value="" disabled selected>Select vineyard</option><?php foreach ($vineyards as $v): ?><option value="<?= $v['vineyard_id'] ?>"><?= sanitize($v['vineyard_name']) ?></option><?php endforeach; ?></select></div>
        <div class="field"><label>Varietal</label><select name="varietal_id" required><option value="" disabled selected>Select varietal</option><?php foreach ($varietals as $v): ?><option value="<?= $v['varietal_id'] ?>"><?= sanitize($v['varietal_name']) ?></option><?php endforeach; ?></select></div>
        <div class="field"><label>Lead Time (days)</label><input type="number" name="lead_time_days" required></div>
      </div>
      <div class="modal-footer"><button type="button" class="btn btn-outline" data-close-modal>Cancel</button><button type="submit" class="btn btn-primary">Add Supplier</button></div>
    </form>
  </div>
</div>
<?php endif; ?>

<?php include __DIR__ . '/includes/footer.php'; ?>
