<?php
/**
 * CWCSM - Supplier model
 */

class Supplier
{
    public static function all(): array
    {
        $sql = "SELECT s.*, v.vineyard_name, wv.varietal_name
                FROM supplier s
                JOIN vineyards v ON v.vineyard_id = s.vineyard_id
                JOIN wine_varietals wv ON wv.varietal_id = s.varietal_id
                WHERE s.is_deleted = 0
                ORDER BY s.supplier_contact_name";
        return getDB()->query($sql)->fetchAll();
    }

    public static function trashed(): array
    {
        $sql = "SELECT s.*, v.vineyard_name, wv.varietal_name
                FROM supplier s
                JOIN vineyards v ON v.vineyard_id = s.vineyard_id
                JOIN wine_varietals wv ON wv.varietal_id = s.varietal_id
                WHERE s.is_deleted = 1
                ORDER BY s.deleted_at DESC";
        return getDB()->query($sql)->fetchAll();
    }

    public static function findById(int $id): ?array
    {
        $stmt = getDB()->prepare(
            "SELECT s.*, v.vineyard_name, wv.varietal_name
             FROM supplier s
             JOIN vineyards v ON v.vineyard_id = s.vineyard_id
             JOIN wine_varietals wv ON wv.varietal_id = s.varietal_id
             WHERE s.supplier_id = ?"
        );
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function create(int $vineyardId, int $varietalId, string $contactName, int $leadTime): int
    {
        $stmt = getDB()->prepare(
            'INSERT INTO supplier (vineyard_id, varietal_id, supplier_contact_name, lead_time_days) VALUES (?, ?, ?, ?)'
        );
        $stmt->execute([$vineyardId, $varietalId, $contactName, $leadTime]);
        return (int) getDB()->lastInsertId();
    }

    public static function update(int $id, int $vineyardId, int $varietalId, string $contactName, int $leadTime): void
    {
        $stmt = getDB()->prepare(
            'UPDATE supplier SET vineyard_id = ?, varietal_id = ?, supplier_contact_name = ?, lead_time_days = ? WHERE supplier_id = ?'
        );
        $stmt->execute([$vineyardId, $varietalId, $contactName, $leadTime, $id]);
    }

    public static function softDelete(int $id): void
    {
        $stmt = getDB()->prepare('UPDATE supplier SET is_deleted = 1, deleted_at = NOW() WHERE supplier_id = ?');
        $stmt->execute([$id]);
    }

    public static function restore(int $id): void
    {
        $stmt = getDB()->prepare('UPDATE supplier SET is_deleted = 0, deleted_at = NULL WHERE supplier_id = ?');
        $stmt->execute([$id]);
    }

    public static function search(string $term): array
    {
        $stmt = getDB()->prepare('SELECT supplier_id, supplier_contact_name FROM supplier WHERE is_deleted = 0 AND supplier_contact_name LIKE ? LIMIT 10');
        $stmt->execute(["%$term%"]);
        return $stmt->fetchAll();
    }

    public static function count(): int
    {
        return (int) getDB()->query('SELECT COUNT(*) c FROM supplier WHERE is_deleted = 0')->fetch()['c'];
    }
}
