<?php
/**
 * CWCSM - Certification models
 * `Certification` = the catalog (certifications table)
 * `SommelierCertification` = the link table (sommelier_certifications)
 */

class Certification
{
    public static function all(): array
    {
        $sql = "SELECT c.*,
                       (SELECT COUNT(*) FROM sommelier_certifications sc WHERE sc.certification_id = c.certification_id AND sc.is_deleted = 0) AS holder_count
                FROM certifications c
                WHERE c.is_deleted = 0
                ORDER BY c.certification_name";
        return getDB()->query($sql)->fetchAll();
    }

    public static function trashed(): array
    {
        return getDB()->query('SELECT * FROM certifications WHERE is_deleted = 1 ORDER BY deleted_at DESC')->fetchAll();
    }

    public static function findById(int $id): ?array
    {
        $stmt = getDB()->prepare('SELECT * FROM certifications WHERE certification_id = ?');
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function create(string $name, string $issuingBody): int
    {
        $stmt = getDB()->prepare('INSERT INTO certifications (certification_name, issuing_body) VALUES (?, ?)');
        $stmt->execute([$name, $issuingBody]);
        return (int) getDB()->lastInsertId();
    }

    public static function update(int $id, string $name, string $issuingBody): void
    {
        $stmt = getDB()->prepare('UPDATE certifications SET certification_name = ?, issuing_body = ? WHERE certification_id = ?');
        $stmt->execute([$name, $issuingBody, $id]);
    }

    public static function softDelete(int $id): void
    {
        $stmt = getDB()->prepare('UPDATE certifications SET is_deleted = 1, deleted_at = NOW() WHERE certification_id = ?');
        $stmt->execute([$id]);
    }

    public static function restore(int $id): void
    {
        $stmt = getDB()->prepare('UPDATE certifications SET is_deleted = 0, deleted_at = NULL WHERE certification_id = ?');
        $stmt->execute([$id]);
    }

    /** Active (non-expired) certification count, for the dashboard stat card */
    public static function activeCount(): int
    {
        $sql = "SELECT COUNT(*) c FROM sommelier_certifications WHERE is_deleted = 0 AND (expiration_date IS NULL OR expiration_date >= CURDATE())";
        return (int) getDB()->query($sql)->fetch()['c'];
    }

    /** Certifications expiring within the next N days, for the dashboard line chart */
    public static function expiringSoon(int $days = 180): array
    {
        $sql = "SELECT sc.expiration_date, c.certification_name, a.first_name, a.last_name
                FROM sommelier_certifications sc
                JOIN certifications c ON c.certification_id = sc.certification_id
                JOIN sommelier s ON s.sommelier_id = sc.sommelier_id
                JOIN account a ON a.account_id = s.account_id
                WHERE sc.is_deleted = 0
                  AND sc.expiration_date IS NOT NULL
                  AND sc.expiration_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL ? DAY)
                ORDER BY sc.expiration_date";
        $stmt = getDB()->prepare($sql);
        $stmt->execute([$days]);
        return $stmt->fetchAll();
    }
}

class SommelierCertification
{
    public static function forSommelier(int $sommelierId): array
    {
        $sql = "SELECT sc.*, c.certification_name, c.issuing_body
                FROM sommelier_certifications sc
                JOIN certifications c ON c.certification_id = sc.certification_id
                WHERE sc.is_deleted = 0 AND sc.sommelier_id = ?
                ORDER BY sc.date_issued DESC";
        $stmt = getDB()->prepare($sql);
        $stmt->execute([$sommelierId]);
        return $stmt->fetchAll();
    }

    public static function findById(int $id): ?array
    {
        $stmt = getDB()->prepare(
            "SELECT sc.*, c.certification_name, c.issuing_body
             FROM sommelier_certifications sc JOIN certifications c ON c.certification_id = sc.certification_id
             WHERE sc.sommelier_certification_id = ?"
        );
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function create(int $sommelierId, int $certificationId, string $dateIssued, ?string $expiration, ?string $filePath): int
    {
        $stmt = getDB()->prepare(
            'INSERT INTO sommelier_certifications (sommelier_id, certification_id, date_issued, expiration_date, certificate_file_path)
             VALUES (?, ?, ?, ?, ?)'
        );
        $stmt->execute([$sommelierId, $certificationId, $dateIssued, $expiration, $filePath]);
        return (int) getDB()->lastInsertId();
    }

    public static function updateFile(int $id, ?string $filePath): void
    {
        $stmt = getDB()->prepare('UPDATE sommelier_certifications SET certificate_file_path = ? WHERE sommelier_certification_id = ?');
        $stmt->execute([$filePath, $id]);
    }

    public static function update(int $id, int $certificationId, string $dateIssued, ?string $expiration): void
    {
        $stmt = getDB()->prepare(
            'UPDATE sommelier_certifications SET certification_id = ?, date_issued = ?, expiration_date = ? WHERE sommelier_certification_id = ?'
        );
        $stmt->execute([$certificationId, $dateIssued, $expiration, $id]);
    }

    public static function softDelete(int $id): void
    {
        $stmt = getDB()->prepare('UPDATE sommelier_certifications SET is_deleted = 1, deleted_at = NOW() WHERE sommelier_certification_id = ?');
        $stmt->execute([$id]);
    }

    public static function restore(int $id): void
    {
        $stmt = getDB()->prepare('UPDATE sommelier_certifications SET is_deleted = 0, deleted_at = NULL WHERE sommelier_certification_id = ?');
        $stmt->execute([$id]);
    }

    public static function ownerSommelierId(int $id): ?int
    {
        $stmt = getDB()->prepare('SELECT sommelier_id FROM sommelier_certifications WHERE sommelier_certification_id = ?');
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        return $row ? (int) $row['sommelier_id'] : null;
    }
}
