<?php
/**
 * CWCSM - Sommelier model
 */

class Sommelier
{
    public static function create(int $accountId, string $hireDate): int
    {
        $stmt = getDB()->prepare('INSERT INTO sommelier (account_id, hire_date) VALUES (?, ?)');
        $stmt->execute([$accountId, $hireDate]);
        return (int) getDB()->lastInsertId();
    }

    public static function findByAccountId(int $accountId): ?array
    {
        $stmt = getDB()->prepare(
            'SELECT s.*, a.first_name, a.last_name, a.username, a.email, a.phone_number
             FROM sommelier s JOIN account a ON a.account_id = s.account_id
             WHERE s.account_id = ? LIMIT 1'
        );
        $stmt->execute([$accountId]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function findById(int $sommelierId): ?array
    {
        $stmt = getDB()->prepare(
            'SELECT s.*, a.first_name, a.last_name, a.username, a.email, a.phone_number
             FROM sommelier s JOIN account a ON a.account_id = s.account_id
             WHERE s.sommelier_id = ? LIMIT 1'
        );
        $stmt->execute([$sommelierId]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function all(): array
    {
        $sql = "SELECT s.*, a.first_name, a.last_name, a.username, a.email,
                       (SELECT COUNT(*) FROM sommelier_certifications sc WHERE sc.sommelier_id = s.sommelier_id) AS cert_count,
                       (SELECT COUNT(*) FROM tasting_notes tn WHERE tn.sommelier_id = s.sommelier_id) AS note_count
                FROM sommelier s
                JOIN account a ON a.account_id = s.account_id
                ORDER BY a.last_name, a.first_name";
        return getDB()->query($sql)->fetchAll();
    }

    public static function search(string $term): array
    {
        $stmt = getDB()->prepare(
            "SELECT s.*, a.first_name, a.last_name, a.email
             FROM sommelier s JOIN account a ON a.account_id = s.account_id
             WHERE a.first_name LIKE ? OR a.last_name LIKE ? OR a.username LIKE ?
             ORDER BY a.last_name LIMIT 10"
        );
        $like = "%$term%";
        $stmt->execute([$like, $like, $like]);
        return $stmt->fetchAll();
    }

    public static function updatePhoto(int $sommelierId, ?string $path): void
    {
        $stmt = getDB()->prepare('UPDATE sommelier SET photo_path = ? WHERE sommelier_id = ?');
        $stmt->execute([$path, $sommelierId]);
    }

    public static function count(): int
    {
        return (int) getDB()->query('SELECT COUNT(*) c FROM sommelier')->fetch()['c'];
    }
}
