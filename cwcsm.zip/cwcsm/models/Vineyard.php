<?php
/**
 * CWCSM - Vineyard model
 */

class Vineyard
{
    public static function all(): array
    {
        $sql = "SELECT v.*, r.region_name, r.country
                FROM vineyards v JOIN regions r ON r.region_id = v.region_id
                WHERE v.is_deleted = 0
                ORDER BY v.vineyard_name";
        return getDB()->query($sql)->fetchAll();
    }

    public static function trashed(): array
    {
        $sql = "SELECT v.*, r.region_name, r.country
                FROM vineyards v JOIN regions r ON r.region_id = v.region_id
                WHERE v.is_deleted = 1
                ORDER BY v.deleted_at DESC";
        return getDB()->query($sql)->fetchAll();
    }

    public static function findById(int $id): ?array
    {
        $stmt = getDB()->prepare(
            "SELECT v.*, r.region_name, r.country
             FROM vineyards v JOIN regions r ON r.region_id = v.region_id
             WHERE v.vineyard_id = ?"
        );
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function create(string $name, int $regionId, int $establishedYear, string $phone, ?string $imagePath): int
    {
        $stmt = getDB()->prepare(
            'INSERT INTO vineyards (vineyard_name, region_id, established_year, contact_phone, is_active, image_path)
             VALUES (?, ?, ?, ?, 1, ?)'
        );
        $stmt->execute([$name, $regionId, $establishedYear, $phone, $imagePath]);
        return (int) getDB()->lastInsertId();
    }

    public static function update(int $id, string $name, int $regionId, int $establishedYear, string $phone, int $isActive): void
    {
        $stmt = getDB()->prepare(
            'UPDATE vineyards SET vineyard_name = ?, region_id = ?, established_year = ?, contact_phone = ?, is_active = ? WHERE vineyard_id = ?'
        );
        $stmt->execute([$name, $regionId, $establishedYear, $phone, $isActive, $id]);
    }

    public static function updateImage(int $id, ?string $imagePath): void
    {
        $stmt = getDB()->prepare('UPDATE vineyards SET image_path = ? WHERE vineyard_id = ?');
        $stmt->execute([$imagePath, $id]);
    }

    public static function softDelete(int $id): void
    {
        $stmt = getDB()->prepare('UPDATE vineyards SET is_deleted = 1, deleted_at = NOW() WHERE vineyard_id = ?');
        $stmt->execute([$id]);
    }

    public static function restore(int $id): void
    {
        $stmt = getDB()->prepare('UPDATE vineyards SET is_deleted = 0, deleted_at = NULL WHERE vineyard_id = ?');
        $stmt->execute([$id]);
    }

    public static function search(string $term): array
    {
        $stmt = getDB()->prepare('SELECT vineyard_id, vineyard_name FROM vineyards WHERE is_deleted = 0 AND vineyard_name LIKE ? LIMIT 10');
        $stmt->execute(["%$term%"]);
        return $stmt->fetchAll();
    }

    public static function count(): int
    {
        return (int) getDB()->query('SELECT COUNT(*) c FROM vineyards WHERE is_deleted = 0')->fetch()['c'];
    }
}
