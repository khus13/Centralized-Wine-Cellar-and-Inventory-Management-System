<?php
/**
 * CWCSM - Account model
 * Wraps the `account` table plus role lookups across admin / sommelier / cellar_manager.
 */

class Account
{
    public static function findByUsername(string $username): ?array
    {
        $stmt = getDB()->prepare('SELECT * FROM account WHERE username = ? LIMIT 1');
        $stmt->execute([$username]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function findByEmail(string $email): ?array
    {
        $stmt = getDB()->prepare('SELECT * FROM account WHERE email = ? LIMIT 1');
        $stmt->execute([$email]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function findById(int $id): ?array
    {
        $stmt = getDB()->prepare('SELECT * FROM account WHERE account_id = ? LIMIT 1');
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function create(string $first, string $last, string $username, string $passwordHash, string $email, string $phone, string $securityQuestion = '', string $securityAnswerHash = ''): int
    {
        $stmt = getDB()->prepare(
            'INSERT INTO account (first_name, last_name, username, password, email, phone_number, security_question, security_answer_hash)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
        );
        $stmt->execute([$first, $last, $username, $passwordHash, $email, $phone, $securityQuestion, $securityAnswerHash]);
        return (int) getDB()->lastInsertId();
    }

    public static function updateProfile(int $accountId, string $first, string $last, string $email, string $phone): void
    {
        $stmt = getDB()->prepare(
            'UPDATE account SET first_name = ?, last_name = ?, email = ?, phone_number = ? WHERE account_id = ?'
        );
        $stmt->execute([$first, $last, $email, $phone, $accountId]);
    }

    public static function updatePassword(int $accountId, string $passwordHash): void
    {
        $stmt = getDB()->prepare('UPDATE account SET password = ? WHERE account_id = ?');
        $stmt->execute([$passwordHash, $accountId]);
    }

    public static function updatePhoto(int $accountId, ?string $photoPath): void
    {
        $stmt = getDB()->prepare('UPDATE account SET photo_path = ? WHERE account_id = ?');
        $stmt->execute([$photoPath, $accountId]);
    }

    /** Soft-delete: blocks login, keeps every linked record (wines, notes, certs...) intact. */
    public static function deactivate(int $accountId): void
    {
        $stmt = getDB()->prepare('UPDATE account SET is_active = 0 WHERE account_id = ?');
        $stmt->execute([$accountId]);
    }

    public static function activate(int $accountId): void
    {
        $stmt = getDB()->prepare('UPDATE account SET is_active = 1 WHERE account_id = ?');
        $stmt->execute([$accountId]);
    }

    /** Alias — account_controller.php calls this name. */
    public static function reactivate(int $accountId): void
    {
        self::activate($accountId);
    }

    /** Used to block deactivating the last remaining active admin (would lock everyone out). */
    public static function activeAdminCount(): int
    {
        $sql = "SELECT COUNT(*) c FROM account a
                JOIN admin ad ON ad.account_id = a.account_id
                WHERE a.is_active = 1";
        return (int) getDB()->query($sql)->fetch()['c'];
    }

    /**
     * Returns 'admin' | 'sommelier' | 'cellar_manager' | null
     */
    public static function getRole(int $accountId): ?string
    {
        $db = getDB();

        $stmt = $db->prepare('SELECT admin_id FROM admin WHERE account_id = ?');
        $stmt->execute([$accountId]);
        if ($stmt->fetch()) {
            return 'admin';
        }

        $stmt = $db->prepare('SELECT sommelier_id FROM sommelier WHERE account_id = ?');
        $stmt->execute([$accountId]);
        if ($stmt->fetch()) {
            return 'sommelier';
        }

        $stmt = $db->prepare('SELECT manager_id FROM cellar_manager WHERE account_id = ?');
        $stmt->execute([$accountId]);
        if ($stmt->fetch()) {
            return 'cellar_manager';
        }

        return null;
    }

    /** All accounts with their resolved role, for the Admin > Accounts view */
    public static function allWithRoles(): array
    {
        $sql = "SELECT a.account_id, a.first_name, a.last_name, a.username, a.email, a.phone_number, a.is_active,
                       CASE
                           WHEN ad.admin_id IS NOT NULL THEN 'admin'
                           WHEN s.sommelier_id IS NOT NULL THEN 'sommelier'
                           WHEN cm.manager_id IS NOT NULL THEN 'cellar_manager'
                           ELSE 'unknown'
                       END AS role
                FROM account a
                LEFT JOIN admin ad ON ad.account_id = a.account_id
                LEFT JOIN sommelier s ON s.account_id = a.account_id
                LEFT JOIN cellar_manager cm ON cm.account_id = a.account_id
                ORDER BY a.last_name, a.first_name";
        return getDB()->query($sql)->fetchAll();
    }

    public static function roleCounts(): array
    {
        $db = getDB();
        return [
            'admin'          => (int) $db->query('SELECT COUNT(*) c FROM admin')->fetch()['c'],
            'sommelier'      => (int) $db->query('SELECT COUNT(*) c FROM sommelier')->fetch()['c'],
            'cellar_manager' => (int) $db->query('SELECT COUNT(*) c FROM cellar_manager')->fetch()['c'],
        ];
    }

    /**
     * Moves an account into a different role. Because the sommelier /
     * cellar_manager tables cascade-delete their dependent records
     * (tasting notes, wine ratings, supplier ratings) and inventory
     * blocks manager deletion, we guard against silent data loss:
     * the change is refused (with an explanatory message) when the
     * current role still owns linked records.
     *
     * Returns [true, null] on success or [false, 'reason'] on failure.
     *
     * @param string $newRole one of 'sommelier' | 'cellar_manager' | 'admin'
     */
    public static function changeRole(int $accountId, string $newRole): array
    {
        if (!in_array($newRole, ['sommelier', 'cellar_manager', 'admin'], true)) {
            return [false, 'Invalid role.'];
        }

        $current = self::getRole($accountId);
        if ($current === null) {
            return [false, 'This account has no current role to change.'];
        }
        if ($current === $newRole) {
            return [false, 'This account already has that role.'];
        }

        $db = getDB();

        // Look up existing role-profile ids we may need to detach.
        $sommelierId = null;
        $managerId = null;
        if ($current === 'sommelier') {
            $stmt = $db->prepare('SELECT sommelier_id FROM sommelier WHERE account_id = ?');
            $stmt->execute([$accountId]);
            $sommelierId = (int) ($stmt->fetch()['sommelier_id'] ?? 0);
        } elseif ($current === 'cellar_manager') {
            $stmt = $db->prepare('SELECT manager_id FROM cellar_manager WHERE account_id = ?');
            $stmt->execute([$accountId]);
            $managerId = (int) ($stmt->fetch()['manager_id'] ?? 0);
        }

        // Guard against destructive cascades / FK blocks.
        // We allow role changes even when the user has data — the old role
        // row will be deleted but FK-cascaded child records are preserved
        // where possible. Only block removing the final admin.
        if ($current === 'admin' && self::adminCount() <= 1) {
            return [false, 'You cannot change the role of the only remaining administrator.'];
        }

        // For cellar managers with inventory, we check FK constraint.
        if ($current === 'cellar_manager' && $managerId) {
            $bottleCount = (int) self::scalar('SELECT COUNT(*) FROM cellar_inventory WHERE manager_id = ?', [$managerId]);
            if ($bottleCount > 0) {
                return [false, 'This Cellar Manager still has inventory records linked to them. Reassign those bottles to another manager first.'];
            }
        }

        try {
            $db->beginTransaction();

            // Detach current role profile.
            if ($current === 'admin') {
                $db->prepare('DELETE FROM admin WHERE account_id = ?')->execute([$accountId]);
            } elseif ($current === 'sommelier') {
                $db->prepare('DELETE FROM sommelier WHERE account_id = ?')->execute([$accountId]);
            } elseif ($current === 'cellar_manager') {
                $db->prepare('DELETE FROM cellar_manager WHERE account_id = ?')->execute([$accountId]);
            }

            // Attach new role profile.
            if ($newRole === 'admin') {
                $db->prepare('INSERT INTO admin (account_id) VALUES (?)')->execute([$accountId]);
            } elseif ($newRole === 'sommelier') {
                $db->prepare('INSERT INTO sommelier (account_id, hire_date) VALUES (?, ?)')->execute([$accountId, date('Y-m-d')]);
            } elseif ($newRole === 'cellar_manager') {
                $db->prepare('INSERT INTO cellar_manager (account_id, hire_date) VALUES (?, ?)')->execute([$accountId, date('Y-m-d')]);
            }

            $db->commit();
            return [true, null];
        } catch (Throwable $e) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            error_log('[CWCSM] changeRole: ' . $e->getMessage());
            return [false, 'Could not change the role. Please try again.'];
        }
    }

    public static function adminCount(): int
    {
        return (int) getDB()->query('SELECT COUNT(*) c FROM admin')->fetch()['c'];
    }

    /** Tiny helper to fetch a single scalar from a prepared query. Returns 0 on error. */
    private static function scalar(string $sql, array $params = [])
    {
        try {
            $stmt = getDB()->prepare($sql);
            $stmt->execute($params);
            $row = $stmt->fetch(PDO::FETCH_NUM);
            return $row ? $row[0] : 0;
        } catch (PDOException $e) {
            return 0; // table may not exist yet
        }
    }
}