<?php
/**
 * CWCSM - Cellar Inventory model
 */

class Inventory
{
    private static function baseSelect(): string
    {
        return "SELECT ci.*, v.vineyard_name, wv.varietal_name, wv.color_type, s.supplier_contact_name,
                       a.first_name AS manager_first_name, a.last_name AS manager_last_name
                FROM cellar_inventory ci
                JOIN vineyards v ON v.vineyard_id = ci.vineyard_id
                JOIN wine_varietals wv ON wv.varietal_id = ci.varietal_id
                JOIN supplier s ON s.supplier_id = ci.supplier_id
                JOIN cellar_manager cm ON cm.manager_id = ci.manager_id
                JOIN account a ON a.account_id = cm.account_id";
    }

    public static function all(): array
    {
        return getDB()->query(self::baseSelect() . ' WHERE ci.is_deleted = 0 ORDER BY ci.bottle_id DESC')->fetchAll();
    }

    /** Archived (soft-deleted) bottles, for the admin "Archived" view */
    public static function trashed(): array
    {
        return getDB()->query(self::baseSelect() . ' WHERE ci.is_deleted = 1 ORDER BY ci.deleted_at DESC')->fetchAll();
    }

    public static function findById(int $id): ?array
    {
        $stmt = getDB()->prepare(self::baseSelect() . ' WHERE ci.bottle_id = ?');
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function search(string $term): array
    {
        $stmt = getDB()->prepare(
            self::baseSelect() . " WHERE ci.is_deleted = 0 AND (v.vineyard_name LIKE ? OR wv.varietal_name LIKE ? OR ci.storage_bin_number LIKE ?)
             ORDER BY ci.bottle_id DESC"
        );
        $like = "%$term%";
        $stmt->execute([$like, $like, $like]);
        return $stmt->fetchAll();
    }

    public static function create(
        int $vineyardId, int $varietalId, int $supplierId, int $managerId,
        int $vintageYear, string $binNumber, string $purchaseDate, float $price,
        string $status, string $lastCheckDate, ?string $imagePath = null
    ): int {
        $stmt = getDB()->prepare(
            'INSERT INTO cellar_inventory
                (vineyard_id, varietal_id, supplier_id, manager_id, vintage_year, storage_bin_number,
                 purchase_date, purchase_price, inventory_status, last_inventory_check_date, image_path)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
        );
        $stmt->execute([$vineyardId, $varietalId, $supplierId, $managerId, $vintageYear, $binNumber, $purchaseDate, $price, $status, $lastCheckDate, $imagePath]);
        return (int) getDB()->lastInsertId();
    }

    public static function update(
        int $id, int $vineyardId, int $varietalId, int $supplierId,
        int $vintageYear, string $binNumber, string $purchaseDate, float $price,
        string $status, string $lastCheckDate
    ): void {
        $stmt = getDB()->prepare(
            'UPDATE cellar_inventory SET vineyard_id = ?, varietal_id = ?, supplier_id = ?, vintage_year = ?,
                storage_bin_number = ?, purchase_date = ?, purchase_price = ?, inventory_status = ?, last_inventory_check_date = ?
             WHERE bottle_id = ?'
        );
        $stmt->execute([$vineyardId, $varietalId, $supplierId, $vintageYear, $binNumber, $purchaseDate, $price, $status, $lastCheckDate, $id]);
    }

    public static function updateImage(int $id, ?string $imagePath): void
    {
        $stmt = getDB()->prepare('UPDATE cellar_inventory SET image_path = ? WHERE bottle_id = ?');
        $stmt->execute([$imagePath, $id]);
    }

    public static function softDelete(int $id): void
    {
        $stmt = getDB()->prepare('UPDATE cellar_inventory SET is_deleted = 1, deleted_at = NOW() WHERE bottle_id = ?');
        $stmt->execute([$id]);
    }

    public static function restore(int $id): void
    {
        $stmt = getDB()->prepare('UPDATE cellar_inventory SET is_deleted = 0, deleted_at = NULL WHERE bottle_id = ?');
        $stmt->execute([$id]);
    }

    public static function totalBottleCount(): int
    {
        return (int) getDB()->query('SELECT COUNT(*) c FROM cellar_inventory WHERE is_deleted = 0')->fetch()['c'];
    }

    public static function totalInventoryCost(): float
    {
        return (float) (getDB()->query('SELECT COALESCE(SUM(purchase_price), 0) s FROM cellar_inventory WHERE is_deleted = 0')->fetch()['s'] ?? 0);
    }

    /** Inventory value grouped by vineyard, for the dashboard bar chart */
    public static function valueByVineyard(): array
    {
        $sql = "SELECT v.vineyard_name, COALESCE(SUM(ci.purchase_price), 0) AS total_value
                FROM vineyards v
                LEFT JOIN cellar_inventory ci ON ci.vineyard_id = v.vineyard_id AND ci.is_deleted = 0
                WHERE v.is_deleted = 0
                GROUP BY v.vineyard_id, v.vineyard_name
                HAVING total_value > 0
                ORDER BY total_value DESC
                LIMIT 10";
        return getDB()->query($sql)->fetchAll();
    }

    public static function search_dropdown_by_vineyard(int $vineyardId): array
    {
        $stmt = getDB()->prepare(self::baseSelect() . ' WHERE ci.is_deleted = 0 AND ci.vineyard_id = ? ORDER BY ci.bottle_id DESC');
        $stmt->execute([$vineyardId]);
        return $stmt->fetchAll();
    }
}
