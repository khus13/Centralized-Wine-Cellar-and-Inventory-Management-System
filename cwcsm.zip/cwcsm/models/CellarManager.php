<?php
/**
 * CWCSM - Cellar Manager model
 */

class CellarManager
{
    public static function create(int $accountId, string $hireDate): int
    {
        $stmt = getDB()->prepare('INSERT INTO cellar_manager (account_id, hire_date) VALUES (?, ?)');
        $stmt->execute([$accountId, $hireDate]);
        return (int) getDB()->lastInsertId();
    }

    public static function findByAccountId(int $accountId): ?array
    {
        $stmt = getDB()->prepare(
            'SELECT cm.*, a.first_name, a.last_name, a.username, a.email
             FROM cellar_manager cm JOIN account a ON a.account_id = cm.account_id
             WHERE cm.account_id = ? LIMIT 1'
        );
        $stmt->execute([$accountId]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function findById(int $managerId): ?array
    {
        $stmt = getDB()->prepare(
            'SELECT cm.*, a.first_name, a.last_name, a.username, a.email
             FROM cellar_manager cm JOIN account a ON a.account_id = cm.account_id
             WHERE cm.manager_id = ? LIMIT 1'
        );
        $stmt->execute([$managerId]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function all(): array
    {
        $sql = "SELECT cm.*, a.first_name, a.last_name, a.username, a.email
                FROM cellar_manager cm JOIN account a ON a.account_id = cm.account_id
                ORDER BY a.last_name, a.first_name";
        return getDB()->query($sql)->fetchAll();
    }

    public static function count(): int
    {
        return (int) getDB()->query('SELECT COUNT(*) c FROM cellar_manager')->fetch()['c'];
    }
}
