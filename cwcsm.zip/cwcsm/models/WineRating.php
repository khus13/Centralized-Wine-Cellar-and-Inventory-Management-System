<?php
/**
 * CWCSM - Wine Rating model
 * A Sommelier's overall rating (1-5) + written report for a specific bottle.
 * One row per (bottle_id, sommelier_id); "editing" upserts that row.
 */

class WineRating
{
    /** All ratings for a bottle, with the rating sommelier's name attached. */
    public static function forBottle(int $bottleId): array
    {
        $stmt = getDB()->prepare(
            "SELECT wr.*, a.first_name, a.last_name
             FROM wine_ratings wr
             JOIN sommelier s ON s.sommelier_id = wr.sommelier_id
             JOIN account a ON a.account_id = s.account_id
             WHERE wr.bottle_id = ?
             ORDER BY wr.updated_at DESC"
        );
        $stmt->execute([$bottleId]);
        return $stmt->fetchAll();
    }

    /** A single sommelier's rating for a bottle (or null). */
    public static function forBottleBySommelier(int $bottleId, int $sommelierId): ?array
    {
        $stmt = getDB()->prepare('SELECT * FROM wine_ratings WHERE bottle_id = ? AND sommelier_id = ? LIMIT 1');
        $stmt->execute([$bottleId, $sommelierId]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    /** All ratings a sommelier has left, newest first, with wine info. */
    public static function bySommelier(int $sommelierId): array
    {
        $stmt = getDB()->prepare(
            "SELECT wr.*, v.vineyard_name, wv.varietal_name, wv.varietal_id, ci.vintage_year
             FROM wine_ratings wr
             JOIN cellar_inventory ci ON ci.bottle_id = wr.bottle_id
             JOIN vineyards v ON v.vineyard_id = ci.vineyard_id
             JOIN wine_varietals wv ON wv.varietal_id = ci.varietal_id
             WHERE wr.sommelier_id = ?
             ORDER BY wr.updated_at DESC"
        );
        $stmt->execute([$sommelierId]);
        return $stmt->fetchAll();
    }

    /** Insert or update a sommelier's rating for a bottle. */
    public static function upsert(int $bottleId, int $sommelierId, int $rating, ?string $report): void
    {
        $stmt = getDB()->prepare(
            'INSERT INTO wine_ratings (bottle_id, sommelier_id, rating, report)
             VALUES (?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE rating = VALUES(rating), report = VALUES(report)'
        );
        $stmt->execute([$bottleId, $sommelierId, $rating, $report]);
    }

    public static function delete(int $bottleId, int $sommelierId): void
    {
        $stmt = getDB()->prepare('DELETE FROM wine_ratings WHERE bottle_id = ? AND sommelier_id = ?');
        $stmt->execute([$bottleId, $sommelierId]);
    }

    /** Average rating + number of raters for one bottle. */
    public static function summaryForBottle(int $bottleId): array
    {
        $stmt = getDB()->prepare('SELECT COALESCE(AVG(rating),0) avg_rating, COUNT(*) rater_count FROM wine_ratings WHERE bottle_id = ?');
        $stmt->execute([$bottleId]);
        $row = $stmt->fetch();
        return ['avg' => (float) $row['avg_rating'], 'count' => (int) $row['rater_count']];
    }

    /**
     * Best / worst performing wines across the cellar, for the admin
     * overview. $direction is 'top' or 'bottom'.
     */
    public static function performing(string $direction = 'top', int $limit = 5): array
    {
        $order = $direction === 'bottom' ? 'ASC' : 'DESC';
        $sql = "SELECT ci.bottle_id, v.vineyard_name, wv.varietal_name, ci.vintage_year,
                       AVG(wr.rating) AS avg_rating, COUNT(*) AS rater_count
                FROM wine_ratings wr
                JOIN cellar_inventory ci ON ci.bottle_id = wr.bottle_id
                JOIN vineyards v ON v.vineyard_id = ci.vineyard_id
                JOIN wine_varietals wv ON wv.varietal_id = ci.varietal_id
                WHERE ci.is_deleted = 0
                GROUP BY ci.bottle_id, v.vineyard_name, wv.varietal_name, ci.vintage_year
                ORDER BY avg_rating $order, rater_count DESC
                LIMIT " . (int) $limit;
        return getDB()->query($sql)->fetchAll();
    }

    /**
     * Recommendation engine: given the varietals a sommelier has rated
     * (especially highly), suggest other in-stock bottles of the same
     * varietal they have NOT rated yet.
     */
    public static function recommendationsForSommelier(int $sommelierId, int $limit = 6): array
    {
        $sql = "SELECT ci.bottle_id, v.vineyard_name, wv.varietal_name, ci.vintage_year,
                       (SELECT COALESCE(AVG(r2.rating),0) FROM wine_ratings r2 WHERE r2.bottle_id = ci.bottle_id) AS avg_rating,
                       (SELECT COUNT(*) FROM wine_ratings r3 WHERE r3.bottle_id = ci.bottle_id) AS rater_count
                FROM cellar_inventory ci
                JOIN vineyards v ON v.vineyard_id = ci.vineyard_id
                JOIN wine_varietals wv ON wv.varietal_id = ci.varietal_id
                WHERE ci.is_deleted = 0
                  AND ci.varietal_id IN (
                        SELECT DISTINCT ci2.varietal_id
                        FROM wine_ratings wr
                        JOIN cellar_inventory ci2 ON ci2.bottle_id = wr.bottle_id
                        WHERE wr.sommelier_id = ? AND wr.rating >= 4
                  )
                  AND ci.bottle_id NOT IN (
                        SELECT bottle_id FROM wine_ratings WHERE sommelier_id = ?
                  )
                ORDER BY avg_rating DESC, ci.created_at DESC
                LIMIT " . (int) $limit;
        $stmt = getDB()->prepare($sql);
        $stmt->execute([$sommelierId, $sommelierId]);
        return $stmt->fetchAll();
    }
}
