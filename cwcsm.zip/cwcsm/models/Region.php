<?php
/**
 * CWCSM - Region model (supports the Vineyards module)
 */

class Region
{
    public static function all(): array
    {
        return getDB()->query('SELECT * FROM regions ORDER BY country, region_name')->fetchAll();
    }

    public static function findById(int $id): ?array
    {
        $stmt = getDB()->prepare('SELECT * FROM regions WHERE region_id = ?');
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function create(string $name, string $country): int
    {
        $stmt = getDB()->prepare('INSERT INTO regions (region_name, country) VALUES (?, ?)');
        $stmt->execute([$name, $country]);
        return (int) getDB()->lastInsertId();
    }
}
