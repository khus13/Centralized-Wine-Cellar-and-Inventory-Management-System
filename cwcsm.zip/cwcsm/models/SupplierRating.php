<?php
/**
 * CWCSM - Supplier Rating model
 * A Cellar Manager's rating (1-5) + written report for a supplier.
 * One row per (supplier_id, manager_id); "editing" upserts that row.
 */

class SupplierRating
{
    /** All ratings for a supplier, with the rating manager's name attached. */
    public static function forSupplier(int $supplierId): array
    {
        $stmt = getDB()->prepare(
            "SELECT sr.*, a.first_name, a.last_name
             FROM supplier_ratings sr
             JOIN cellar_manager cm ON cm.manager_id = sr.manager_id
             JOIN account a ON a.account_id = cm.account_id
             WHERE sr.supplier_id = ?
             ORDER BY sr.updated_at DESC"
        );
        $stmt->execute([$supplierId]);
        return $stmt->fetchAll();
    }

    /** A single manager's rating for a supplier (or null). */
    public static function forSupplierByManager(int $supplierId, int $managerId): ?array
    {
        $stmt = getDB()->prepare('SELECT * FROM supplier_ratings WHERE supplier_id = ? AND manager_id = ? LIMIT 1');
        $stmt->execute([$supplierId, $managerId]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    /** Insert or update a manager's rating for a supplier. */
    public static function upsert(int $supplierId, int $managerId, int $rating, ?string $report): void
    {
        $stmt = getDB()->prepare(
            'INSERT INTO supplier_ratings (supplier_id, manager_id, rating, report)
             VALUES (?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE rating = VALUES(rating), report = VALUES(report)'
        );
        $stmt->execute([$supplierId, $managerId, $rating, $report]);
    }

    public static function delete(int $supplierId, int $managerId): void
    {
        $stmt = getDB()->prepare('DELETE FROM supplier_ratings WHERE supplier_id = ? AND manager_id = ?');
        $stmt->execute([$supplierId, $managerId]);
    }

    /** Average rating + rater count for one supplier. */
    public static function summaryForSupplier(int $supplierId): array
    {
        $stmt = getDB()->prepare('SELECT COALESCE(AVG(rating),0) avg_rating, COUNT(*) rater_count FROM supplier_ratings WHERE supplier_id = ?');
        $stmt->execute([$supplierId]);
        $row = $stmt->fetch();
        return ['avg' => (float) $row['avg_rating'], 'count' => (int) $row['rater_count']];
    }

    /** Best / worst performing suppliers, for the admin overview. */
    public static function performing(string $direction = 'top', int $limit = 5): array
    {
        $order = $direction === 'bottom' ? 'ASC' : 'DESC';
        $sql = "SELECT s.supplier_id, s.supplier_contact_name, v.vineyard_name,
                       AVG(sr.rating) AS avg_rating, COUNT(*) AS rater_count
                FROM supplier_ratings sr
                JOIN supplier s ON s.supplier_id = sr.supplier_id
                JOIN vineyards v ON v.vineyard_id = s.vineyard_id
                WHERE s.is_deleted = 0
                GROUP BY s.supplier_id, s.supplier_contact_name, v.vineyard_name
                ORDER BY avg_rating $order, rater_count DESC
                LIMIT " . (int) $limit;
        return getDB()->query($sql)->fetchAll();
    }
}
