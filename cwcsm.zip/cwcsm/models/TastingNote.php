<?php
/**
 * CWCSM - Tasting Notes model
 */

class TastingNote
{
    private static function baseSelect(): string
    {
        return "SELECT tn.*, v.vineyard_name, wv.varietal_name, ci.vintage_year,
                       a.first_name AS sommelier_first_name, a.last_name AS sommelier_last_name
                FROM tasting_notes tn
                JOIN cellar_inventory ci ON ci.bottle_id = tn.bottle_id
                JOIN vineyards v ON v.vineyard_id = ci.vineyard_id
                JOIN wine_varietals wv ON wv.varietal_id = ci.varietal_id
                JOIN sommelier s ON s.sommelier_id = tn.sommelier_id
                JOIN account a ON a.account_id = s.account_id";
    }

    public static function all(): array
    {
        return getDB()->query(self::baseSelect() . ' WHERE tn.is_deleted = 0 ORDER BY tn.tasting_date DESC')->fetchAll();
    }

    public static function trashed(): array
    {
        return getDB()->query(self::baseSelect() . ' WHERE tn.is_deleted = 1 ORDER BY tn.deleted_at DESC')->fetchAll();
    }

    public static function findById(int $id): ?array
    {
        $stmt = getDB()->prepare(self::baseSelect() . ' WHERE tn.note_id = ?');
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function bySommelier(int $sommelierId): array
    {
        $stmt = getDB()->prepare(self::baseSelect() . ' WHERE tn.is_deleted = 0 AND tn.sommelier_id = ? ORDER BY tn.tasting_date DESC');
        $stmt->execute([$sommelierId]);
        return $stmt->fetchAll();
    }

    public static function create(
        int $bottleId, int $sommelierId, string $tastingDate, string $aroma, string $flavor,
        int $body, int $acidity, int $tannin, int $peakStart, int $peakEnd, ?string $remarks = null
    ): int {
        $stmt = getDB()->prepare(
            'INSERT INTO tasting_notes
                (bottle_id, sommelier_id, tasting_date, aroma_notes, flavor_notes, remarks, body_rating, acidity_rating, tannin_rating, peak_drinking_start_year, peak_drinking_end_year)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
        );
        $stmt->execute([$bottleId, $sommelierId, $tastingDate, $aroma, $flavor, $remarks, $body, $acidity, $tannin, $peakStart, $peakEnd]);
        return (int) getDB()->lastInsertId();
    }

    public static function update(
        int $id, int $bottleId, string $tastingDate, string $aroma, string $flavor,
        int $body, int $acidity, int $tannin, int $peakStart, int $peakEnd, ?string $remarks = null
    ): void {
        $stmt = getDB()->prepare(
            'UPDATE tasting_notes SET bottle_id = ?, tasting_date = ?, aroma_notes = ?, flavor_notes = ?, remarks = ?,
                body_rating = ?, acidity_rating = ?, tannin_rating = ?, peak_drinking_start_year = ?, peak_drinking_end_year = ?
             WHERE note_id = ?'
        );
        $stmt->execute([$bottleId, $tastingDate, $aroma, $flavor, $remarks, $body, $acidity, $tannin, $peakStart, $peakEnd, $id]);
    }

    public static function softDelete(int $id): void
    {
        $stmt = getDB()->prepare('UPDATE tasting_notes SET is_deleted = 1, deleted_at = NOW() WHERE note_id = ?');
        $stmt->execute([$id]);
    }

    public static function restore(int $id): void
    {
        $stmt = getDB()->prepare('UPDATE tasting_notes SET is_deleted = 0, deleted_at = NULL WHERE note_id = ?');
        $stmt->execute([$id]);
    }

    public static function ownerSommelierId(int $noteId): ?int
    {
        $stmt = getDB()->prepare('SELECT sommelier_id FROM tasting_notes WHERE note_id = ?');
        $stmt->execute([$noteId]);
        $row = $stmt->fetch();
        return $row ? (int) $row['sommelier_id'] : null;
    }

    /** Monthly counts of tasting notes created, for the dashboard area chart (last 6 months) */
    public static function monthlyCounts(int $months = 6): array
    {
        $sql = "SELECT DATE_FORMAT(tasting_date, '%Y-%m') AS ym, COUNT(*) AS note_count
                FROM tasting_notes
                WHERE is_deleted = 0 AND tasting_date >= DATE_SUB(CURDATE(), INTERVAL ? MONTH)
                GROUP BY ym
                ORDER BY ym";
        $stmt = getDB()->prepare($sql);
        $stmt->execute([$months]);
        return $stmt->fetchAll();
    }

    public static function countForBottle(int $bottleId): int
    {
        $stmt = getDB()->prepare('SELECT COUNT(*) c FROM tasting_notes WHERE bottle_id = ? AND is_deleted = 0');
        $stmt->execute([$bottleId]);
        return (int) $stmt->fetch()['c'];
    }
}
