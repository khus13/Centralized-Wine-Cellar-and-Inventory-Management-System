<?php
/**
 * CWCSM - Login Audit model (login_log table)
 */

class LoginAudit
{
    public static function recordLogin(int $accountId, string $status): int
    {
        $stmt = getDB()->prepare(
            'INSERT INTO login_log (account_id, login_time, login_status) VALUES (?, NOW(), ?)'
        );
        $stmt->execute([$accountId, $status]);
        return (int) getDB()->lastInsertId();
    }

    public static function recordLogout(int $loginId): void
    {
        $stmt = getDB()->prepare('UPDATE login_log SET logout_time = NOW() WHERE login_id = ?');
        $stmt->execute([$loginId]);
    }

    public static function all(array $filters = []): array
    {
        $sql = "SELECT ll.*, a.username, a.first_name, a.last_name,
                       CASE
                           WHEN ad.admin_id IS NOT NULL THEN 'admin'
                           WHEN s.sommelier_id IS NOT NULL THEN 'sommelier'
                           WHEN cm.manager_id IS NOT NULL THEN 'cellar_manager'
                           ELSE 'unknown'
                       END AS role
                FROM login_log ll
                JOIN account a ON a.account_id = ll.account_id
                LEFT JOIN admin ad ON ad.account_id = a.account_id
                LEFT JOIN sommelier s ON s.account_id = a.account_id
                LEFT JOIN cellar_manager cm ON cm.account_id = a.account_id
                WHERE 1=1";
        $params = [];

        if (!empty($filters['date'])) {
            $sql .= ' AND DATE(ll.login_time) = ?';
            $params[] = $filters['date'];
        }
        if (!empty($filters['username'])) {
            $sql .= ' AND a.username LIKE ?';
            $params[] = '%' . $filters['username'] . '%';
        }
        if (!empty($filters['role'])) {
            $sql .= ' HAVING role = ?';
            $params[] = $filters['role'];
        }

        $sql .= ' ORDER BY ll.login_time DESC LIMIT 500';

        $stmt = getDB()->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }
}
