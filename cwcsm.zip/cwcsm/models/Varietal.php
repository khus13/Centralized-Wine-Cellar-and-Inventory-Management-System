<?php
/**
 * CWCSM - Wine Varietal model
 */

class Varietal
{
    public static function all(): array
    {
        return getDB()->query('SELECT * FROM wine_varietals WHERE is_deleted = 0 ORDER BY varietal_name')->fetchAll();
    }

    public static function trashed(): array
    {
        return getDB()->query('SELECT * FROM wine_varietals WHERE is_deleted = 1 ORDER BY deleted_at DESC')->fetchAll();
    }

    public static function findById(int $id): ?array
    {
        $stmt = getDB()->prepare('SELECT * FROM wine_varietals WHERE varietal_id = ?');
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function create(string $name, string $color, int $minAge, int $maxAge, string $pairing, float $temp): int
    {
        $stmt = getDB()->prepare(
            'INSERT INTO wine_varietals (varietal_name, color_type, min_typical_aging_yrs, max_typical_aging_yrs, food_pairing_template, entry_temperature_celsius)
             VALUES (?, ?, ?, ?, ?, ?)'
        );
        $stmt->execute([$name, $color, $minAge, $maxAge, $pairing, $temp]);
        return (int) getDB()->lastInsertId();
    }

    public static function update(int $id, string $name, string $color, int $minAge, int $maxAge, string $pairing, float $temp): void
    {
        $stmt = getDB()->prepare(
            'UPDATE wine_varietals SET varietal_name = ?, color_type = ?, min_typical_aging_yrs = ?, max_typical_aging_yrs = ?, food_pairing_template = ?, entry_temperature_celsius = ?
             WHERE varietal_id = ?'
        );
        $stmt->execute([$name, $color, $minAge, $maxAge, $pairing, $temp, $id]);
    }

    public static function updateImage(int $id, ?string $path): void
    {
        $stmt = getDB()->prepare('UPDATE wine_varietals SET image_path = ? WHERE varietal_id = ?');
        $stmt->execute([$path, $id]);
    }

    public static function softDelete(int $id): void
    {
        $stmt = getDB()->prepare('UPDATE wine_varietals SET is_deleted = 1, deleted_at = NOW() WHERE varietal_id = ?');
        $stmt->execute([$id]);
    }

    public static function restore(int $id): void
    {
        $stmt = getDB()->prepare('UPDATE wine_varietals SET is_deleted = 0, deleted_at = NULL WHERE varietal_id = ?');
        $stmt->execute([$id]);
    }

    public static function search(string $term): array
    {
        $stmt = getDB()->prepare('SELECT varietal_id, varietal_name FROM wine_varietals WHERE is_deleted = 0 AND varietal_name LIKE ? LIMIT 10');
        $stmt->execute(["%$term%"]);
        return $stmt->fetchAll();
    }

    /** distribution of bottle counts by varietal, for dashboard pie chart */
    public static function distributionCounts(): array
    {
        $sql = "SELECT wv.varietal_name, COUNT(ci.bottle_id) AS bottle_count
                FROM wine_varietals wv
                LEFT JOIN cellar_inventory ci ON ci.varietal_id = wv.varietal_id AND ci.is_deleted = 0
                WHERE wv.is_deleted = 0
                GROUP BY wv.varietal_id, wv.varietal_name
                HAVING bottle_count > 0
                ORDER BY bottle_count DESC";
        return getDB()->query($sql)->fetchAll();
    }
}
