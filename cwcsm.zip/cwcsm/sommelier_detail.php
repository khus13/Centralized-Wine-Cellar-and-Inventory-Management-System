<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_login();

$sommelierId = (int) ($_GET['id'] ?? 0);
$sommelier = Sommelier::findById($sommelierId);
if (!$sommelier) {
    flash('error', 'Sommelier not found.');
    redirect('sommeliers.php');
}

require_once __DIR__ . '/controllers/sommelier_detail_controller.php';

$isOwner = is_sommelier() && (int) current_user()['profile_id'] === $sommelierId;
$isAdmin = is_admin();
$canEdit = $isOwner || $isAdmin;

$certs = SommelierCertification::forSommelier($sommelierId);
$allCertifications = Certification::all();
$notes = TastingNote::bySommelier($sommelierId);

$pageTitle = $sommelier['first_name'] . ' ' . $sommelier['last_name'];
include __DIR__ . '/includes/header.php';

$expiringSoonCerts = array_filter($certs, function ($c) {
    if (!$c['expiration_date']) return false;
    $t = strtotime($c['expiration_date']);
    return $t >= time() && $t <= strtotime('+30 days');
});
?>
<?php if ($expiringSoonCerts && $canEdit): ?>
<div class="flash flash-error" style="margin-bottom:16px;">
  <?= sanitize($sommelier['first_name']) ?>'s certification<?= count($expiringSoonCerts) === 1 ? '' : 's' ?> —
  <?= implode(', ', array_map(fn($c) => sanitize($c['certification_name']) . ' (expires ' . format_date($c['expiration_date']) . ')', $expiringSoonCerts)) ?>
  — <?= count($expiringSoonCerts) === 1 ? 'is' : 'are' ?> expiring within 30 days.
</div>
<?php endif; ?>
<a href="sommeliers.php" style="font-size:13px;color:#5c4d4f;">&larr; Back to Sommeliers</a>

<div class="profile-hero" style="margin-top:14px;">
  <div class="avatar-lg">
    <?php if (!empty($sommelier['photo_path'])): ?>
      <img src="<?= sanitize(upload_url($sommelier['photo_path'])) ?>" alt="">
    <?php else: ?>
      <?= strtoupper(substr($sommelier['first_name'], 0, 1) . substr($sommelier['last_name'], 0, 1)) ?>
    <?php endif; ?>
  </div>
  <div style="flex:1;">
    <h1><?= sanitize($sommelier['first_name'] . ' ' . $sommelier['last_name']) ?></h1>
    <p class="subtitle">Sommelier since <?= format_date($sommelier['hire_date']) ?> &middot; <?= sanitize($sommelier['email']) ?></p>
  </div>
  <?php if ($canEdit): ?>
    <div style="display:flex;gap:8px;">
      <button class="btn btn-outline" data-open-modal="uploadPhotoModal"><?= icon('camera') ?> Update Photo</button>
      <?php if (!empty($sommelier['photo_path'])): ?>
        <form method="post" action="sommelier_detail.php?id=<?= $sommelierId ?>" data-confirm="Remove this profile photo?">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="remove_photo">
          <button type="submit" class="btn btn-outline remove-image-btn"><?= icon('trash') ?> Remove</button>
        </form>
      <?php endif; ?>
    </div>
  <?php endif; ?>
</div>

<div class="stat-grid" style="grid-template-columns:repeat(3,1fr);">
  <div class="stat-card"><div class="stat-icon"><?= icon('certificate') ?></div><div><div class="stat-label">Certifications</div><div class="stat-value"><?= count($certs) ?></div></div></div>
  <div class="stat-card"><div class="stat-icon"><?= icon("notes") ?></div><div><div class="stat-label">Tasting Notes</div><div class="stat-value"><?= count($notes) ?></div></div></div>
  <div class="stat-card"><div class="stat-icon"><?= icon("archive") ?></div><div><div class="stat-label">Years of Service</div><div class="stat-value"><?= max(0, date('Y') - (int) date('Y', strtotime($sommelier['hire_date']))) ?></div></div></div>
</div>

<div class="card" style="margin-bottom:16px;">
  <div class="toolbar" style="margin-bottom:14px;">
    <h3 style="margin:0;">Certifications</h3>
    <?php if ($canEdit): ?><button class="btn btn-primary btn-sm" data-open-modal="addCertModal">+ Add Certification</button><?php endif; ?>
  </div>

  <?php if (!$certs): ?>
    <p style="color:#5c4d4f;font-size:13.5px;">No certifications on file yet.</p>
  <?php else: ?>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Certification</th><th>Issuing Body</th><th>Issued</th><th>Expires</th><th>Document</th><?php if ($canEdit): ?><th></th><?php endif; ?></tr></thead>
        <tbody>
          <?php foreach ($certs as $c):
            $expired = $c['expiration_date'] && strtotime($c['expiration_date']) < time();
            $expiringSoon = !$expired && $c['expiration_date'] && strtotime($c['expiration_date']) <= strtotime('+30 days');
          ?>
          <tr>
            <td><?= sanitize($c['certification_name']) ?></td>
            <td><?= sanitize($c['issuing_body']) ?></td>
            <td><?= format_date($c['date_issued']) ?></td>
            <td><?= $c['expiration_date'] ? format_date($c['expiration_date']) : '—' ?> <?php if ($expired): ?><span class="status-pill status-out_of_stock">Expired</span><?php elseif ($expiringSoon): ?><span class="status-pill status-warning">Expiring Soon</span><?php endif; ?></td>
            <td>
              <?php if (!empty($c['certificate_file_path'])): ?>
                <a href="<?= sanitize(upload_url($c['certificate_file_path'])) ?>" target="_blank">View PDF</a>
                <?php if ($canEdit): ?>
                  <form method="post" action="sommelier_detail.php?id=<?= $sommelierId ?>" data-confirm="Remove this certification's uploaded file?" style="display:inline;">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="remove_certification_file">
                    <input type="hidden" name="sommelier_certification_id" value="<?= $c['sommelier_certification_id'] ?>">
                    <button type="submit" class="btn btn-outline remove-image-btn btn-sm" style="margin-left:6px;padding:2px 8px;font-size:11.5px;">Remove File</button>
                  </form>
                <?php endif; ?>
              <?php else: ?>—<?php endif; ?>
            </td>
            <?php if ($canEdit): ?>
            <td class="table-actions">
              <button type="button" class="btn btn-outline btn-sm" data-open-modal="editCert<?= $c['sommelier_certification_id'] ?>">Edit</button>
              <form method="post" action="sommelier_detail.php?id=<?= $sommelierId ?>" data-confirm="Remove this certification?">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="delete_certification">
                <input type="hidden" name="sommelier_certification_id" value="<?= $c['sommelier_certification_id'] ?>">
                <button type="submit" class="btn btn-danger btn-sm">Remove</button>
              </form>
            </td>
            <?php endif; ?>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>

<?php if ($canEdit): foreach ($certs as $c): ?>
<div class="modal-overlay" id="editCert<?= $c['sommelier_certification_id'] ?>">
  <div class="modal">
    <div class="modal-header"><h3>Edit Certification</h3><button class="modal-close" data-close-modal>&times;</button></div>
    <form method="post" action="sommelier_detail.php?id=<?= $sommelierId ?>" enctype="multipart/form-data">
      <div class="modal-body">
        <?= csrf_field() ?>
        <input type="hidden" name="sommelier_certification_id" value="<?= $c['sommelier_certification_id'] ?>">
        <div class="field"><label>Certification</label>
          <select name="certification_id" required>
            <?php foreach ($allCertifications as $ac): ?><option value="<?= $ac['certification_id'] ?>" <?= (int) $ac['certification_id'] === (int) $c['certification_id'] ? 'selected' : '' ?>><?= sanitize($ac['certification_name']) ?> — <?= sanitize($ac['issuing_body']) ?></option><?php endforeach; ?>
          </select>
        </div>
        <div class="field"><label>Date Issued</label><input type="date" name="date_issued" value="<?= sanitize($c['date_issued']) ?>" required></div>
        <div class="field"><label>Expiration Date (optional)</label><input type="date" name="expiration_date" value="<?= sanitize($c['expiration_date'] ?? '') ?>"></div>
        <?php if (!empty($c['certificate_file_path'])): ?>
        <div class="field">
          <label>Current Certificate</label>
          <div style="display:flex;align-items:center;gap:10px;">
            <a href="<?= sanitize(upload_url($c['certificate_file_path'])) ?>" target="_blank">View PDF</a>
            <button type="submit" name="action" value="remove_certification_file" class="btn btn-outline remove-image-btn btn-sm" formnovalidate>Remove File</button>
          </div>
        </div>
        <?php endif; ?>
        <div class="field"><label><?= empty($c['certificate_file_path']) ? 'Certificate PDF (optional)' : 'Replace Certificate PDF (optional)' ?></label><input type="file" name="certificate_file" accept="application/pdf"></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline" data-close-modal>Cancel</button>
        <button type="submit" name="action" value="edit_certification" class="btn btn-primary">Save Changes</button>
      </div>
    </form>
  </div>
</div>
<?php endforeach; endif; ?>

<div class="card">
  <h3 style="margin-bottom:14px;">Tasting Note Statistics</h3>
  <?php if (!$notes): ?>
    <p style="color:#5c4d4f;font-size:13.5px;">No tasting notes recorded yet.</p>
  <?php else: ?>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Wine</th><th>Date</th><th>Body</th><th>Acidity</th><th>Tannin</th></tr></thead>
        <tbody>
        <?php foreach (array_slice($notes, 0, 10) as $n): ?>
          <tr>
            <td><?= sanitize($n['vineyard_name'] . ' ' . $n['varietal_name'] . ' (' . $n['vintage_year'] . ')') ?></td>
            <td><?= format_date($n['tasting_date']) ?></td>
            <td><?= star_rating((int) $n['body_rating']) ?></td>
            <td><?= star_rating((int) $n['acidity_rating']) ?></td>
            <td><?= star_rating((int) $n['tannin_rating']) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>

<?php if ($canEdit): ?>
<div class="modal-overlay" id="uploadPhotoModal">
  <div class="modal">
    <div class="modal-header"><h3>Update Profile Photo</h3><button class="modal-close" data-close-modal>&times;</button></div>
    <form method="post" action="sommelier_detail.php?id=<?= $sommelierId ?>" enctype="multipart/form-data">
      <div class="modal-body">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="upload_photo">
        <div class="field"><label>Photo</label><input type="file" name="photo" accept="image/*" required></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline" data-close-modal>Cancel</button>
        <button type="submit" class="btn btn-primary">Upload</button>
      </div>
    </form>
  </div>
</div>

<div class="modal-overlay" id="addCertModal">
  <div class="modal">
    <div class="modal-header"><h3>Add Certification</h3><button class="modal-close" data-close-modal>&times;</button></div>
    <form method="post" action="sommelier_detail.php?id=<?= $sommelierId ?>" enctype="multipart/form-data">
      <div class="modal-body">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="add_certification">
        <div class="field"><label>Certification</label>
          <select name="certification_id" required>
            <option value="" disabled selected>Select certification</option>
            <?php foreach ($allCertifications as $c): ?><option value="<?= $c['certification_id'] ?>"><?= sanitize($c['certification_name']) ?> — <?= sanitize($c['issuing_body']) ?></option><?php endforeach; ?>
          </select>
        </div>
        <div class="field"><label>Date Issued</label><input type="date" name="date_issued" value="<?= date('Y-m-d') ?>" required></div>
        <div class="field"><label>Expiration Date (optional)</label><input type="date" name="expiration_date"></div>
        <div class="field"><label>Certificate PDF (optional)</label><input type="file" name="certificate_file" accept="application/pdf"></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline" data-close-modal>Cancel</button>
        <button type="submit" class="btn btn-primary">Save</button>
      </div>
    </form>
  </div>
</div>
<?php endif; ?>

<?php include __DIR__ . '/includes/footer.php'; ?>
