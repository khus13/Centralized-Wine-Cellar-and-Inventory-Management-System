<?php
/**
 * CWCSM - Wine Cellar controller
 * Included by wine_cellar.php before any HTML output.
 * Admin and Cellar Manager: full CRUD. Sommelier: read-only (blocked here too).
 */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    if (!can_manage_inventory()) {
        http_response_code(403);
        die('You do not have permission to modify the wine cellar.');
    }

    $action = $_POST['action'] ?? '';

    if ($action === 'create' || $action === 'update') {
        $vineyardId  = (int) ($_POST['vineyard_id'] ?? 0);
        $varietalId  = (int) ($_POST['varietal_id'] ?? 0);
        $supplierId  = (int) ($_POST['supplier_id'] ?? 0);
        $vintageYear = (int) ($_POST['vintage_year'] ?? 0);
        $binNumber   = trim($_POST['storage_bin_number'] ?? '');
        $purchaseDate = $_POST['purchase_date'] ?? '';
        $price       = (float) ($_POST['purchase_price'] ?? 0);
        $status      = $_POST['inventory_status'] ?? 'In Stock';
        $checkDate   = $_POST['last_inventory_check_date'] ?? date('Y-m-d');

        if (!$vineyardId || !$varietalId || !$supplierId || !$vintageYear || $binNumber === '' || !$purchaseDate) {
            flash('error', 'Please fill in all required wine cellar fields (vineyard, varietal, supplier, vintage, bin, and purchase date).');
        } else {
            $uploadError = null;
            $imagePath = handle_upload('bottle_image', 'wines', ['jpg', 'jpeg', 'png', 'webp'], 5 * 1024 * 1024, $uploadError);

            if ($uploadError) {
                flash('error', $uploadError);
            } else {
                try {
                    if ($action === 'create') {
                        $managerId = is_cellar_manager()
                            ? (int) current_user()['profile_id']
                            : (int) ($_POST['manager_id'] ?? 0);

                        if (!$managerId) {
                            flash('error', 'Please select which Cellar Manager is recording this bottle.');
                        } else {
                            Inventory::create($vineyardId, $varietalId, $supplierId, $managerId, $vintageYear, $binNumber, $purchaseDate, $price, $status, $checkDate, $imagePath);
                            flash('success', 'Wine bottle added to the cellar.');
                        }
                    } else {
                        $bottleId = (int) ($_POST['bottle_id'] ?? 0);
                        Inventory::update($bottleId, $vineyardId, $varietalId, $supplierId, $vintageYear, $binNumber, $purchaseDate, $price, $status, $checkDate);
                        if ($imagePath) {
                            Inventory::updateImage($bottleId, $imagePath);
                        }
                        flash('success', 'Wine bottle updated.');
                    }
                } catch (PDOException $e) {
                    error_log('[CWCSM] wine_controller: ' . $e->getMessage());
                    flash('error', friendly_db_error($e));
                }
            }
        }
    } elseif ($action === 'remove_image') {
        $bottleId = (int) ($_POST['bottle_id'] ?? 0);
        $bottle = $bottleId ? Inventory::findById($bottleId) : null;
        if ($bottle) {
            delete_upload($bottle['image_path']);
            Inventory::updateImage($bottleId, '');
            flash('success', 'Bottle image removed.');
        }
    } elseif ($action === 'delete') {
        $bottleId = (int) ($_POST['bottle_id'] ?? 0);
        if ($bottleId) {
            try {
                Inventory::softDelete($bottleId);
                flash('success', 'Wine bottle archived.');
            } catch (PDOException $e) {
                flash('error', friendly_db_error($e));
            }
        }
    } elseif ($action === 'restore') {
        $bottleId = (int) ($_POST['bottle_id'] ?? 0);
        if ($bottleId) {
            Inventory::restore($bottleId);
            flash('success', 'Wine bottle restored.');
        }
    }

    redirect('wine_cellar.php');
}
