<?php
/**
 * CWCSM - Accounts controller (Admin only). Password resets + deactivate/reactivate accounts.
 */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    if (!is_admin()) {
        http_response_code(403);
        die('You do not have permission to manage accounts.');
    }

    $action = $_POST['action'] ?? '';

    if ($action === 'reset_password') {
        $accountId = (int) ($_POST['account_id'] ?? 0);
        $newPassword = $_POST['new_password'] ?? '';

        if (strlen($newPassword) < 8) {
            flash('error', 'New password must be at least 8 characters.');
        } elseif ($accountId) {
            Account::updatePassword($accountId, password_hash($newPassword, PASSWORD_DEFAULT));
            flash('success', 'Password reset successfully.');
        }
    } elseif ($action === 'deactivate') {
        $accountId = (int) ($_POST['account_id'] ?? 0);
        if ($accountId === (int) current_user()['account_id']) {
            flash('error', 'You can\'t deactivate your own account.');
        } elseif ($accountId) {
            Account::deactivate($accountId);
            flash('success', 'Account deactivated. That person can no longer sign in.');
        }
    } elseif ($action === 'reactivate') {
        $accountId = (int) ($_POST['account_id'] ?? 0);
        if ($accountId) {
            Account::reactivate($accountId);
            flash('success', 'Account reactivated.');
        }
    } elseif ($action === 'change_role') {
        $accountId = (int) ($_POST['account_id'] ?? 0);
        $newRole   = $_POST['new_role'] ?? '';
        if ($accountId === (int) current_user()['account_id']) {
            flash('error', "You can't change your own role.");
        } elseif ($accountId) {
            [$ok, $err] = Account::changeRole($accountId, $newRole);
            if ($ok) {
                $labels = ['sommelier' => 'Sommelier', 'cellar_manager' => 'Cellar Manager', 'admin' => 'System Admin'];
                flash('success', 'Role updated to ' . ($labels[$newRole] ?? $newRole) . '.');
            } else {
                flash('error', $err);
            }
        }
    }

    redirect('accounts.php');
}