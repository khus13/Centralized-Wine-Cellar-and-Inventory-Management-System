<?php
/**
 * CWCSM - Wine Rating controller
 * Sommeliers create / edit / remove their own overall rating + report for
 * a bottle. Included by wine_cellar.php BEFORE wine_controller.php so that
 * rating submissions are handled here (and redirected) without tripping the
 * inventory-only permission gate in wine_controller.php.
 */

if ($_SERVER['REQUEST_METHOD'] === 'POST'
    && in_array($_POST['action'] ?? '', ['rate_wine', 'delete_wine_rating'], true)) {

    csrf_verify();

    if (!is_sommelier()) {
        http_response_code(403);
        die('Only sommeliers can rate wines.');
    }

    $sommelierId = (int) current_user()['profile_id'];
    $bottleId    = (int) ($_POST['bottle_id'] ?? 0);
    $action      = $_POST['action'];

    if ($action === 'rate_wine') {
        $rating = (int) ($_POST['rating'] ?? 0);
        $report = trim($_POST['report'] ?? '');

        if (!$bottleId || $rating < 1 || $rating > 5) {
            flash('error', 'Please choose a rating from 1 to 5 stars.');
        } else {
            try {
                WineRating::upsert($bottleId, $sommelierId, $rating, $report !== '' ? $report : null);
                flash('success', 'Your rating was saved.');
            } catch (PDOException $e) {
                error_log('[CWCSM] wine_rating_controller: ' . $e->getMessage());
                flash('error', friendly_db_error($e));
            }
        }
    } elseif ($action === 'delete_wine_rating') {
        if ($bottleId) {
            WineRating::delete($bottleId, $sommelierId);
            flash('success', 'Your rating was removed.');
        }
    }

    redirect('wine_cellar.php');
}
