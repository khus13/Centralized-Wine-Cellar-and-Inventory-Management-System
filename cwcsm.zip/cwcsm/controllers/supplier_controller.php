<?php
/**
 * CWCSM - Supplier controller. Admin: CRUD. Everyone else: read-only.
 */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    if (!is_admin()) {
        http_response_code(403);
        die('You do not have permission to modify suppliers.');
    }

    $action = $_POST['action'] ?? '';

    if ($action === 'create' || $action === 'update') {
        $vineyardId = (int) ($_POST['vineyard_id'] ?? 0);
        $varietalId = (int) ($_POST['varietal_id'] ?? 0);
        $contact    = trim($_POST['supplier_contact_name'] ?? '');
        $leadTime   = (int) ($_POST['lead_time_days'] ?? 0);

        if (!$vineyardId || !$varietalId || $contact === '') {
            flash('error', 'Please fill in all required supplier fields.');
        } else {
            try {
                if ($action === 'create') {
                    Supplier::create($vineyardId, $varietalId, $contact, $leadTime);
                    flash('success', 'Supplier added.');
                } else {
                    Supplier::update((int) $_POST['supplier_id'], $vineyardId, $varietalId, $contact, $leadTime);
                    flash('success', 'Supplier updated.');
                }
            } catch (PDOException $e) {
                error_log('[CWCSM] supplier_controller: ' . $e->getMessage());
                flash('error', friendly_db_error($e));
            }
        }
    } elseif ($action === 'delete') {
        try {
            Supplier::softDelete((int) ($_POST['supplier_id'] ?? 0));
            flash('success', 'Supplier archived.');
        } catch (PDOException $e) {
            flash('error', friendly_db_error($e));
        }
    } elseif ($action === 'restore') {
        Supplier::restore((int) ($_POST['supplier_id'] ?? 0));
        flash('success', 'Supplier restored.');
    }

    redirect('suppliers.php');
}
