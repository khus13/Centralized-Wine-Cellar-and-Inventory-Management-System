<?php
/**
 * CWCSM - Wine Varietal controller. Admin: CRUD. Everyone else: read-only.
 */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    if (!is_admin()) {
        http_response_code(403);
        die('You do not have permission to modify wine varietals.');
    }

    $action = $_POST['action'] ?? '';

    if ($action === 'create' || $action === 'update') {
        $name    = trim($_POST['varietal_name'] ?? '');
        $color   = $_POST['color_type'] ?? '';
        $minAge  = (int) ($_POST['min_typical_aging_yrs'] ?? 0);
        $maxAge  = (int) ($_POST['max_typical_aging_yrs'] ?? 0);
        $pairing = trim($_POST['food_pairing_template'] ?? '');
        $temp    = (float) ($_POST['entry_temperature_celsius'] ?? 0);

        if ($name === '' || $color === '' || $pairing === '') {
            flash('error', 'Please fill in all required fields.');
        } else {
            $err = null;
            $imagePath = handle_upload('varietal_image', 'varietals', ['jpg', 'jpeg', 'png', 'webp'], 5 * 1024 * 1024, $err);
            if ($err) {
                flash('error', $err);
            } else {
                try {
                    if ($action === 'create') {
                        $newId = Varietal::create($name, $color, $minAge, $maxAge, $pairing, $temp);
                        if ($imagePath) {
                            Varietal::updateImage($newId, $imagePath);
                        }
                        flash('success', 'Wine varietal added.');
                    } else {
                        Varietal::update((int) $_POST['varietal_id'], $name, $color, $minAge, $maxAge, $pairing, $temp);
                        if ($imagePath) {
                            Varietal::updateImage((int) $_POST['varietal_id'], $imagePath);
                        }
                        flash('success', 'Wine varietal updated.');
                    }
                } catch (PDOException $e) {
                    error_log('[CWCSM] varietal_controller: ' . $e->getMessage());
                    flash('error', friendly_db_error($e));
                }
            }
        }
    } elseif ($action === 'remove_image') {
        $id = (int) ($_POST['varietal_id'] ?? 0);
        $v = $id ? Varietal::findById($id) : null;
        if ($v) {
            delete_upload($v['image_path'] ?? null);
            Varietal::updateImage($id, null);
            flash('success', 'Varietal photo removed.');
        }
    } elseif ($action === 'delete') {
        try {
            Varietal::softDelete((int) ($_POST['varietal_id'] ?? 0));
            flash('success', 'Wine varietal archived.');
        } catch (PDOException $e) {
            flash('error', friendly_db_error($e));
        }
    } elseif ($action === 'restore') {
        Varietal::restore((int) ($_POST['varietal_id'] ?? 0));
        flash('success', 'Wine varietal restored.');
    }

    redirect('varietals.php');
}
