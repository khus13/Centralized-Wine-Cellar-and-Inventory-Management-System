<?php
/**
 * CWCSM - Vineyard controller. Admin: CRUD. Everyone else: read-only.
 */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    if (!is_admin()) {
        http_response_code(403);
        die('You do not have permission to modify vineyards.');
    }

    $action = $_POST['action'] ?? '';

    if ($action === 'create' || $action === 'update') {
        $name        = trim($_POST['vineyard_name'] ?? '');
        $regionField = $_POST['region_id'] ?? '';
        $year        = (int) ($_POST['established_year'] ?? 0);
        $phone       = trim($_POST['contact_phone'] ?? '');
        $isActive    = isset($_POST['is_active']) ? 1 : 0;

        $regionId = 0;
        $regionError = null;

        if ($regionField === 'new') {
            $newRegionName    = trim($_POST['new_region_name'] ?? '');
            $newRegionCountry = trim($_POST['new_region_country'] ?? '');
            if ($newRegionName === '' || $newRegionCountry === '') {
                $regionError = 'Please provide both a name and country for the new region.';
            } else {
                try {
                    $regionId = Region::create($newRegionName, $newRegionCountry);
                } catch (PDOException $e) {
                    error_log('[CWCSM] vineyard_controller (new region): ' . $e->getMessage());
                    $regionError = friendly_db_error($e);
                }
            }
        } else {
            $regionId = (int) $regionField;
        }

        if ($name === '' || !$regionId || !$year) {
            flash('error', $regionError ?? 'Please fill in all required vineyard fields.');
        } else {
            $err = null;
            $imagePath = handle_upload('vineyard_image', 'vineyards', ['jpg', 'jpeg', 'png', 'webp'], 5 * 1024 * 1024, $err);
            if ($err) {
                flash('error', $err);
            } else {
                try {
                    if ($action === 'create') {
                        Vineyard::create($name, $regionId, $year, $phone, $imagePath);
                        flash('success', $regionField === 'new' ? 'New region and vineyard added.' : 'Vineyard added.');
                    } else {
                        $id = (int) $_POST['vineyard_id'];
                        Vineyard::update($id, $name, $regionId, $year, $phone, $isActive);
                        if ($imagePath) {
                            Vineyard::updateImage($id, $imagePath);
                        }
                        flash('success', $regionField === 'new' ? 'New region added and vineyard updated.' : 'Vineyard updated.');
                    }
                } catch (PDOException $e) {
                    error_log('[CWCSM] vineyard_controller: ' . $e->getMessage());
                    flash('error', friendly_db_error($e));
                }
            }
        }
    } elseif ($action === 'remove_image') {
        $id = (int) ($_POST['vineyard_id'] ?? 0);
        $v = $id ? Vineyard::findById($id) : null;
        if ($v) {
            delete_upload($v['image_path']);
            Vineyard::updateImage($id, null);
            flash('success', 'Vineyard photo removed.');
        }
    } elseif ($action === 'delete') {
        try {
            Vineyard::softDelete((int) ($_POST['vineyard_id'] ?? 0));
            flash('success', 'Vineyard archived.');
        } catch (PDOException $e) {
            flash('error', friendly_db_error($e));
        }
    } elseif ($action === 'restore') {
        Vineyard::restore((int) ($_POST['vineyard_id'] ?? 0));
        flash('success', 'Vineyard restored.');
    } elseif ($action === 'create_region') {
        $name = trim($_POST['region_name'] ?? '');
        $country = trim($_POST['country'] ?? '');
        if ($name !== '' && $country !== '') {
            try {
                Region::create($name, $country);
                flash('success', 'Region added.');
            } catch (PDOException $e) {
                flash('error', friendly_db_error($e));
            }
        }
    }

    redirect('vineyards.php');
}
