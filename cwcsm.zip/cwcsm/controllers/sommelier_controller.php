<?php
/**
 * CWCSM - Sommeliers list controller. Admin-only: create a new Sommelier
 * account directly (bypasses public self-registration).
 */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    if (!is_admin()) {
        http_response_code(403);
        die('You do not have permission to add sommeliers.');
    }

    $action = $_POST['action'] ?? '';

    if ($action === 'create_sommelier') {
        $first    = trim($_POST['first_name'] ?? '');
        $last     = trim($_POST['last_name'] ?? '');
        $username = trim($_POST['username'] ?? '');
        $email    = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $hireDate = $_POST['hire_date'] ?? date('Y-m-d');

        if ($first === '' || $last === '' || $username === '' || $email === '') {
            flash('error', 'Please fill in all required fields.');
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            flash('error', 'Please enter a valid email address.');
        } elseif (strlen($password) < 8) {
            flash('error', 'Password must be at least 8 characters.');
        } elseif (Account::findByUsername($username)) {
            flash('error', 'That username is already taken.');
        } elseif (Account::findByEmail($email)) {
            flash('error', 'That email is already registered.');
        } else {
            $db = getDB();
            try {
                $db->beginTransaction();
                $hash = password_hash($password, PASSWORD_DEFAULT);
                $accountId = Account::create($first, $last, $username, $hash, $email, '');
                Sommelier::create($accountId, $hireDate);
                $db->commit();
                flash('success', 'Sommelier account created.');
            } catch (Throwable $e) {
                $db->rollBack();
                error_log('[CWCSM] sommelier_controller: ' . $e->getMessage());
                flash('error', 'Could not create the sommelier account. Please try again.');
            }
        }
    }

    redirect('sommeliers.php');
}
