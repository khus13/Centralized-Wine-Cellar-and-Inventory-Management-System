<?php
/**
 * CWCSM - Sommelier detail controller
 * Included by sommelier_detail.php. $sommelier must already be loaded.
 */

/** @var array $sommelier */
if (!isset($sommelier)) { return; }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    $isOwner = is_sommelier() && (int) current_user()['profile_id'] === (int) $sommelier['sommelier_id'];
    $isAdmin = is_admin();

    if (!$isOwner && !$isAdmin) {
        http_response_code(403);
        die('You do not have permission to modify this profile.');
    }

    $action = $_POST['action'] ?? '';

    if ($action === 'upload_photo') {
        $err = null;
        $path = handle_upload('photo', 'profiles', ['jpg', 'jpeg', 'png', 'webp'], 4 * 1024 * 1024, $err);
        if ($err) {
            flash('error', $err);
        } elseif ($path) {
            $old = $sommelier['photo_path'] ?? null;
            Sommelier::updatePhoto((int) $sommelier['sommelier_id'], $path);
            delete_upload($old);
            flash('success', 'Profile photo updated.');
        } else {
            flash('error', 'Please choose a photo to upload.');
        }
    } elseif ($action === 'remove_photo') {
        delete_upload($sommelier['photo_path'] ?? null);
        Sommelier::updatePhoto((int) $sommelier['sommelier_id'], null);
        flash('success', 'Profile photo removed.');
    } elseif ($action === 'add_certification') {
        $certId = (int) ($_POST['certification_id'] ?? 0);
        $issued = $_POST['date_issued'] ?? '';
        $expires = trim($_POST['expiration_date'] ?? '') ?: null;

        if (!$certId || !$issued) {
            flash('error', 'Please select a certification and issue date.');
        } else {
            $err = null;
            $filePath = handle_upload('certificate_file', 'certifications', ['pdf'], 8 * 1024 * 1024, $err);
            if ($err) {
                flash('error', $err);
            } else {
                try {
                    SommelierCertification::create((int) $sommelier['sommelier_id'], $certId, $issued, $expires, $filePath);
                    flash('success', 'Certification added.');
                } catch (PDOException $e) {
                    error_log('[CWCSM] sommelier_detail_controller: ' . $e->getMessage());
                    flash('error', friendly_db_error($e));
                }
            }
        }
    } elseif ($action === 'edit_certification') {
        $scId = (int) ($_POST['sommelier_certification_id'] ?? 0);
        $owner = SommelierCertification::ownerSommelierId($scId);
        if (!$isAdmin && $owner !== (int) $sommelier['sommelier_id']) {
            flash('error', 'You can only edit your own certifications.');
        } else {
            $certId = (int) ($_POST['certification_id'] ?? 0);
            $issued = $_POST['date_issued'] ?? '';
            $expires = trim($_POST['expiration_date'] ?? '') ?: null;

            if (!$certId || !$issued) {
                flash('error', 'Please select a certification and issue date.');
            } else {
                $err = null;
                $filePath = handle_upload('certificate_file', 'certifications', ['pdf'], 8 * 1024 * 1024, $err);
                if ($err) {
                    flash('error', $err);
                } else {
                    try {
                        SommelierCertification::update($scId, $certId, $issued, $expires);
                        if ($filePath) {
                            SommelierCertification::updateFile($scId, $filePath);
                        }
                        flash('success', 'Certification updated.');
                    } catch (PDOException $e) {
                        error_log('[CWCSM] sommelier_detail_controller: ' . $e->getMessage());
                        flash('error', friendly_db_error($e));
                    }
                }
            }
        }
    } elseif ($action === 'delete_certification') {
        $scId = (int) ($_POST['sommelier_certification_id'] ?? 0);
        $owner = SommelierCertification::ownerSommelierId($scId);
        if ($isAdmin || $owner === (int) $sommelier['sommelier_id']) {
            SommelierCertification::softDelete($scId);
            flash('success', 'Certification archived.');
        }
    }

    redirect('sommelier_detail.php?id=' . (int) $sommelier['sommelier_id']);
}
