<?php
/**
 * CWCSM - Tasting Notes controller
 * Admin: full CRUD. Sommelier: create + edit/delete own only. Cellar Manager: read-only (blocked here).
 */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    if (!is_admin() && !is_sommelier()) {
        http_response_code(403);
        die('You do not have permission to modify tasting notes.');
    }

    $action = $_POST['action'] ?? '';

    if ($action === 'create' || $action === 'update') {
        $bottleId   = (int) ($_POST['bottle_id'] ?? 0);
        $tastingDate = $_POST['tasting_date'] ?? '';
        $aroma      = trim($_POST['aroma_notes'] ?? '');
        $flavor     = trim($_POST['flavor_notes'] ?? '');
        $remarks    = trim($_POST['remarks'] ?? '');
        $body       = (int) ($_POST['body_rating'] ?? 0);
        $acidity    = (int) ($_POST['acidity_rating'] ?? 0);
        $tannin     = (int) ($_POST['tannin_rating'] ?? 0);
        $peakStart  = (int) ($_POST['peak_drinking_start_year'] ?? 0);
        $peakEnd    = (int) ($_POST['peak_drinking_end_year'] ?? 0);

        if (!$bottleId || !$tastingDate || $aroma === '' || $flavor === '' || !$peakStart || !$peakEnd) {
            flash('error', 'Please fill in all required tasting note fields.');
        } else {
            try {
                if ($action === 'create') {
                    $sommelierId = is_sommelier() ? (int) current_user()['profile_id'] : (int) ($_POST['sommelier_id'] ?? 0);
                    if (!$sommelierId) {
                        flash('error', 'Please select which sommelier this note belongs to.');
                    } else {
                        TastingNote::create($bottleId, $sommelierId, $tastingDate, $aroma, $flavor, $body, $acidity, $tannin, $peakStart, $peakEnd, $remarks !== '' ? $remarks : null);
                        flash('success', 'Tasting note added.');
                    }
                } else {
                    $noteId = (int) ($_POST['note_id'] ?? 0);
                    $owner = TastingNote::ownerSommelierId($noteId);
                    if (!is_admin() && $owner !== (int) current_user()['profile_id']) {
                        flash('error', 'You can only edit your own tasting notes.');
                    } else {
                        TastingNote::update($noteId, $bottleId, $tastingDate, $aroma, $flavor, $body, $acidity, $tannin, $peakStart, $peakEnd, $remarks !== '' ? $remarks : null);
                        flash('success', 'Tasting note updated.');
                    }
                }
            } catch (PDOException $e) {
                error_log('[CWCSM] tasting_notes_controller: ' . $e->getMessage());
                flash('error', friendly_db_error($e));
            }
        }
    } elseif ($action === 'delete') {
        $noteId = (int) ($_POST['note_id'] ?? 0);
        $owner = TastingNote::ownerSommelierId($noteId);
        if (!is_admin() && $owner !== (int) current_user()['profile_id']) {
            flash('error', 'You can only delete your own tasting notes.');
        } else {
            TastingNote::softDelete($noteId);
            flash('success', 'Tasting note archived.');
        }
    } elseif ($action === 'restore') {
        $noteId = (int) ($_POST['note_id'] ?? 0);
        $owner = TastingNote::ownerSommelierId($noteId);
        if (is_admin() || $owner === (int) current_user()['profile_id']) {
            TastingNote::restore($noteId);
            flash('success', 'Tasting note restored.');
        }
    }

    redirect('tasting_notes.php');
}
