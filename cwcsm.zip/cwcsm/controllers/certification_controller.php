<?php
/**
 * CWCSM - Certification catalog controller. Admin: CRUD. Everyone else: read-only.
 */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    if (!is_admin()) {
        http_response_code(403);
        die('You do not have permission to modify the certification catalog.');
    }

    $action = $_POST['action'] ?? '';

    if ($action === 'create' || $action === 'update') {
        $name = trim($_POST['certification_name'] ?? '');
        $body = trim($_POST['issuing_body'] ?? '');
        if ($name === '' || $body === '') {
            flash('error', 'Please fill in both fields.');
        } else {
            try {
                if ($action === 'create') {
                    Certification::create($name, $body);
                    flash('success', 'Certification added to the catalog.');
                } else {
                    Certification::update((int) $_POST['certification_id'], $name, $body);
                    flash('success', 'Certification updated.');
                }
            } catch (PDOException $e) {
                error_log('[CWCSM] certification_controller: ' . $e->getMessage());
                flash('error', friendly_db_error($e));
            }
        }
    } elseif ($action === 'delete') {
        try {
            Certification::softDelete((int) ($_POST['certification_id'] ?? 0));
            flash('success', 'Certification archived.');
        } catch (PDOException $e) {
            flash('error', friendly_db_error($e));
        }
    } elseif ($action === 'restore') {
        Certification::restore((int) ($_POST['certification_id'] ?? 0));
        flash('success', 'Certification restored.');
    }

    redirect('certifications.php');
}
