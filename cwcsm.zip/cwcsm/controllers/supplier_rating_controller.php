<?php
/**
 * CWCSM - Supplier Rating controller
 * Cellar Managers create / edit / remove their own rating + report for a
 * supplier. Included by suppliers.php BEFORE supplier_controller.php so that
 * rating submissions are handled here (and redirected) without tripping the
 * admin-only permission gate in supplier_controller.php.
 */

if ($_SERVER['REQUEST_METHOD'] === 'POST'
    && in_array($_POST['action'] ?? '', ['rate_supplier', 'delete_supplier_rating'], true)) {

    csrf_verify();

    if (!is_cellar_manager()) {
        http_response_code(403);
        die('Only cellar managers can rate suppliers.');
    }

    $managerId  = (int) current_user()['profile_id'];
    $supplierId = (int) ($_POST['supplier_id'] ?? 0);
    $action     = $_POST['action'];

    if ($action === 'rate_supplier') {
        $rating = (int) ($_POST['rating'] ?? 0);
        $report = trim($_POST['report'] ?? '');

        if (!$supplierId || $rating < 1 || $rating > 5) {
            flash('error', 'Please choose a rating from 1 to 5 stars.');
        } else {
            try {
                SupplierRating::upsert($supplierId, $managerId, $rating, $report !== '' ? $report : null);
                flash('success', 'Your supplier rating was saved.');
            } catch (PDOException $e) {
                error_log('[CWCSM] supplier_rating_controller: ' . $e->getMessage());
                flash('error', friendly_db_error($e));
            }
        }
    } elseif ($action === 'delete_supplier_rating') {
        if ($supplierId) {
            SupplierRating::delete($supplierId, $managerId);
            flash('success', 'Your supplier rating was removed.');
        }
    }

    redirect('suppliers.php');
}
