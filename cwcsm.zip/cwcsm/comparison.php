<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_login();
require_role(['sommelier', 'admin']);

$pageTitle = 'Wine Comparison';

$vineyards = Vineyard::all();
$varietals  = Varietal::all();
$db = getDB();

// All bottles with tasting data — the pool to pick from
$pool = $db->query(
    "SELECT ci.bottle_id, v.vineyard_name, v.vineyard_id, wv.varietal_name, wv.varietal_id,
            ci.vintage_year, ci.purchase_price,
            COUNT(tn.note_id) AS note_count,
            ROUND(AVG(tn.body_rating), 1) AS avg_body,
            ROUND(AVG(tn.acidity_rating), 1) AS avg_acidity,
            ROUND(AVG(tn.tannin_rating), 1) AS avg_tannin,
            ROUND((AVG(tn.body_rating) + AVG(tn.acidity_rating) + AVG(tn.tannin_rating)) / 3, 1) AS overall_avg,
            (SELECT ROUND(AVG(wr.rating), 1) FROM wine_ratings wr WHERE wr.bottle_id = ci.bottle_id) AS avg_wine_rating,
            (SELECT COUNT(*) FROM wine_ratings wr2 WHERE wr2.bottle_id = ci.bottle_id) AS rating_count
     FROM cellar_inventory ci
     JOIN vineyards v ON v.vineyard_id = ci.vineyard_id
     JOIN wine_varietals wv ON wv.varietal_id = ci.varietal_id
     JOIN tasting_notes tn ON tn.bottle_id = ci.bottle_id AND tn.is_deleted = 0
     WHERE ci.is_deleted = 0
     GROUP BY ci.bottle_id, v.vineyard_name, v.vineyard_id, wv.varietal_name, wv.varietal_id, ci.vintage_year, ci.purchase_price
     ORDER BY overall_avg DESC"
)->fetchAll();

// Selected wines from query string (ids[]=1&ids[]=2)
$selectedIds = array_map('intval', $_GET['ids'] ?? []);
$selected = $selectedIds ? array_filter($pool, fn($w) => in_array((int)$w['bottle_id'], $selectedIds)) : [];

include __DIR__ . '/includes/header.php';
?>
<div class="page-header">
  <div>
    <h1>Wine Comparison</h1>
    <p class="subtitle">Select wines to compare their tasting note ratings side by side</p>
  </div>
</div>

<div class="card" style="margin-bottom:16px;">
  <h3 style="margin-bottom:10px;">Select Wines to Compare</h3>
  <p style="font-size:12px;color:var(--ink-soft);margin-bottom:10px;">
    Filter wines below, then check the ones you want to compare. Click "Compare Selected" when ready.
  </p>

  <div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:10px;align-items:flex-end;">
    <div class="field" style="margin-bottom:0;min-width:150px;flex:1;">
      <label style="font-size:11px;">Filter Vineyard</label>
      <select id="cmpFilterVineyard" style="padding:6px 10px;font-size:12px;border-radius:6px;border:1px solid var(--border-soft);background:rgba(255,255,255,0.05);color:var(--ink);">
        <option value="">All Vineyards</option>
        <?php foreach ($vineyards as $v): ?><option value="<?= $v['vineyard_id'] ?>"><?= sanitize($v['vineyard_name']) ?></option><?php endforeach; ?>
      </select>
    </div>
    <div class="field" style="margin-bottom:0;min-width:150px;flex:1;">
      <label style="font-size:11px;">Filter Varietal</label>
      <select id="cmpFilterVarietal" style="padding:6px 10px;font-size:12px;border-radius:6px;border:1px solid var(--border-soft);background:rgba(255,255,255,0.05);color:var(--ink);">
        <option value="">All Varietals</option>
        <?php foreach ($varietals as $v): ?><option value="<?= $v['varietal_id'] ?>"><?= sanitize($v['varietal_name']) ?></option><?php endforeach; ?>
      </select>
    </div>
    <button class="btn btn-primary btn-sm" id="cmpCompareBtn" disabled>Compare Selected (<span id="cmpCount">0</span>)</button>
    <button class="btn btn-outline btn-sm" id="cmpClearBtn" style="display:none;">Clear All</button>
  </div>

  <div class="table-wrap" style="max-height:340px;overflow-y:auto;">
    <table style="font-size:12px;">
      <thead><tr><th style="width:30px;"></th><th>Wine</th><th>Varietal</th><th>Vintage</th><th>Notes</th><th>Score</th></tr></thead>
      <tbody id="cmpPool">
      <?php foreach ($pool as $w): ?>
        <tr class="cmp-row" data-vineyard="<?= $w['vineyard_id'] ?>" data-varietal="<?= $w['varietal_id'] ?>" data-bid="<?= $w['bottle_id'] ?>">
          <td><input type="checkbox" class="cmp-check" value="<?= $w['bottle_id'] ?>" <?= in_array((int)$w['bottle_id'], $selectedIds) ? 'checked' : '' ?>></td>
          <td><?= sanitize($w['vineyard_name']) ?></td>
          <td><?= sanitize($w['varietal_name']) ?></td>
          <td><?= (int)$w['vintage_year'] ?></td>
          <td><?= (int)$w['note_count'] ?></td>
          <td><?= $w['overall_avg'] ?>/5</td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$pool): ?><tr><td colspan="6" style="color:var(--ink-soft);text-align:center;">No wines with tasting notes yet.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php if ($selected): ?>
<div class="card">
  <h3 style="margin-bottom:14px;">Comparison — <?= count($selected) ?> Wine<?= count($selected) === 1 ? '' : 's' ?></h3>
  <div class="compare-grid">
    <?php foreach ($selected as $w): ?>
      <div class="compare-card">
        <div class="compare-title"><?= sanitize($w['vineyard_name'] . ' ' . $w['varietal_name']) ?></div>
        <div class="compare-sub">Vintage <?= (int) $w['vintage_year'] ?> · <?= (int) $w['note_count'] ?> note<?= $w['note_count'] == 1 ? '' : 's' ?> · <?= money((float) $w['purchase_price']) ?></div>
        <div class="compare-stats">
          <div class="compare-stat"><span class="stat-label">Body</span><span class="stat-val"><?= $w['avg_body'] ?> / 5</span></div>
          <div class="compare-bar"><div class="fill" style="width:<?= ($w['avg_body']/5)*100 ?>%"></div></div>
          <div class="compare-stat"><span class="stat-label">Acidity</span><span class="stat-val"><?= $w['avg_acidity'] ?> / 5</span></div>
          <div class="compare-bar"><div class="fill" style="width:<?= ($w['avg_acidity']/5)*100 ?>%"></div></div>
          <div class="compare-stat"><span class="stat-label">Tannin</span><span class="stat-val"><?= $w['avg_tannin'] ?> / 5</span></div>
          <div class="compare-bar"><div class="fill" style="width:<?= ($w['avg_tannin']/5)*100 ?>%"></div></div>
          <div class="compare-stat" style="margin-top:6px;padding-top:6px;border-top:1px solid var(--border-soft);">
            <span class="stat-label" style="font-weight:700;">Overall</span><span class="stat-val"><?= $w['overall_avg'] ?> / 5</span>
          </div>
          <?php if ($w['rating_count'] > 0): ?>
          <div class="compare-stat"><span class="stat-label">Wine Rating</span><span class="stat-val"><?= avg_stars((float)$w['avg_wine_rating'], (int)$w['rating_count']) ?></span></div>
          <?php endif; ?>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
</div>
<?php endif; ?>

<script>
(function(){
  var checks = document.querySelectorAll('.cmp-check');
  var btn = document.getElementById('cmpCompareBtn');
  var cnt = document.getElementById('cmpCount');
  var clr = document.getElementById('cmpClearBtn');
  var fv = document.getElementById('cmpFilterVineyard');
  var fvar = document.getElementById('cmpFilterVarietal');
  var rows = document.querySelectorAll('.cmp-row');

  function update(){
    var sel = document.querySelectorAll('.cmp-check:checked');
    cnt.textContent = sel.length;
    btn.disabled = sel.length < 2;
    clr.style.display = sel.length > 0 ? '' : 'none';
  }
  checks.forEach(function(c){ c.addEventListener('change', update); });
  update();

  btn.addEventListener('click', function(){
    var ids = [];
    document.querySelectorAll('.cmp-check:checked').forEach(function(c){ ids.push(c.value); });
    window.location.href = 'comparison.php?' + ids.map(function(id){ return 'ids[]=' + id; }).join('&');
  });

  clr.addEventListener('click', function(){
    checks.forEach(function(c){ c.checked = false; }); update();
  });

  function applyFilter(){
    var vine = fv.value, vari = fvar.value;
    rows.forEach(function(r){
      var show = true;
      if(vine && r.dataset.vineyard !== vine) show = false;
      if(vari && r.dataset.varietal !== vari) show = false;
      r.style.display = show ? '' : 'none';
    });
  }
  fv.addEventListener('change', applyFilter);
  fvar.addEventListener('change', applyFilter);
})();
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
