<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_login();
require_once __DIR__ . '/controllers/vineyard_controller.php';

$pageTitle = 'Vineyards';
$showArchived = isset($_GET['archived']) && is_admin();
$allVineyards = $showArchived ? Vineyard::trashed() : Vineyard::all();

$highlightId = $_GET["highlight"] ?? null;
if ($highlightId && !isset($_GET["page"])) {
    $targetPage = page_of_item($allVineyards, "vineyard_id", $highlightId, 12);
    if ($targetPage && $targetPage > 1) {
        redirect("vineyards.php?highlight=" . urlencode($highlightId) . "&page=" . $targetPage);
    }
}

[$vineyards, $pageMeta] = paginate($allVineyards, 12);
$regions = Region::all();
$canEdit = is_admin();

include __DIR__ . '/includes/header.php';
?>
<div class="page-header">
  <div><h1>Vineyards<?= $showArchived ? ' — Archived' : '' ?></h1><p class="subtitle"><?= count($allVineyards) ?> <?= $showArchived ? 'archived vineyards' : 'partner vineyards' ?></p></div>
  <div style="display:flex;gap:10px;">
    <?php if ($canEdit): ?><a class="btn btn-outline btn-sm" href="vineyards.php<?= $showArchived ? '' : '?archived=1' ?>"><?= icon('archive') ?> <?= $showArchived ? 'Back to Active' : 'View Archived' ?></a><?php endif; ?>
    <?php if ($canEdit && !$showArchived): ?><button class="btn btn-primary" data-open-modal="addVineyardModal"><?= icon('plus') ?> Add Vineyard</button><?php endif; ?>
  </div>
</div>

<div class="toolbar">
  <div class="filter-bar"><input type="text" placeholder="Search vineyards..." data-filter-input=".filterable-row" style="width:260px;"></div>
  <div class="view-toggle">
    <button type="button" class="active" data-view="grid"><?= icon('grid') ?> Grid</button>
    <button type="button" data-view="table"><?= icon('list') ?> Table</button>
  </div>
</div>

<?php if (!$vineyards): ?>
  <div class="empty-state card"><div class="icon"><?= icon('vineyard') ?></div><p><?= $showArchived ? 'No archived vineyards.' : 'No vineyards on file yet.' ?></p></div>
<?php else: ?>

<div class="entity-grid" id="gridView">
  <?php foreach ($vineyards as $v): ?>
  <div class="entity-card filterable-row" data-item-id="<?= $v["vineyard_id"] ?>" data-filter-text="<?= sanitize($v["vineyard_name"] . ' ' . $v['region_name']) ?>">
    <div class="thumb">
      <?php if (!empty($v['image_path'])): ?><img src="<?= sanitize(upload_url($v['image_path'])) ?>" alt=""><?php else: ?><?= icon('vineyard') ?><?php endif; ?>
    </div>
    <div class="body">
      <h4><?= sanitize($v['vineyard_name']) ?></h4>
      <div class="meta-row"><span><?= sanitize($v['region_name']) ?>, <?= sanitize($v['country']) ?></span></div>
      <div class="meta-row"><span>Est. <?= (int) $v['established_year'] ?></span><span><?= sanitize($v['contact_phone'] ?: '—') ?></span></div>
      <div style="margin-top:8px;"><span class="status-pill status-<?= $v['is_active'] ? 'active' : 'inactive' ?>"><?= $v['is_active'] ? 'Active' : 'Inactive' ?></span></div>
    </div>
    <?php if ($canEdit && !$showArchived): ?>
    <div class="footer-actions">
      <button class="btn btn-outline btn-sm" data-open-modal="viewVineyard<?= $v['vineyard_id'] ?>">View</button>
      <button class="btn btn-outline btn-sm" data-open-modal="editVineyard<?= $v['vineyard_id'] ?>"><?= icon('edit') ?> Edit</button>
      <form method="post" action="vineyards.php" data-confirm="Archive this vineyard?" style="display:inline;">
        <?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="vineyard_id" value="<?= $v['vineyard_id'] ?>">
        <button type="submit" class="btn btn-danger btn-sm"><?= icon('archive') ?> Archive</button>
      </form>
    </div>
    <?php elseif ($canEdit && $showArchived): ?>
    <div class="footer-actions">
      <form method="post" action="vineyards.php" style="display:inline;">
        <?= csrf_field() ?><input type="hidden" name="action" value="restore"><input type="hidden" name="vineyard_id" value="<?= $v['vineyard_id'] ?>">
        <button type="submit" class="btn btn-outline btn-sm"><?= icon('restore') ?> Restore</button>
      </form>
    </div>
    <?php endif; ?>
  </div>
  <?php endforeach; ?>
</div>

<div class="table-wrap" id="tableView" style="display:none;">
  <table>
    <thead><tr><th></th><th>Vineyard</th><th>Region</th><th>Established</th><th>Phone</th><th>Status</th><?php if ($canEdit && !$showArchived): ?><th></th><?php endif; ?></tr></thead>
    <tbody>
    <?php foreach ($vineyards as $v): ?>
      <tr class="filterable-row" data-filter-text="<?= sanitize($v['vineyard_name'] . ' ' . $v['region_name']) ?>">
        <td>
          <div style="width:36px;height:36px;border-radius:6px;overflow:hidden;background:var(--cream);display:flex;align-items:center;justify-content:center;color:var(--wine-accent);">
            <?php if (!empty($v['image_path'])): ?><img src="<?= sanitize(upload_url($v['image_path'])) ?>" style="width:100%;height:100%;object-fit:cover;"><?php else: ?><?= icon('vineyard') ?><?php endif; ?>
          </div>
        </td>
        <td><?= sanitize($v['vineyard_name']) ?></td>
        <td><?= sanitize($v['region_name']) ?>, <?= sanitize($v['country']) ?></td>
        <td><?= (int) $v['established_year'] ?></td>
        <td><?= sanitize($v['contact_phone'] ?: '—') ?></td>
        <td><span class="status-pill status-<?= $v['is_active'] ? 'active' : 'inactive' ?>"><?= $v['is_active'] ? 'Active' : 'Inactive' ?></span></td>
        <?php if ($canEdit && !$showArchived): ?>
        <td class="table-actions"><button class="btn btn-outline btn-sm" data-open-modal="editVineyard<?= $v['vineyard_id'] ?>">Edit</button></td>
        <?php endif; ?>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>

<?php if ($canEdit && !$showArchived): foreach ($vineyards as $v): ?>
<div class="modal-overlay" id="editVineyard<?= $v['vineyard_id'] ?>">
  <div class="modal modal-lg">
    <div class="modal-header"><h3>Edit Vineyard</h3><button class="modal-close" data-close-modal>&times;</button></div>

    <?php if (!empty($v['image_path'])): ?>
    <div style="padding:16px 22px 0;display:flex;align-items:center;gap:12px;">
      <img src="<?= sanitize(upload_url($v['image_path'])) ?>" style="height:56px;width:56px;object-fit:cover;border-radius:6px;">
      <form method="post" action="vineyards.php" data-confirm="Remove this vineyard's photo?">
        <?= csrf_field() ?><input type="hidden" name="action" value="remove_image"><input type="hidden" name="vineyard_id" value="<?= $v['vineyard_id'] ?>">
        <button type="submit" class="btn btn-outline remove-image-btn btn-sm"><?= icon('trash') ?> Remove Image</button>
      </form>
    </div>
    <?php endif; ?>

    <form method="post" action="vineyards.php" enctype="multipart/form-data">
      <div class="modal-body">
        <?= csrf_field() ?><input type="hidden" name="action" value="update"><input type="hidden" name="vineyard_id" value="<?= $v['vineyard_id'] ?>">
        <div class="form-grid">
          <div class="field"><label>Vineyard Name <?= req() ?></label><input type="text" name="vineyard_name" value="<?= sanitize($v['vineyard_name']) ?>" required></div>
          <div class="field">
            <label>Region</label>
            <select name="region_id" class="region-select" required>
              <?php foreach ($regions as $r): ?><option value="<?= $r['region_id'] ?>" <?= $r['region_id'] == $v['region_id'] ? 'selected' : '' ?>><?= sanitize($r['region_name'] . ', ' . $r['country']) ?></option><?php endforeach; ?>
              <option value="new">+ Add a new region…</option>
            </select>
            <div class="new-region-fields" style="display:none;margin-top:10px;">
              <div class="form-grid">
                <div class="field"><label>New Region Name</label><input type="text" name="new_region_name" placeholder="e.g. Willamette Valley"></div>
                <div class="field"><label>Country</label><input type="text" name="new_region_country" placeholder="e.g. United States"></div>
              </div>
            </div>
          </div>
          <div class="field"><label>Established Year <?= req() ?></label><input type="number" name="established_year" value="<?= (int) $v['established_year'] ?>" required></div>
          <div class="field"><label>Contact Phone</label><input type="text" name="contact_phone" value="<?= sanitize($v['contact_phone']) ?>"></div>
          <div class="field"><label>Status</label>
            <label style="display:flex;align-items:center;gap:8px;font-weight:400;font-size:13.5px;"><input type="checkbox" name="is_active" style="width:auto;" <?= $v['is_active'] ? 'checked' : '' ?>> Active</label>
          </div>
          <div class="field"><label><?= empty($v['image_path']) ? 'Photo' : 'Replace Photo' ?></label><input type="file" name="vineyard_image" accept="image/*"></div>
        </div>
      </div>
      <div class="modal-footer"><button type="button" class="btn btn-outline" data-close-modal>Cancel</button><button type="submit" class="btn btn-primary">Save Changes</button></div>
    </form>
  </div>
</div>
<?php endforeach; endif; ?>

<?php // View modals for highlight/search ?>
<?php foreach ($vineyards as $v): ?>
<div class="modal-overlay" id="viewVineyard<?= $v['vineyard_id'] ?>">
  <div class="modal">
    <div class="modal-header"><h3><?= sanitize($v['vineyard_name']) ?></h3><button class="modal-close" data-close-modal>&times;</button></div>
    <div class="modal-body">
      <?php if (!empty($v['image_path'])): ?><img src="<?= sanitize(upload_url($v['image_path'])) ?>" style="border-radius:8px;margin-bottom:14px;max-height:220px;object-fit:cover;width:100%;"><?php endif; ?>
      <p><strong>Region:</strong> <?= sanitize($v['region_name'] . ', ' . $v['country']) ?></p>
      <p><strong>Established:</strong> <?= (int) $v['established_year'] ?></p>
      <p><strong>Phone:</strong> <?= sanitize($v['contact_phone'] ?: '—') ?></p>
      <p><strong>Status:</strong> <?= $v['is_active'] ? 'Active' : 'Inactive' ?></p>
    </div>
  </div>
</div>
<?php endforeach; ?>

<?= render_pagination($pageMeta) ?>

<?php endif; ?>

<?php if ($canEdit && !$showArchived): ?>
<div class="modal-overlay" id="addVineyardModal">
  <div class="modal modal-lg">
    <div class="modal-header"><h3>Add Vineyard</h3><button class="modal-close" data-close-modal>&times;</button></div>
    <form method="post" action="vineyards.php" enctype="multipart/form-data">
      <div class="modal-body">
        <?= csrf_field() ?><input type="hidden" name="action" value="create">
        <div class="form-grid">
          <div class="field"><label>Vineyard Name <?= req() ?></label><input type="text" name="vineyard_name" required></div>
          <div class="field">
            <label>Region</label>
            <select name="region_id" class="region-select" required>
              <option value="" disabled selected>Select region</option>
              <?php foreach ($regions as $r): ?><option value="<?= $r['region_id'] ?>"><?= sanitize($r['region_name'] . ', ' . $r['country']) ?></option><?php endforeach; ?>
              <option value="new">+ Add a new region…</option>
            </select>
            <div class="new-region-fields" style="display:none;margin-top:10px;">
              <div class="form-grid">
                <div class="field"><label>New Region Name</label><input type="text" name="new_region_name" placeholder="e.g. Willamette Valley"></div>
                <div class="field"><label>Country</label><input type="text" name="new_region_country" placeholder="e.g. United States"></div>
              </div>
            </div>
          </div>
          <div class="field"><label>Established Year <?= req() ?></label><input type="number" name="established_year" required></div>
          <div class="field"><label>Contact Phone</label><input type="text" name="contact_phone"></div>
          <div class="field field-span-2"><label>Photo (optional)</label><input type="file" name="vineyard_image" accept="image/*"></div>
        </div>
      </div>
      <div class="modal-footer"><button type="button" class="btn btn-outline" data-close-modal>Cancel</button><button type="submit" class="btn btn-primary">Add Vineyard</button></div>
    </form>
  </div>
</div>
<?php endif; ?>

<?php include __DIR__ . '/includes/footer.php'; ?>
