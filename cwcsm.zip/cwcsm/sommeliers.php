<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_login();
require_once __DIR__ . '/controllers/sommelier_controller.php';

$pageTitle = 'Sommeliers';
$allSommeliers = Sommelier::all();
[$sommeliers, $pageMeta] = paginate($allSommeliers, 12);
$canAdd = is_admin();

include __DIR__ . '/includes/header.php';
?>
<div class="page-header">
  <div>
    <h1>Sommeliers</h1>
    <p class="subtitle"><?= count($allSommeliers) ?> sommeliers on the team</p>
  </div>
  <?php if ($canAdd): ?><button class="btn btn-primary" data-open-modal="addSommelierModal"><?= icon('plus') ?> Add Sommelier</button><?php endif; ?>
</div>

<div class="toolbar">
  <div class="filter-bar">
    <input type="text" placeholder="Search by name..." data-filter-input=".filterable-row" style="width:260px;">
  </div>
  <div class="view-toggle">
    <button type="button" class="active" data-view="grid"><?= icon('grid') ?> Grid</button>
    <button type="button" data-view="table"><?= icon('list') ?> Table</button>
  </div>
</div>

<?php if (!$sommeliers): ?>
  <div class="empty-state card"><div class="icon"><?= icon('people') ?></div><p>No sommeliers registered yet.</p></div>
<?php else: ?>
<div class="entity-grid" id="gridView">
  <?php foreach ($sommeliers as $s): ?>
    <a class="entity-card filterable-row" data-filter-text="<?= sanitize($s['first_name'] . ' ' . $s['last_name']) ?>" href="sommelier_detail.php?id=<?= $s['sommelier_id'] ?>" style="text-decoration:none;color:inherit;">
      <div class="thumb">
        <?php if (!empty($s['photo_path'])): ?>
          <img src="<?= sanitize(upload_url($s['photo_path'])) ?>" alt="">
        <?php else: ?>
          <?= icon('user') ?>
        <?php endif; ?>
      </div>
      <div class="body">
        <h4><?= sanitize($s['first_name'] . ' ' . $s['last_name']) ?></h4>
        <div class="meta-row"><span>Hired <?= format_date($s['hire_date']) ?></span></div>
        <div class="meta-row"><span><?= (int) $s['cert_count'] ?> certification<?= $s['cert_count'] == 1 ? '' : 's' ?></span><span><?= (int) $s['note_count'] ?> notes</span></div>
      </div>
    </a>
  <?php endforeach; ?>
</div>

<div class="table-wrap" id="tableView" style="display:none;">
  <table>
    <thead><tr><th></th><th>Name</th><th>Hired</th><th>Certifications</th><th>Tasting Notes</th></tr></thead>
    <tbody>
      <?php foreach ($sommeliers as $s): ?>
      <tr class="filterable-row" data-filter-text="<?= sanitize($s['first_name'] . ' ' . $s['last_name']) ?>" style="curs40pxointer;"40pxlick="window.location='sommelier_detail.php?id=<?= $s['sommelier_id'] ?>'">
        <td>
          <span class="avatar" style="width:32px;height:32px;">
            <?php if (!empty($s['photo_path'])): ?><img src="<?= sanitize(upload_url($s['photo_path'])) ?>" style="width:64px;height:64px;object-fit:cover;border-radius:50%;"><?php else: ?><?= strtoupper(substr($s['first_name'], 0, 1) . substr($s['last_name'], 0, 1)) ?><?php endif; ?>
          </span>
        </td>
        <td><?= sanitize($s['first_name'] . ' ' . $s['last_name']) ?></td>
        <td><?= format_date($s['hire_date']) ?></td>
        <td><?= (int) $s['cert_count'] ?></td>
        <td><?= (int) $s['note_count'] ?></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php endif; ?>

<?= render_pagination($pageMeta) ?>

<?php if ($canAdd): ?>
<div class="modal-overlay" id="addSommelierModal">
  <div class="modal modal-lg">
    <div class="modal-header"><h3>Add Sommelier</h3><button class="modal-close" data-close-modal>&times;</button></div>
    <form method="post" action="sommeliers.php">
      <div class="modal-body">
        <?= csrf_field() ?><input type="hidden" name="action" value="create_sommelier">
        <div class="form-grid">
          <div class="field"><label>First Name <?= req() ?></label><input type="text" name="first_name" required></div>
          <div class="field"><label>Last Name <?= req() ?></label><input type="text" name="last_name" required></div>
          <div class="field"><label>Username <?= req() ?></label><input type="text" name="username" required></div>
          <div class="field"><label>Email <?= req() ?></label><input type="email" name="email" required></div>
          <div class="field"><label>Hire Date</label><input type="date" name="hire_date" value="<?= date('Y-m-d') ?>" required></div>
          <div class="field"><label>Temporary Password <?= req() ?></label><input type="password" name="password" minlength="8" required></div>
        </div>
        <p class="hint">This creates the login for them directly — share the temporary password so they can sign in and change it from their profile.</p>
      </div>
      <div class="modal-footer"><button type="button" class="btn btn-outline" data-close-modal>Cancel</button><button type="submit" class="btn btn-primary">Add Sommelier</button></div>
    </form>
  </div>
</div>
<?php endif; ?>

<?php include __DIR__ . '/includes/footer.php'; ?>
