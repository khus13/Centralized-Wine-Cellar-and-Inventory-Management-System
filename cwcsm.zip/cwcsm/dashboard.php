<?php
/** @noinspection PhpUndefinedMethodInspection */
require_once __DIR__ . '/includes/bootstrap.php';
require_login();

$user = current_user();
$pageTitle = 'Dashboard';

// ---- Role-specific data only ----
$myNotes = []; $myRatings = []; $recommendations = []; $myCerts = [];
$inventoryByVineyard = []; $mySupplierRatings = [];
$bottleCount = 0; $totalCost = 0; $roleCounts = []; $totalEmployees = 0; $activeCerts = 0;
$topWines = []; $bottomWines = []; $topSuppliers = []; $bottomSuppliers = [];
$expiringCerts = [];

if ($user['role'] === 'sommelier' && !empty($user['profile_id'])) {
    // Sommelier sees ONLY their own work
    try { $myNotes = TastingNote::bySommelier((int) $user['profile_id']); } catch (Throwable $e) { $myNotes = []; }
    try { $myRatings = WineRating::bySommelier((int) $user['profile_id']); } catch (Throwable $e) { $myRatings = []; }
    try { $recommendations = WineRating::recommendationsForSommelier((int) $user['profile_id']); } catch (Throwable $e) { $recommendations = []; }
    try { $myCerts = Certification::forSommelier((int) $user['profile_id']); } catch (Throwable $e) { $myCerts = []; }
    try {
        $expiringCerts = Certification::expiringSoon(30);
        $expiringCerts = array_values(array_filter($expiringCerts, fn($n) => $n['first_name'] === $user['first_name'] && $n['last_name'] === $user['last_name']));
    } catch (Throwable $e) { $expiringCerts = []; }

} elseif ($user['role'] === 'cellar_manager' && !empty($user['profile_id'])) {
    // Cellar Manager sees ONLY their own inventory work
    try { $bottleCount = Inventory::totalBottleCount(); } catch (Throwable $e) {}
    try { $totalCost = Inventory::totalInventoryCost(); } catch (Throwable $e) {}
    try { $inventoryByVineyard = Inventory::valueByVineyard(); } catch (Throwable $e) {}

} elseif ($user['role'] === 'admin') {
    // Admin sees everything
    try { $bottleCount = Inventory::totalBottleCount(); } catch (Throwable $e) {}
    try { $totalCost = Inventory::totalInventoryCost(); } catch (Throwable $e) {}
    try { $roleCounts = Account::roleCounts(); } catch (Throwable $e) { $roleCounts = ['admin'=>0,'sommelier'=>0,'cellar_manager'=>0]; }
    $totalEmployees = ($roleCounts['admin'] ?? 0) + ($roleCounts['sommelier'] ?? 0) + ($roleCounts['cellar_manager'] ?? 0);
    try { $activeCerts = Certification::activeCount(); } catch (Throwable $e) {}
    try { $expiringCerts = Certification::expiringSoon(30); } catch (Throwable $e) {}
    try { $topWines = WineRating::performing('top', 5); } catch (Throwable $e) {}
    try { $bottomWines = WineRating::performing('bottom', 5); } catch (Throwable $e) {}
    try { $topSuppliers = SupplierRating::performing('top', 5); } catch (Throwable $e) {}
    try { $bottomSuppliers = SupplierRating::performing('bottom', 5); } catch (Throwable $e) {}
}

// CSV export
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="cwcsm_dashboard_' . date('Y-m-d') . '.csv"');
    $fp = fopen('php://output', 'w');
    if ($user['role'] === 'sommelier') {
        fputcsv($fp, ['Wine', 'Tasting Date', 'Body', 'Acidity', 'Tannin', 'Remarks']);
        foreach ($myNotes as $n) {
            fputcsv($fp, [$n['vineyard_name'] . ' ' . $n['varietal_name'] . ' (' . $n['vintage_year'] . ')', $n['tasting_date'], $n['body_rating'], $n['acidity_rating'], $n['tannin_rating'], $n['remarks'] ?? '']);
        }
    } elseif ($user['role'] === 'cellar_manager') {
        fputcsv($fp, ['Vineyard', 'Total Inventory Value']);
        foreach ($inventoryByVineyard as $row) { fputcsv($fp, [$row['vineyard_name'], $row['total_value']]); }
        fputcsv($fp, []); fputcsv($fp, ['Total Bottles', $bottleCount]); fputcsv($fp, ['Total Cost', $totalCost]);
    } else {
        fputcsv($fp, ['Metric', 'Value']);
        fputcsv($fp, ['Total Bottles', $bottleCount]); fputcsv($fp, ['Total Inventory Cost', $totalCost]);
        fputcsv($fp, ['Sommeliers', $roleCounts['sommelier'] ?? 0]); fputcsv($fp, ['Cellar Managers', $roleCounts['cellar_manager'] ?? 0]);
        if ($topWines) { fputcsv($fp, []); fputcsv($fp, ['Top-Rated Wines','Avg','Raters']); foreach ($topWines as $w) fputcsv($fp, [$w['vineyard_name'].' '.$w['varietal_name'], round($w['avg_rating'],1), $w['rater_count']]); }
        if ($topSuppliers) { fputcsv($fp, []); fputcsv($fp, ['Top Suppliers','Avg','Raters']); foreach ($topSuppliers as $s) fputcsv($fp, [$s['supplier_contact_name'], round($s['avg_rating'],1), $s['rater_count']]); }
    }
    fclose($fp); exit;
}

$extraScripts = ['https://cdn.jsdelivr.net/npm/chart.js@4.4.4/dist/chart.umd.min.js', 'assets/js/dashboard.js'];
include __DIR__ . '/includes/header.php';
?>
<?php if ($expiringCerts): ?>
<div class="flash flash-error" style="margin-bottom:14px;">
  <?= count($expiringCerts) ?> certification<?= count($expiringCerts) === 1 ? '' : 's' ?> expiring within 30 days.
</div>
<?php endif; ?>

<div class="page-header">
  <div>
    <h1>Welcome back, <?= sanitize($user['first_name']) ?></h1>
    <p class="subtitle"><?= ucfirst(str_replace('_', ' ', $user['role'])) ?> Dashboard</p>
  </div>
  <div style="display:flex;gap:8px;">
    <button class="btn btn-outline btn-sm" data-open-modal="dashSummaryModal"><?= icon('notes') ?> Summary</button>
    <a class="btn btn-outline btn-sm" href="dashboard.php?export=csv"><?= icon('archive') ?> Export</a>
  </div>
</div>

<!-- ============= SOMMELIER DASHBOARD ============= -->
<?php if ($user['role'] === 'sommelier'): ?>

<div class="stat-grid">
  <div class="stat-card"><div class="stat-icon"><?= icon('notes') ?></div><div><div class="stat-label">My Tasting Notes</div><div class="stat-value"><?= count($myNotes) ?></div></div></div>
  <div class="stat-card"><div class="stat-icon"><?= icon('wine') ?></div><div><div class="stat-label">My Wine Ratings</div><div class="stat-value"><?= count($myRatings) ?></div></div></div>
  <div class="stat-card"><div class="stat-icon"><?= icon('certificate') ?></div><div><div class="stat-label">My Certifications</div><div class="stat-value"><?= count($myCerts ?? []) ?></div></div></div>
</div>

<div class="card" style="margin-bottom:16px;">
  <h3>Recent Tasting Notes</h3>
  <?php if (!$myNotes): ?><p style="color:var(--ink-muted);font-size:13px;">No tasting notes yet. <a href="tasting_notes.php">Create one →</a></p>
  <?php else: ?>
  <div class="table-wrap" style="margin-top:10px;">
    <table><thead><tr><th>Wine</th><th>Date</th><th>Body</th><th>Acidity</th><th>Tannin</th><th>Remarks</th></tr></thead>
    <tbody>
    <?php foreach (array_slice($myNotes, 0, 8) as $n): ?>
      <tr>
        <td><?= sanitize($n['vineyard_name'] . ' ' . $n['varietal_name'] . ' \'' . substr($n['vintage_year'], -2)) ?></td>
        <td><?= format_date($n['tasting_date']) ?></td>
        <td><?= star_rating((int) $n['body_rating']) ?></td>
        <td><?= star_rating((int) $n['acidity_rating']) ?></td>
        <td><?= star_rating((int) $n['tannin_rating']) ?></td>
        <td style="max-width:160px;"><?= sanitize($n['remarks'] ?? '—') ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody></table>
  </div>
  <?php if (count($myNotes) > 8): ?><p style="margin-top:8px;font-size:12px;"><a href="tasting_notes.php">View all <?= count($myNotes) ?> →</a></p><?php endif; ?>
  <?php endif; ?>
</div>

<?php if ($recommendations): ?>
<div class="card" style="margin-bottom:16px;">
  <h3>Recommended for You</h3>
  <p style="font-size:12px;color:var(--ink-muted);margin-bottom:10px;">Wines of varietals you've rated highly that you haven't reviewed yet.</p>
  <div class="rec-grid">
    <?php foreach ($recommendations as $rec): ?>
      <div class="rec-card">
        <span class="rec-varietal"><?= sanitize($rec['varietal_name']) ?></span>
        <h4><?= sanitize($rec['vineyard_name']) ?> '<?= (int) $rec['vintage_year'] ?></h4>
        <span class="rec-meta"><?= $rec['rater_count'] > 0 ? avg_stars((float) $rec['avg_rating'], (int) $rec['rater_count']) : 'Not yet rated' ?></span>
      </div>
    <?php endforeach; ?>
  </div>
</div>
<?php endif; ?>

<!-- ============= CELLAR MANAGER DASHBOARD ============= -->
<?php elseif ($user['role'] === 'cellar_manager'): ?>

<div class="stat-grid">
  <div class="stat-card"><div class="stat-icon"><?= icon('wine') ?></div><div><div class="stat-label">Total Bottles</div><div class="stat-value"><?= number_format($bottleCount) ?></div></div></div>
  <div class="stat-card"><div class="stat-icon"><?= icon('archive') ?></div><div><div class="stat-label">Inventory Value</div><div class="stat-value"><?= money($totalCost) ?></div></div></div>
  <div class="stat-card"><div class="stat-icon"><?= icon('truck') ?></div><div><div class="stat-label">Vineyards Tracked</div><div class="stat-value"><?= count($inventoryByVineyard) ?></div></div></div>
</div>

<div class="chart-grid">
  <div class="chart-card"><h3>Inventory Value by Vineyard</h3><canvas id="inventoryByVineyardChart"></canvas></div>
  <div class="chart-card"><h3>Wine Distribution by Varietal</h3><canvas id="varietalDistributionChart"></canvas></div>
</div>

<div class="card">
  <h3>Inventory Breakdown</h3>
  <div class="table-wrap" style="margin-top:10px;">
    <table><thead><tr><th>Vineyard</th><th>Value</th></tr></thead>
    <tbody>
    <?php foreach ($inventoryByVineyard as $row): ?><tr><td><?= sanitize($row['vineyard_name']) ?></td><td><?= money((float) $row['total_value']) ?></td></tr><?php endforeach; ?>
    <?php if (!$inventoryByVineyard): ?><tr><td colspan="2" style="color:var(--ink-muted);">No inventory data.</td></tr><?php endif; ?>
    </tbody></table>
  </div>
</div>

<!-- ============= ADMIN DASHBOARD ============= -->
<?php else: ?>

<div class="stat-grid">
  <div class="stat-card"><div class="stat-icon"><?= icon('wine') ?></div><div><div class="stat-label">Bottles</div><div class="stat-value"><?= number_format($bottleCount) ?></div></div></div>
  <div class="stat-card"><div class="stat-icon"><?= icon('archive') ?></div><div><div class="stat-label">Inventory Value</div><div class="stat-value"><?= money($totalCost) ?></div></div></div>
  <div class="stat-card"><div class="stat-icon"><?= icon('people') ?></div><div><div class="stat-label">Team</div><div class="stat-value"><?= $totalEmployees ?></div><div class="stat-sub"><?= $roleCounts['sommelier'] ?> Som · <?= $roleCounts['cellar_manager'] ?> CM · <?= $roleCounts['admin'] ?> Admin</div></div></div>
  <div class="stat-card"><div class="stat-icon"><?= icon('certificate') ?></div><div><div class="stat-label">Active Certs</div><div class="stat-value"><?= $activeCerts ?></div></div></div>
</div>

<div class="chart-grid">
  <div class="chart-card"><h3>Inventory by Vineyard</h3><canvas id="inventoryByVineyardChart"></canvas></div>
  <div class="chart-card"><h3>Varietal Distribution</h3><canvas id="varietalDistributionChart"></canvas></div>
  <div class="chart-card"><h3>Certifications Expiring</h3><canvas id="certExpiringChart"></canvas></div>
  <div class="chart-card"><h3>Monthly Tasting Notes</h3><canvas id="monthlyNotesChart"></canvas></div>
</div>

<?php if ($topWines || $bottomWines): ?>
<div class="card" style="margin-bottom:14px;">
  <h3>Wine Performance</h3>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-top:10px;">
    <div>
      <h4 style="font-size:11px;color:var(--ink-muted);text-transform:uppercase;letter-spacing:.5px;">Top Rated</h4>
      <?php foreach ($topWines as $w): ?>
        <div style="display:flex;justify-content:space-between;padding:5px 0;border-bottom:1px dashed var(--border);font-size:12px;">
          <span><?= sanitize($w['vineyard_name'] . ' ' . $w['varietal_name']) ?></span>
          <span><?= avg_stars((float)$w['avg_rating'], (int)$w['rater_count']) ?></span>
        </div>
      <?php endforeach; if (!$topWines): ?><p class="rating-empty">No data.</p><?php endif; ?>
    </div>
    <div>
      <h4 style="font-size:11px;color:var(--ink-muted);text-transform:uppercase;letter-spacing:.5px;">Lowest Rated</h4>
      <?php foreach ($bottomWines as $w): ?>
        <div style="display:flex;justify-content:space-between;padding:5px 0;border-bottom:1px dashed var(--border);font-size:12px;">
          <span><?= sanitize($w['vineyard_name'] . ' ' . $w['varietal_name']) ?></span>
          <span><?= avg_stars((float)$w['avg_rating'], (int)$w['rater_count']) ?></span>
        </div>
      <?php endforeach; if (!$bottomWines): ?><p class="rating-empty">No data.</p><?php endif; ?>
    </div>
  </div>
</div>
<?php endif; ?>

<?php if ($topSuppliers || $bottomSuppliers): ?>
<div class="card">
  <h3>Supplier Performance</h3>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-top:10px;">
    <div>
      <h4 style="font-size:11px;color:var(--ink-muted);text-transform:uppercase;letter-spacing:.5px;">Top Rated</h4>
      <?php foreach ($topSuppliers as $s): ?>
        <div style="display:flex;justify-content:space-between;padding:5px 0;border-bottom:1px dashed var(--border);font-size:12px;">
          <span><?= sanitize($s['supplier_contact_name']) ?></span><span><?= avg_stars((float)$s['avg_rating'], (int)$s['rater_count']) ?></span>
        </div>
      <?php endforeach; if (!$topSuppliers): ?><p class="rating-empty">No data.</p><?php endif; ?>
    </div>
    <div>
      <h4 style="font-size:11px;color:var(--ink-muted);text-transform:uppercase;letter-spacing:.5px;">Lowest Rated</h4>
      <?php foreach ($bottomSuppliers as $s): ?>
        <div style="display:flex;justify-content:space-between;padding:5px 0;border-bottom:1px dashed var(--border);font-size:12px;">
          <span><?= sanitize($s['supplier_contact_name']) ?></span><span><?= avg_stars((float)$s['avg_rating'], (int)$s['rater_count']) ?></span>
        </div>
      <?php endforeach; if (!$bottomSuppliers): ?><p class="rating-empty">No data.</p><?php endif; ?>
    </div>
  </div>
</div>
<?php endif; ?>

<?php endif; ?>

<!-- Summary Modal -->
<div class="modal-overlay" id="dashSummaryModal">
  <div class="modal"><div class="modal-header"><h3>Dashboard Summary</h3><button class="modal-close" data-close-modal>&times;</button></div>
  <div class="modal-body">
    <ul class="summary-list">
    <?php if ($user['role'] === 'sommelier'): ?>
      <li><span class="label">My Tasting Notes</span><span class="value"><?= count($myNotes) ?></span></li>
      <li><span class="label">My Wine Ratings</span><span class="value"><?= count($myRatings) ?></span></li>
      <li><span class="label">Certifications</span><span class="value"><?= count($myCerts ?? []) ?></span></li>
    <?php elseif ($user['role'] === 'cellar_manager'): ?>
      <li><span class="label">Total Bottles</span><span class="value"><?= number_format($bottleCount) ?></span></li>
      <li><span class="label">Inventory Value</span><span class="value"><?= money($totalCost) ?></span></li>
      <li><span class="label">Vineyards</span><span class="value"><?= count($inventoryByVineyard) ?></span></li>
    <?php else: ?>
      <li><span class="label">Total Bottles</span><span class="value"><?= number_format($bottleCount) ?></span></li>
      <li><span class="label">Inventory Value</span><span class="value"><?= money($totalCost) ?></span></li>
      <li><span class="label">Team Size</span><span class="value"><?= $totalEmployees ?></span></li>
      <li><span class="label">Active Certifications</span><span class="value"><?= $activeCerts ?></span></li>
    <?php endif; ?>
    </ul>
  </div></div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
