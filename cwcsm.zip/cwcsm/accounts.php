<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_role('admin');
require_once __DIR__ . '/controllers/account_controller.php';

$pageTitle = 'Accounts';
$allAccounts = Account::allWithRoles();
[$accounts, $pageMeta] = paginate($allAccounts, 15);
$myAccountId = (int) current_user()['account_id'];

include __DIR__ . '/includes/header.php';
?>
<div class="page-header">
  <div><h1>Accounts</h1><p class="subtitle"><?= count($allAccounts) ?> total accounts &middot; Admin accounts are seeded directly in MySQL, not via registration</p></div>
</div>

<div class="toolbar"><div class="filter-bar"><input type="text" placeholder="Search accounts..." data-filter-input=".filterable-row" style="width:260px;"></div></div>

<div class="table-wrap">
  <table style="font-size:12px;">
    <thead><tr><th style="width:36px;"></th><th>Name</th><th>Username</th><th>Email</th><th>Role</th><th style="width:56px;">Status</th><th>Actions</th></tr></thead>
    <tbody>
    <?php foreach ($accounts as $a): ?>
      <tr class="filterable-row <?= !$a['is_active'] ? 'archived-row' : '' ?>" data-filter-text="<?= sanitize($a['first_name'] . ' ' . $a['last_name'] . ' ' . $a['username']) ?>">
        <td>
          <span class="avatar" style="width:28px;height:28px;font-size:10px;">
            <?php if (!empty($a['photo_path'])): ?>
              <img src="<?= sanitize(upload_url($a['photo_path'])) ?>" alt="" style="width:100%;height:100%;object-fit:cover;border-radius:50%;">
            <?php else: ?>
              <?= strtoupper(substr($a['first_name'], 0, 1) . substr($a['last_name'], 0, 1)) ?>
            <?php endif; ?>
          </span>
        </td>
        <td style="white-space:nowrap;"><?= sanitize($a['first_name'] . ' ' . $a['last_name']) ?></td>
        <td><?= sanitize($a['username']) ?></td>
        <td style="max-width:180px;overflow:hidden;text-overflow:ellipsis;"><?= sanitize($a['email']) ?></td>
        <td><span class="role-badge role-<?= sanitize($a['role']) ?>" style="font-size:9px;"><?= sanitize(str_replace('_', ' ', $a['role'])) ?></span></td>
        <td><span class="status-pill status-<?= !$a['is_active'] ? 'inactive' : 'active' ?>" style="font-size:9px;"><?= !$a['is_active'] ? 'Off' : 'Active' ?></span></td>
        <td>
          <div style="display:flex;gap:4px;flex-wrap:nowrap;">
            <button class="btn btn-outline btn-sm" style="font-size:10px;padding:4px 8px;" data-open-modal="reset<?= $a['account_id'] ?>">Reset PW</button>
            <?php if ((int) $a['account_id'] !== $myAccountId): ?>
              <button class="btn btn-outline btn-sm" style="font-size:10px;padding:4px 8px;" data-open-modal="role<?= $a['account_id'] ?>">Role</button>
              <?php if (!$a['is_active']): ?>
                <form method="post" action="accounts.php" style="display:inline;"><?= csrf_field() ?><input type="hidden" name="action" value="reactivate"><input type="hidden" name="account_id" value="<?= $a['account_id'] ?>"><button type="submit" class="btn btn-outline btn-sm" style="font-size:10px;padding:4px 8px;">Reactivate</button></form>
              <?php else: ?>
                <form method="post" action="accounts.php" data-confirm="Deactivate this account?" style="display:inline;"><?= csrf_field() ?><input type="hidden" name="action" value="deactivate"><input type="hidden" name="account_id" value="<?= $a['account_id'] ?>"><button type="submit" class="btn btn-danger btn-sm" style="font-size:10px;padding:4px 8px;">Deactivate</button></form>
              <?php endif; ?>
            <?php endif; ?>
          </div>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>

<?= render_pagination($pageMeta) ?>

<?php foreach ($accounts as $a): ?>
<div class="modal-overlay" id="reset<?= $a['account_id'] ?>">
  <div class="modal">
    <div class="modal-header"><h3>Reset Password — <?= sanitize($a['username']) ?></h3><button class="modal-close" data-close-modal>&times;</button></div>
    <form method="post" action="accounts.php">
      <div class="modal-body">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="reset_password">
        <input type="hidden" name="account_id" value="<?= $a['account_id'] ?>">
        <div class="field"><label>New Password <?= req() ?></label><input type="password" name="new_password" minlength="8" required></div>
        <p class="hint">The user will use this password on their next sign-in.</p>
      </div>
      <div class="modal-footer"><button type="button" class="btn btn-outline" data-close-modal>Cancel</button><button type="submit" class="btn btn-primary">Reset Password</button></div>
    </form>
  </div>
</div>

<?php if ((int) $a['account_id'] !== $myAccountId): ?>
<div class="modal-overlay" id="role<?= $a['account_id'] ?>">
  <div class="modal">
    <div class="modal-header"><h3>Change Role — <?= sanitize($a['first_name'] . ' ' . $a['last_name']) ?></h3><button class="modal-close" data-close-modal>&times;</button></div>
    <form method="post" action="accounts.php" data-confirm="Change this user's role? Their access will change immediately.">
      <div class="modal-body">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="change_role">
        <input type="hidden" name="account_id" value="<?= $a['account_id'] ?>">
        <p style="font-size:13.5px;color:var(--ink-soft);margin-bottom:12px;">
          Current role: <span class="role-badge role-<?= sanitize($a['role']) ?>"><?= sanitize(str_replace('_', ' ', $a['role'])) ?></span>
        </p>
        <div class="field">
          <label>New Role <?= req() ?></label>
          <select name="new_role" required>
            <option value="sommelier" <?= $a['role'] === 'sommelier' ? 'disabled' : '' ?>>Sommelier</option>
            <option value="cellar_manager" <?= $a['role'] === 'cellar_manager' ? 'disabled' : '' ?>>Cellar Manager</option>
            <option value="admin" <?= $a['role'] === 'admin' ? 'disabled' : '' ?>>System Admin</option>
          </select>
        </div>
        <p class="hint">Promotions take effect right away. If the user still owns records tied to their current role (e.g. a Sommelier's tasting notes), reassign those first — the change is blocked to protect their work.</p>
      </div>
      <div class="modal-footer"><button type="button" class="btn btn-outline" data-close-modal>Cancel</button><button type="submit" class="btn btn-primary">Update Role</button></div>
    </form>
  </div>
</div>
<?php endif; ?>
<?php endforeach; ?>

<?php include __DIR__ . '/includes/footer.php'; ?>