<?php
$current = basename($_SERVER['SCRIPT_NAME']);
function nav_active(string $file, string $current): string
{
    return $file === $current ? 'active' : '';
}
$role = $_SESSION['role'] ?? '';

$cellarPages = ['wine_cellar.php','tasting_notes.php','varietals.php','comparison.php'];
$teamPages   = ['sommeliers.php','certifications.php'];
$supplyPages = ['vineyards.php','suppliers.php','cellar_comparison.php'];
$adminPages  = ['accounts.php','login_audit.php'];

$cellarOpen = in_array($current, $cellarPages);
$teamOpen   = in_array($current, $teamPages);
$supplyOpen = in_array($current, $supplyPages);
$adminOpen  = in_array($current, $adminPages);
?>
<aside class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <p class="logo">CWCSM</p>
    <p class="tagline">Wine Cellar &amp; Sommelier Mgmt</p>
  </div>

  <div class="sidebar-nav-content">
    <a class="nav-link <?= nav_active('dashboard.php', $current) ?>" href="<?= APP_URL ?>dashboard.php"><span class="icon"><?= icon('dashboard') ?></span><span class="nav-text">Dashboard</span></a>

    <div class="nav-folder <?= $cellarOpen ? 'open' : '' ?>">
      <button class="nav-folder-btn" type="button"><span class="icon"><?= icon('wine') ?></span><span class="nav-text">Cellar</span><span class="nav-arrow">›</span></button>
      <div class="nav-folder-items">
        <a class="nav-link sub <?= nav_active('wine_cellar.php', $current) ?>" href="<?= APP_URL ?>wine_cellar.php"><span class="nav-text">Wine Cellar</span></a>
        <a class="nav-link sub <?= nav_active('tasting_notes.php', $current) ?>" href="<?= APP_URL ?>tasting_notes.php"><span class="nav-text">Tasting Notes</span></a>
        <a class="nav-link sub <?= nav_active('varietals.php', $current) ?>" href="<?= APP_URL ?>varietals.php"><span class="nav-text">Wine Varietals</span></a>
        <?php if ($role === 'sommelier' || $role === 'admin'): ?>
          <a class="nav-link sub <?= nav_active('comparison.php', $current) ?>" href="<?= APP_URL ?>comparison.php"><span class="nav-text">Wine Comparison</span></a>
        <?php endif; ?>
      </div>
    </div>

    <div class="nav-folder <?= $teamOpen ? 'open' : '' ?>">
      <button class="nav-folder-btn" type="button"><span class="icon"><?= icon('people') ?></span><span class="nav-text">Team</span><span class="nav-arrow">›</span></button>
      <div class="nav-folder-items">
        <a class="nav-link sub <?= nav_active('sommeliers.php', $current) ?>" href="<?= APP_URL ?>sommeliers.php"><span class="nav-text">Sommeliers</span></a>
        <a class="nav-link sub <?= nav_active('certifications.php', $current) ?>" href="<?= APP_URL ?>certifications.php"><span class="nav-text">Certifications</span></a>
      </div>
    </div>

    <div class="nav-folder <?= $supplyOpen ? 'open' : '' ?>">
      <button class="nav-folder-btn" type="button"><span class="icon"><?= icon('truck') ?></span><span class="nav-text">Supply Chain</span><span class="nav-arrow">›</span></button>
      <div class="nav-folder-items">
        <a class="nav-link sub <?= nav_active('vineyards.php', $current) ?>" href="<?= APP_URL ?>vineyards.php"><span class="nav-text">Vineyards</span></a>
        <a class="nav-link sub <?= nav_active('suppliers.php', $current) ?>" href="<?= APP_URL ?>suppliers.php"><span class="nav-text">Suppliers</span></a>
        <?php if ($role === 'cellar_manager' || $role === 'admin'): ?>
          <a class="nav-link sub <?= nav_active('cellar_comparison.php', $current) ?>" href="<?= APP_URL ?>cellar_comparison.php"><span class="nav-text">Insights</span></a>
        <?php endif; ?>
      </div>
    </div>

    <?php if ($role === 'admin'): ?>
    <div class="nav-folder <?= $adminOpen ? 'open' : '' ?>">
      <button class="nav-folder-btn" type="button"><span class="icon"><?= icon('lock') ?></span><span class="nav-text">Admin</span><span class="nav-arrow">›</span></button>
      <div class="nav-folder-items">
        <a class="nav-link sub <?= nav_active('accounts.php', $current) ?>" href="<?= APP_URL ?>accounts.php"><span class="nav-text">Accounts</span></a>
        <a class="nav-link sub <?= nav_active('login_audit.php', $current) ?>" href="<?= APP_URL ?>login_audit.php"><span class="nav-text">Login Audit</span></a>
      </div>
    </div>
    <?php endif; ?>
  </div>

  <div class="sidebar-footer">
    <a class="nav-link <?= nav_active('profile.php', $current) ?>" href="<?= APP_URL ?>profile.php"><span class="icon"><?= icon('gear') ?></span><span class="nav-text">My Profile</span></a>
    <a class="nav-link" href="<?= APP_URL ?>logout.php"><span class="icon"><?= icon('logout') ?></span><span class="nav-text">Logout</span></a>
  </div>
</aside>
