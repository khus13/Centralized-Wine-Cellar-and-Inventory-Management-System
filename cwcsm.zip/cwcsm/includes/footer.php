  </div>
  <footer class="app-footer">CWCSM &middot; Centralized Wine Cellar and Sommelier Management &middot; &copy; <?= date('Y') ?></footer>
</div>
</div>
<script src="<?= asset_url('assets/js/main.js') ?>"></script>
<?php if (!empty($extraScripts)) foreach ($extraScripts as $s): ?>
<script src="<?= preg_match('#^https?://#i', $s) ? sanitize($s) : asset_url($s) ?>"></script>
<?php endforeach; ?>
</body>
</html>
