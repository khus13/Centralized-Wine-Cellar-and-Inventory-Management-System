<?php
/**
 * CWCSM - Bootstrap
 * Included at the top of every entry-point script.
 */

if (session_status() === PHP_SESSION_NONE) {
    // Harden session cookie params before starting the session
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

/**
 * APP_URL - the URL path this app is running under, detected automatically
 * from where this project actually sits inside the web server's document
 * root. Works whether the project lives at htdocs/cwcsm/, htdocs/foo/bar/,
 * or anywhere else — no manual configuration needed, and it's correct from
 * both root-level pages and scripts under /api/. Always ends with a
 * trailing slash. Use it for every asset/script/upload link so pages never
 * render unstyled.
 */
$projectRoot = str_replace('\\', '/', dirname(__DIR__)); // filesystem path to the project root (parent of includes/)
$docRoot = rtrim(str_replace('\\', '/', $_SERVER['DOCUMENT_ROOT'] ?? ''), '/');
if ($docRoot !== '' && str_starts_with($projectRoot, $docRoot)) {
    $appUrlPath = substr($projectRoot, strlen($docRoot));
} else {
    // Fallback if DOCUMENT_ROOT isn't available: derive from the current script's URL.
    $appUrlPath = dirname($_SERVER['SCRIPT_NAME']);
    if (str_ends_with(rtrim($appUrlPath, '/'), '/api')) {
        $appUrlPath = dirname($appUrlPath); // step out of /api back to project root
    }
}
define('APP_URL', rtrim($appUrlPath, '/') . '/');
unset($projectRoot, $docRoot, $appUrlPath);

// Session timeout (30 minutes of inactivity)
define('SECURITY_QUESTIONS', [
    'What was the name of your first pet?',
    'What is your mother\'s maiden name?',
    'What city were you born in?',
    'What was the name of your first school?',
    'What is your favorite wine varietal?',
]);

define('SESSION_TIMEOUT_SECONDS', 1800);

/**
 * Appends ?v=<file modified time> to a static asset URL, so browsers are
 * forced to refetch it the moment the file on disk actually changes,
 * instead of serving a stale cached copy of an old main.js/style.css.
 */
function asset_url(string $relativePath): string
{
    $fsPath = __DIR__ . '/../' . $relativePath;
    $v = is_file($fsPath) ? filemtime($fsPath) : time();
    return APP_URL . $relativePath . '?v=' . $v;
}
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > SESSION_TIMEOUT_SECONDS) {
    $_SESSION = [];
    session_destroy();
    session_start();
    $_SESSION['flash'][] = ['type' => 'error', 'message' => 'Your session expired. Please sign in again.'];
}
$_SESSION['last_activity'] = time();

/**
 * Classic PHP gotcha: if an uploaded file makes the request bigger than
 * post_max_size, PHP silently empties $_POST and $_FILES entirely instead
 * of raising a normal error. Without this check, a page just looks like
 * "nothing happened" when someone attaches a large photo. Catch it here,
 * for every POST, before any page-specific logic runs.
 */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && empty($_POST) && empty($_FILES)) {
    $contentLength = (int) ($_SERVER['CONTENT_LENGTH'] ?? 0);
    if ($contentLength > 0) {
        $_SESSION['flash'][] = [
            'type' => 'error',
            'message' => 'That upload was too large for this server to accept (PHP\'s post_max_size / upload_max_filesize limit). Try a smaller image, or ask your administrator to raise those limits in php.ini.',
        ];
        header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? 'dashboard.php'));
        exit;
    }
}

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/icons.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/middleware.php';

require_once __DIR__ . '/../models/Account.php';
require_once __DIR__ . '/../models/Sommelier.php';
require_once __DIR__ . '/../models/CellarManager.php';
require_once __DIR__ . '/../models/Region.php';
require_once __DIR__ . '/../models/Vineyard.php';
require_once __DIR__ . '/../models/Varietal.php';
require_once __DIR__ . '/../models/Supplier.php';
require_once __DIR__ . '/../models/Inventory.php';
require_once __DIR__ . '/../models/TastingNote.php';
require_once __DIR__ . '/../models/Certification.php';
require_once __DIR__ . '/../models/LoginAudit.php';
require_once __DIR__ . '/../models/WineRating.php';
require_once __DIR__ . '/../models/SupplierRating.php';

/**
 * Global safety net: never leak stack traces / file paths to the browser.
 * Set APP_DEBUG=1 at the top of this file temporarily if you need to see
 * real errors while developing.
 */
define('APP_DEBUG', false);

set_exception_handler(function (Throwable $e) {
    error_log('[CWCSM] Uncaught ' . get_class($e) . ': ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());
    http_response_code(500);
    if (APP_DEBUG) {
        echo '<pre>' . htmlspecialchars((string) $e) . '</pre>';
    } else {
        echo '<!DOCTYPE html><html><head><title>Something went wrong — CWCSM</title>'
           . '<link rel="stylesheet" href="' . APP_URL . 'assets/css/style.css"></head>'
           . '<body style="display:flex;align-items:center;justify-content:center;min-height:100vh;background:#f6f1e9;">'
           . '<div class="card" style="max-width:440px;text-align:center;"><h2>Something went wrong</h2>'
           . '<p style="color:#5c4d4f;">Please check that the record you referenced still exists, then try again. If this keeps happening, contact your administrator.</p>'
           . '<a class="btn btn-primary" href="javascript:history.back()" style="margin-top:12px;">Go Back</a></div></body></html>';
    }
    exit;
});
