<?php
/**
 * CWCSM - Middleware / route guards
 */

function require_login(): void
{
    if (!is_logged_in()) {
        redirect('login.php');
    }
}

/**
 * @param string|string[] $roles one role or an array of allowed roles
 */
function require_role($roles): void
{
    require_login();
    $roles = (array) $roles;
    if (!in_array($_SESSION['role'], $roles, true)) {
        http_response_code(403);
        require __DIR__ . '/../views/errors/403.php';
        exit;
    }
}

function is_admin(): bool
{
    return is_logged_in() && $_SESSION['role'] === 'admin';
}

function is_sommelier(): bool
{
    return is_logged_in() && $_SESSION['role'] === 'sommelier';
}

function is_cellar_manager(): bool
{
    return is_logged_in() && $_SESSION['role'] === 'cellar_manager';
}

/** Admin or Cellar Manager — the two roles allowed to write to inventory */
function can_manage_inventory(): bool
{
    return is_admin() || is_cellar_manager();
}
