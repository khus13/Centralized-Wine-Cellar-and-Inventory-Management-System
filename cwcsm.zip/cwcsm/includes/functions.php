<?php
/**
 * CWCSM - Shared helper functions
 */

function sanitize(string $value): string
{
    return htmlspecialchars(trim($value), ENT_QUOTES, 'UTF-8');
}

function redirect(string $path): void
{
    // Absolute URLs (http://, https://) or already-rooted paths pass through unchanged.
    if (!preg_match('#^https?://#i', $path) && !str_starts_with($path, '/')) {
        $path = (defined('APP_URL') ? APP_URL : '') . $path;
    }
    header('Location: ' . $path);
    exit;
}

/* ---------------------------------------------------------
 * CSRF protection
 * --------------------------------------------------------- */
function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . csrf_token() . '">';
}

function csrf_verify(): void
{
    $token = $_POST['csrf_token'] ?? '';
    if (empty($token) || empty($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $token)) {
        http_response_code(403);
        die('Invalid or expired form submission (CSRF check failed). Please go back and try again.');
    }
}

/* ---------------------------------------------------------
 * Flash messages
 * --------------------------------------------------------- */
function flash(string $type, string $message): void
{
    $_SESSION['flash'][] = ['type' => $type, 'message' => $message];
}

function get_flashes(): array
{
    $flashes = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $flashes;
}

/* ---------------------------------------------------------
 * File uploads
 * Returns the relative path (e.g. uploads/wines/xxx.jpg) on success,
 * or null on failure. $errors is populated by reference on failure.
 * --------------------------------------------------------- */
function handle_upload(string $inputName, string $subfolder, array $allowedExt, int $maxBytes, ?string &$error = null): ?string
{
    if (!isset($_FILES[$inputName]) || $_FILES[$inputName]['error'] === UPLOAD_ERR_NO_FILE) {
        return null; // no file supplied — not necessarily an error
    }

    $file = $_FILES[$inputName];

    if ($file['error'] !== UPLOAD_ERR_OK) {
        $error = 'Upload failed (error code ' . $file['error'] . ').';
        return null;
    }

    if ($file['size'] > $maxBytes) {
        $error = 'File is too large. Max size is ' . round($maxBytes / 1048576, 1) . 'MB.';
        return null;
    }

    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowedExt, true)) {
        $error = 'Invalid file type. Allowed: ' . implode(', ', $allowedExt);
        return null;
    }

    // Basic MIME sniffing for images (skip for pdf)
    if (in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp'], true)) {
        $imgInfo = @getimagesize($file['tmp_name']);
        if ($imgInfo === false) {
            $error = 'File does not appear to be a valid image.';
            return null;
        }
    }

    $baseDir = __DIR__ . '/../uploads/' . trim($subfolder, '/');
    if (!is_dir($baseDir)) {
        mkdir($baseDir, 0755, true);
    }

    $secureName = bin2hex(random_bytes(16)) . '.' . $ext;
    $destination = $baseDir . '/' . $secureName;

    if (!move_uploaded_file($file['tmp_name'], $destination)) {
        $error = 'Could not save uploaded file.';
        return null;
    }

    return 'uploads/' . trim($subfolder, '/') . '/' . $secureName;
}

function delete_upload(?string $relativePath): void
{
    if (!$relativePath) {
        return;
    }
    $full = __DIR__ . '/../' . ltrim($relativePath, '/');
    if (is_file($full)) {
        @unlink($full);
    }
}

/* ---------------------------------------------------------
 * Formatting helpers
 * --------------------------------------------------------- */
function money(float $amount): string
{
    return '$' . number_format($amount, 2);
}

function upload_url(string $relativePath): string
{
    return (defined('APP_URL') ? APP_URL : '') . ltrim($relativePath, '/');
}

/**
 * Turns a PDOException into a short, safe-to-display message instead of a
 * blank crash page. Keeps enough detail to actually debug (constraint name,
 * duplicate key, etc.) without dumping the full query or file paths.
 */
function friendly_db_error(PDOException $e): string
{
    $msg = $e->getMessage();
    if (str_contains($msg, 'Duplicate entry')) {
        return 'That value is already in use — please use a different one.';
    }
    if (str_contains($msg, 'foreign key constraint fails') || str_contains($msg, 'a foreign key constraint fails')) {
        return 'That record is still linked to other data, so this action can\'t be completed.';
    }
    // Fall back to a trimmed version of the actual driver message — enough to diagnose, not a full trace.
    $short = preg_replace('/^SQLSTATE\[[^\]]+\]\s*(\[\d+\])?\s*/', '', $msg);
    return 'Could not save this record (' . mb_strimwidth($short, 0, 160, '…') . ').';
}

function format_date(?string $date): string
{
    if (!$date) {
        return '—';
    }
    return date('M j, Y', strtotime($date));
}

function star_rating(int $rating, int $max = 5): string
{
    $rating = max(0, min($max, $rating));
    return str_repeat('&#9733;', $rating) . str_repeat('&#9734;', $max - $rating);
}

/**
 * Small red asterisk marking a required form field. Use inside a <label>:
 *   <label>Vineyard <?= req() ?></label>
 */
function req(): string
{
    return '<span class="req" title="Required" aria-hidden="true">*</span>';
}

/* ---------------------------------------------------------
 * Pagination
 * paginate() slices a full result array to the current page and
 * returns [$pageItems, $meta]. render_pagination() prints the control.
 * --------------------------------------------------------- */
function current_page(string $param = 'page'): int
{
    $p = (int) ($_GET[$param] ?? 1);
    return $p < 1 ? 1 : $p;
}

/**
 * @return array{0: array, 1: array} [$items, $meta]
 * $meta = ['page','per_page','total','total_pages','from','to']
 */
function paginate(array $items, int $perPage = 12, string $param = 'page'): array
{
    $total = count($items);
    $totalPages = max(1, (int) ceil($total / $perPage));
    $page = min(current_page($param), $totalPages);
    $offset = ($page - 1) * $perPage;
    $slice = array_slice($items, $offset, $perPage);
    $meta = [
        'page'        => $page,
        'per_page'    => $perPage,
        'total'       => $total,
        'total_pages' => $totalPages,
        'from'        => $total ? $offset + 1 : 0,
        'to'          => min($offset + $perPage, $total),
        'param'       => $param,
    ];
    return [$slice, $meta];
}

/**
 * Given the full ordered list, find which 1-based page a specific record
 * id lands on. Lets a page jump straight to a searched-for item even when
 * it sits on a later pagination page. Returns null if not found.
 */
function page_of_item(array $items, string $idKey, $id, int $perPage): ?int
{
    $id = (string) $id;
    foreach (array_values($items) as $i => $row) {
        if ((string) ($row[$idKey] ?? '') === $id) {
            return (int) floor($i / $perPage) + 1;
        }
    }
    return null;
}

/**
 * Renders a pagination bar. Preserves existing query-string params
 * (e.g. ?archived=1) while swapping the page number.
 */
function render_pagination(array $meta): string
{
    if ($meta['total_pages'] <= 1) {
        return '';
    }
    $param = $meta['param'] ?? 'page';
    $query = $_GET;

    $link = function (int $p) use ($query, $param) {
        $query[$param] = $p;
        return '?' . http_build_query($query);
    };

    $page = $meta['page'];
    $totalPages = $meta['total_pages'];

    $html = '<nav class="pagination" aria-label="Pagination">';
    $html .= '<span class="pagination-info">Showing ' . $meta['from'] . '–' . $meta['to'] . ' of ' . $meta['total'] . '</span>';
    $html .= '<span class="pagination-pages">';

    // Prev
    if ($page > 1) {
        $html .= '<a class="page-btn" href="' . htmlspecialchars($link($page - 1)) . '" aria-label="Previous">&lsaquo;</a>';
    } else {
        $html .= '<span class="page-btn disabled">&lsaquo;</span>';
    }

    // Windowed page numbers
    $start = max(1, $page - 2);
    $end = min($totalPages, $page + 2);
    if ($start > 1) {
        $html .= '<a class="page-btn" href="' . htmlspecialchars($link(1)) . '">1</a>';
        if ($start > 2) {
            $html .= '<span class="page-ellipsis">…</span>';
        }
    }
    for ($i = $start; $i <= $end; $i++) {
        if ($i === $page) {
            $html .= '<span class="page-btn active">' . $i . '</span>';
        } else {
            $html .= '<a class="page-btn" href="' . htmlspecialchars($link($i)) . '">' . $i . '</a>';
        }
    }
    if ($end < $totalPages) {
        if ($end < $totalPages - 1) {
            $html .= '<span class="page-ellipsis">…</span>';
        }
        $html .= '<a class="page-btn" href="' . htmlspecialchars($link($totalPages)) . '">' . $totalPages . '</a>';
    }

    // Next
    if ($page < $totalPages) {
        $html .= '<a class="page-btn" href="' . htmlspecialchars($link($page + 1)) . '" aria-label="Next">&rsaquo;</a>';
    } else {
        $html .= '<span class="page-btn disabled">&rsaquo;</span>';
    }

    $html .= '</span></nav>';
    return $html;
}

/**
 * Renders 5 filled/empty stars for an average (float) rating, plus the
 * numeric value. Used for wine/supplier rating summaries.
 */
function avg_stars(float $avg, int $count = -1): string
{
    $rounded = (int) round($avg);
    $stars = '<span class="stars">' . str_repeat('&#9733;', $rounded) . str_repeat('&#9734;', 5 - $rounded) . '</span>';
    $label = $avg > 0 ? number_format($avg, 1) : '—';
    $out = $stars . ' <span class="rating-num">' . $label . '</span>';
    if ($count >= 0) {
        $out .= ' <span class="rating-count">(' . $count . ')</span>';
    }
    return $out;
}
