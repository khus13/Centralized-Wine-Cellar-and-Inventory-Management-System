<?php
/**
 * Expects: $pageTitle (string), optionally $pageSubtitle
 */
$user = current_user();
$account = Account::findById($user['account_id']);

// Notifications: certifications expiring in the next 30 days.
// Admin sees everyone's; Sommelier sees only their own.
$notifExpiring = Certification::expiringSoon(30);
if ($user['role'] === 'sommelier') {
    $ownCerts = SommelierCertification::forSommelier((int) $user['profile_id']);
    $ownCertNames = array_column($ownCerts, 'certification_name');
    $notifExpiring = array_values(array_filter($notifExpiring, function ($n) use ($user) {
        return $n['first_name'] === $user['first_name'] && $n['last_name'] === $user['last_name'];
    }));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= sanitize($pageTitle ?? 'CWCSM') ?> — CWCSM</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= asset_url('assets/css/style.css') ?>">
</head>
<body>
<div class="app-shell">
<?php include __DIR__ . '/sidebar.php'; ?>
<div class="main">
  <div class="topbar">
    <button class="icon-btn" id="sidebarToggle" style="display:none;" aria-label="Toggle menu">&#9776;</button>
    <div class="search-box">
      <input type="text" id="globalSearch" placeholder="Search wines, vineyards, sommeliers..." autocomplete="off">
      <span class="search-icon"><?= icon('search') ?></span>
      <div class="search-results" id="searchResults"></div>
    </div>
    <div class="topbar-actions">
      <span class="role-badge role-<?= sanitize($user['role']) ?>"><?= sanitize(str_replace('_', ' ', $user['role'])) ?></span>

      <div class="notif-wrap">
        <button class="icon-btn" id="notifBell" title="Notifications" aria-label="Notifications">
          <?= icon('bell') ?>
          <?php if ($notifExpiring): ?><span class="notif-dot"></span><?php endif; ?>
        </button>
        <div class="notif-panel" id="notifPanel">
          <div class="notif-header">Certifications expiring soon</div>
          <?php if (!$notifExpiring): ?>
            <div class="notif-empty">Nothing expiring in the next 30 days.</div>
          <?php else: foreach (array_slice($notifExpiring, 0, 6) as $n): ?>
            <div class="notif-item">
              <div class="title"><?= sanitize($n['certification_name']) ?></div>
              <div class="meta"><?= sanitize($n['first_name'] . ' ' . $n['last_name']) ?> &middot; expires <?= format_date($n['expiration_date']) ?></div>
            </div>
          <?php endforeach; endif; ?>
        </div>
      </div>

      <a class="user-chip" href="profile.php">
        <span class="avatar">
          <?php if (!empty($account['photo_path'])): ?>
            <img src="<?= sanitize(upload_url($account['photo_path'])) ?>" alt="">
          <?php else: ?>
            <?= strtoupper(substr($user['first_name'], 0, 1) . substr($user['last_name'], 0, 1)) ?>
          <?php endif; ?>
        </span>
        <span><?= sanitize($user['first_name']) ?></span>
      </a>
    </div>
  </div>
  <div class="content">
    <?php $flashes = get_flashes(); if ($flashes): ?>
      <div class="flash-stack">
        <?php foreach ($flashes as $f): ?>
          <div class="flash flash-<?= sanitize($f['type']) ?>"><?= sanitize($f['message']) ?><button type="button" class="flash-close" data-dismiss-flash aria-label="Dismiss">&times;</button></div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
