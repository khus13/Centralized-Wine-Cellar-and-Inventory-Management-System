<?php
/**
 * CWCSM - Icon helper
 * Small set of hand-picked line icons (24x24, currentColor stroke) used in
 * place of emoji glyphs throughout the UI. Usage: <?= icon('wine') ?>
 */

function icon(string $name, string $extraClass = ''): string
{
    $paths = [
        'dashboard'    => '<rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/>',
        'wine'         => '<path d="M8 2h8l-1 7a3 3 0 0 1-3 2.7V17h2.5v2H7.5v-2H10v-5.3A3 3 0 0 1 7 9L8 2z"/><path d="M8.3 5h7.4"/>',
        'notes'        => '<path d="M6 2h9l4 4v14a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V3a1 1 0 0 1 1-1z"/><path d="M15 2v4h4M8 12h7M8 16h7M8 8h3"/>',
        'people'       => '<circle cx="9" cy="8" r="3.2"/><path d="M3 20c0-3.3 2.7-6 6-6s6 2.7 6 6"/><circle cx="17" cy="9" r="2.6"/><path d="M15.5 14.2c2.5.4 4.5 2.6 4.5 5.3"/>',
        'certificate'  => '<circle cx="12" cy="9" r="6"/><path d="M9 14.5 7.5 22 12 19l4.5 3-1.5-7.5"/>',
        'grape'        => '<circle cx="7" cy="14" r="2.4"/><circle cx="12" cy="14" r="2.4"/><circle cx="9.5" cy="9.5" r="2.4"/><circle cx="14.5" cy="9.5" r="2.4"/><circle cx="12" cy="18.5" r="2.4"/><path d="M12 3.5c-.9 1-1.4 2.2-1.4 3.5"/>',
        'vineyard'     => '<path d="M4 21V9M4 9 1.5 6.5M4 9 6.5 6.5M4 4v2"/><path d="M12 21V9M12 9 9.5 6.5M12 9 14.5 6.5M12 4v2"/><path d="M20 21V9M20 9 17.5 6.5M20 9 22.5 6.5M20 4v2"/><path d="M2 21h20"/>',
        'truck'        => '<rect x="1" y="7" width="13" height="9" rx="1"/><path d="M14 10h4l3 3v3h-7z"/><circle cx="6" cy="18" r="1.8"/><circle cx="17.5" cy="18" r="1.8"/>',
        'lock'         => '<rect x="4" y="10" width="16" height="10" rx="1.5"/><path d="M7 10V7a5 5 0 0 1 10 0v3"/>',
        'gear'         => '<circle cx="12" cy="12" r="3"/><path d="M19.4 13.5a7.6 7.6 0 0 0 0-3l2-1.4-2-3.4-2.3.8a7.6 7.6 0 0 0-2.6-1.5L14 2h-4l-.5 2.5a7.6 7.6 0 0 0-2.6 1.5l-2.3-.8-2 3.4 2 1.4a7.6 7.6 0 0 0 0 3l-2 1.4 2 3.4 2.3-.8a7.6 7.6 0 0 0 2.6 1.5L10 22h4l.5-2.5a7.6 7.6 0 0 0 2.6-1.5l2.3.8 2-3.4-2-1.4z"/>',
        'logout'       => '<path d="M9 21H5a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h4"/><path d="M16 17l5-5-5-5M21 12H9"/>',
        'bell'         => '<path d="M6 9a6 6 0 1 1 12 0c0 4.5 1.5 6 1.5 6h-15S6 13.5 6 9z"/><path d="M10 19a2 2 0 0 0 4 0"/>',
        'search'       => '<circle cx="10.5" cy="10.5" r="6.5"/><path d="M20 20l-4.8-4.8"/>',
        'plus'         => '<path d="M12 5v14M5 12h14"/>',
        'edit'         => '<path d="M12.5 5.5 18 11 8 21H2v-6z"/><path d="M16 3.5 20 7.5"/>',
        'trash'        => '<path d="M4 7h16"/><path d="M9 7V4.5A1.5 1.5 0 0 1 10.5 3h3A1.5 1.5 0 0 1 15 4.5V7"/><path d="M6 7l1 13.5A1.5 1.5 0 0 0 8.5 22h7a1.5 1.5 0 0 0 1.5-1.5L18 7"/>',
        'archive'      => '<rect x="2.5" y="3" width="19" height="5" rx="1"/><path d="M4.5 8v10.5A1.5 1.5 0 0 0 6 20h12a1.5 1.5 0 0 0 1.5-1.5V8"/><path d="M10 12.5h4"/>',
        'restore'      => '<path d="M3 12a9 9 0 1 0 3-6.7"/><path d="M3 4v5h5"/>',
        'camera'       => '<path d="M4 7h3l1.5-2h7L17 7h3a1 1 0 0 1 1 1v11a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1z"/><circle cx="12" cy="13.5" r="3.8"/>',
        'grid'         => '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
        'list'         => '<path d="M8 6h13M8 12h13M8 18h13"/><circle cx="3.5" cy="6" r="1.3" fill="currentColor" stroke="none"/><circle cx="3.5" cy="12" r="1.3" fill="currentColor" stroke="none"/><circle cx="3.5" cy="18" r="1.3" fill="currentColor" stroke="none"/>',
        'chevron-down' => '<path d="M6 9l6 6 6-6"/>',
        'close'        => '<path d="M5 5l14 14M19 5 5 19"/>',
        'user'         => '<circle cx="12" cy="8" r="4"/><path d="M4 20c0-4.4 3.6-8 8-8s8 3.6 8 8"/>',
    ];

    if (!isset($paths[$name])) {
        return '';
    }

    return '<svg class="icon-svg ' . sanitize($extraClass) . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $paths[$name] . '</svg>';
}
