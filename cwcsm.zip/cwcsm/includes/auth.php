<?php
/**
 * CWCSM - Authentication
 */

/**
 * Attempts to log a user in.
 * Returns [true, null] on success, or [false, 'error message'] on failure.
 * On success, populates $_SESSION and writes a login_log row.
 */
function attempt_login(string $username, string $password): array
{
    $account = Account::findByUsername($username);

    if (!$account || !password_verify($password, $account['password'])) {
        // Log failed attempt only if the account exists, so we can audit it
        if ($account) {
            LoginAudit::recordLogin((int) $account['account_id'], 'failed');
        }
        return [false, 'Incorrect username or password.'];
    }

    if (!$account['is_active']) {
        LoginAudit::recordLogin((int) $account['account_id'], 'blocked');
        return [false, 'This account has been deactivated. Please contact an administrator.'];
    }

    $role = Account::getRole((int) $account['account_id']);
    if (!$role) {
        return [false, 'This account is not fully configured. Please contact an administrator.'];
    }

    session_regenerate_id(true);

    $_SESSION['account_id']  = (int) $account['account_id'];
    $_SESSION['username']    = $account['username'];
    $_SESSION['first_name']  = $account['first_name'];
    $_SESSION['last_name']   = $account['last_name'];
    $_SESSION['role']        = $role;

    if ($role === 'sommelier') {
        $prof = Sommelier::findByAccountId((int) $account['account_id']);
        $_SESSION['profile_id'] = (int) $prof['sommelier_id'];
    } elseif ($role === 'cellar_manager') {
        $prof = CellarManager::findByAccountId((int) $account['account_id']);
        $_SESSION['profile_id'] = (int) $prof['manager_id'];
    } else {
        $_SESSION['profile_id'] = null;
    }

    $_SESSION['login_id'] = LoginAudit::recordLogin((int) $account['account_id'], 'success');

    return [true, null];
}

function do_logout(): void
{
    if (!empty($_SESSION['login_id'])) {
        LoginAudit::recordLogout((int) $_SESSION['login_id']);
    }
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    }
    session_destroy();
}

/**
 * Registers a new Sommelier or Cellar Manager account.
 * Returns [true, null] on success or [false, 'error message'] on failure.
 */
function register_account(string $first, string $last, string $username, string $email, string $password, string $role = 'sommelier', string $securityQuestion = '', string $securityAnswer = ''): array
{
    // Everyone who signs up starts as a Sommelier. Elevated roles
    // (Cellar Manager, System Admin) are only granted by an administrator
    // from the Accounts page — users can't pick their own role.
    $role = 'sommelier';
    if (strlen($password) < 8) {
        return [false, 'Password must be at least 8 characters.'];
    }
    if ($securityQuestion === '' || trim($securityAnswer) === '') {
        return [false, 'Please choose a security question and provide an answer.'];
    }
    if (Account::findByUsername($username)) {
        return [false, 'That username is already taken.'];
    }
    if (Account::findByEmail($email)) {
        return [false, 'That email is already registered.'];
    }

    $db = getDB();
    try {
        $db->beginTransaction();

        $hash = password_hash($password, PASSWORD_DEFAULT);
        $answerHash = password_hash(strtolower(trim($securityAnswer)), PASSWORD_DEFAULT);
        $accountId = Account::create($first, $last, $username, $hash, $email, '', $securityQuestion, $answerHash);

        if ($role === 'sommelier') {
            Sommelier::create($accountId, date('Y-m-d'));
        } else {
            CellarManager::create($accountId, date('Y-m-d'));
        }

        $db->commit();
        return [true, null];
    } catch (Throwable $e) {
        $db->rollBack();
        return [false, 'Registration failed. Please try again.'];
    }
}

function current_user(): ?array
{
    if (empty($_SESSION['account_id'])) {
        return null;
    }
    return [
        'account_id' => $_SESSION['account_id'],
        'username'   => $_SESSION['username'],
        'first_name' => $_SESSION['first_name'],
        'last_name'  => $_SESSION['last_name'],
        'role'       => $_SESSION['role'],
        'profile_id' => $_SESSION['profile_id'] ?? null,
    ];
}

function is_logged_in(): bool
{
    return !empty($_SESSION['account_id']);
}