<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_login();

header('Content-Type: application/json');

$term = trim($_GET['q'] ?? '');
if (strlen($term) < 2) {
    echo json_encode(['wines' => [], 'vineyards' => [], 'suppliers' => [], 'sommeliers' => [], 'varietals' => []]);
    exit;
}

$db = getDB();

$wines = [];
$stmt = $db->prepare(
    "SELECT ci.bottle_id, v.vineyard_name, wv.varietal_name, ci.vintage_year
     FROM cellar_inventory ci
     JOIN vineyards v ON v.vineyard_id = ci.vineyard_id
     JOIN wine_varietals wv ON wv.varietal_id = ci.varietal_id
     WHERE v.vineyard_name LIKE ? OR wv.varietal_name LIKE ? OR ci.storage_bin_number LIKE ?
     LIMIT 6"
);
$like = "%$term%";
$stmt->execute([$like, $like, $like]);
foreach ($stmt->fetchAll() as $row) {
    $wines[] = ['id' => $row['bottle_id'], 'label' => $row['vineyard_name'] . ' ' . $row['varietal_name'] . ' (' . $row['vintage_year'] . ')'];
}

$vineyards = array_map(fn($r) => ['id' => $r['vineyard_id'], 'label' => $r['vineyard_name']], Vineyard::search($term));
$suppliers = array_map(fn($r) => ['id' => $r['supplier_id'], 'label' => $r['supplier_contact_name']], Supplier::search($term));
$sommeliers = array_map(fn($r) => ['id' => $r['sommelier_id'], 'label' => $r['first_name'] . ' ' . $r['last_name']], Sommelier::search($term));
$varietals = array_map(fn($r) => ['id' => $r['varietal_id'], 'label' => $r['varietal_name']], Varietal::search($term));

echo json_encode([
    'wines'      => $wines,
    'vineyards'  => $vineyards,
    'suppliers'  => $suppliers,
    'sommeliers' => $sommeliers,
    'varietals'  => $varietals,
]);
