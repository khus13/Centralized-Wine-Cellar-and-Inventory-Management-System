<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_login();

header('Content-Type: application/json');

// 1. Inventory value by vineyard (bar chart)
$byVineyard = Inventory::valueByVineyard();
$vineyardLabels = array_column($byVineyard, 'vineyard_name');
$vineyardValues = array_map('floatval', array_column($byVineyard, 'total_value'));

// 2. Wine distribution by varietal (pie chart)
$byVarietal = Varietal::distributionCounts();
$varietalLabels = array_column($byVarietal, 'varietal_name');
$varietalValues = array_map('intval', array_column($byVarietal, 'bottle_count'));

// 3. Certifications expiring soon (line chart) — bucket by month for the next 6 months
$expiring = Certification::expiringSoon(180);
$buckets = [];
for ($i = 0; $i < 6; $i++) {
    $key = date('Y-m', strtotime("+$i month"));
    $buckets[$key] = 0;
}
foreach ($expiring as $row) {
    $key = date('Y-m', strtotime($row['expiration_date']));
    if (isset($buckets[$key])) {
        $buckets[$key]++;
    }
}
$expiringLabels = array_map(fn($k) => date('M Y', strtotime($k . '-01')), array_keys($buckets));
$expiringValues = array_values($buckets);

// 4. Monthly tasting notes created (area chart) — last 6 months, zero-filled
$monthly = TastingNote::monthlyCounts(6);
$monthlyMap = [];
foreach ($monthly as $row) {
    $monthlyMap[$row['ym']] = (int) $row['note_count'];
}
$monthlyLabels = [];
$monthlyValues = [];
for ($i = 5; $i >= 0; $i--) {
    $key = date('Y-m', strtotime("-$i month"));
    $monthlyLabels[] = date('M Y', strtotime($key . '-01'));
    $monthlyValues[] = $monthlyMap[$key] ?? 0;
}

echo json_encode([
    'inventoryByVineyard' => ['labels' => $vineyardLabels, 'values' => $vineyardValues],
    'varietalDistribution' => ['labels' => $varietalLabels, 'values' => $varietalValues],
    'certExpiring' => ['labels' => $expiringLabels, 'values' => $expiringValues],
    'monthlyNotes' => ['labels' => $monthlyLabels, 'values' => $monthlyValues],
]);
