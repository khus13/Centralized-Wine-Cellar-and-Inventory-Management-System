<?php
require_once __DIR__ . '/includes/bootstrap.php';

if (is_logged_in()) {
    redirect('dashboard.php');
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username === '' || $password === '') {
        $errors[] = 'Please enter both your username and password.';
    } else {
        [$ok, $reason] = attempt_login($username, $password);
        if ($ok) {
            redirect('dashboard.php');
        } else {
            $errors[] = $reason;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sign In — CWCSM</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= asset_url('assets/css/style.css') ?>">
</head>
<body class="auth-page">
<div class="auth-shell">
  <div class="auth-panel">
    <div class="auth-panel-inner">
      <p class="logo">CWCSM</p>
      <p class="tagline">Centralized Wine Cellar and Sommelier Management</p>
      <p class="welcome">We are happy to see you again!</p>

      <div class="auth-tabs">
        <a class="active" href="login.php">Sign In</a>
        <a href="register.php">Sign Up</a>
      </div>

      <?php foreach (get_flashes() as $f): ?>
        <div class="flash flash-<?= sanitize($f['type']) ?>" style="margin-bottom:14px;"><?= sanitize($f['message']) ?><button type="button" class="flash-close" data-dismiss-flash aria-label="Dismiss">&times;</button></div>
      <?php endforeach; ?>
      <?php foreach ($errors as $e): ?>
        <div class="flash flash-error" style="margin-bottom:14px;"><?= sanitize($e) ?><button type="button" class="flash-close" data-dismiss-flash aria-label="Dismiss">&times;</button></div>
      <?php endforeach; ?>

      <form method="post" action="login.php">
        <?= csrf_field() ?>
        <div class="field">
          <label for="username">Username</label>
          <input type="text" id="username" name="username" placeholder="Enter Username" required autofocus value="<?= sanitize($_POST['username'] ?? '') ?>">
        </div>
        <div class="field">
          <label for="password">Password</label>
          <input type="password" id="password" name="password" placeholder="Enter Password" required>
        </div>
        <a class="forgot-link" href="forgot_password.php">Forgot Password?</a>
        <button type="submit" class="btn btn-primary auth-submit">Login</button>
      </form>

      <p class="auth-switch">Don't have an account? <a href="register.php">Sign Up</a></p>
    </div>
  </div>
  <div class="auth-visual">
    <span class="brand-mark">CWCSM</span>
    <div>
      <p class="quote">"Every bottle has a story. CWCSM keeps the record straight — from vineyard to glass."</p>
      <p class="meta-line">Wine Cellar &amp; Sommelier Management</p>
    </div>
  </div>
</div>
<script src="<?= asset_url('assets/js/main.js') ?>"></script>
</body>
</html>
