<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_login();
require_once __DIR__ . '/controllers/varietal_controller.php';

$pageTitle = 'Wine Varietals';
$showArchived = isset($_GET['archived']) && is_admin();
$allVarietals = $showArchived ? Varietal::trashed() : Varietal::all();

$highlightId = $_GET['highlight'] ?? null;
if ($highlightId && !isset($_GET['page'])) {
    $targetPage = page_of_item($allVarietals, 'varietal_id', $highlightId, 12);
    if ($targetPage && $targetPage > 1) {
        redirect('varietals.php?highlight=' . urlencode($highlightId) . '&page=' . $targetPage);
    }
}

[$varietals, $pageMeta] = paginate($allVarietals, 12);
$canEdit = is_admin();

include __DIR__ . '/includes/header.php';
?>
<div class="page-header">
  <div><h1>Wine Varietals<?= $showArchived ? ' — Archived' : '' ?></h1><p class="subtitle">Aging profiles, pairing guidance, and service temperature</p></div>
  <div style="display:flex;gap:10px;">
    <?php if ($canEdit): ?><a class="btn btn-outline btn-sm" href="varietals.php<?= $showArchived ? '' : '?archived=1' ?>"><?= icon('archive') ?> <?= $showArchived ? 'Back to Active' : 'View Archived' ?></a><?php endif; ?>
    <?php if ($canEdit && !$showArchived): ?><button class="btn btn-primary" data-open-modal="addVarietalModal"><?= icon('plus') ?> Add Varietal</button><?php endif; ?>
  </div>
</div>

<div class="toolbar">
  <div class="filter-bar"><input type="text" placeholder="Search varietals..." data-filter-input=".filterable-row" style="width:260px;"></div>
  <div class="view-toggle">
    <button type="button" data-view="grid"><?= icon('grid') ?> Grid</button>
    <button type="button" class="active" data-view="table"><?= icon('list') ?> Table</button>
  </div>
</div>

<?php if (!$varietals): ?>
  <div class="empty-state card"><div class="icon"><?= icon('grape') ?></div><p><?= $showArchived ? 'No archived varietals.' : 'No wine varietals yet.' ?></p></div>
<?php else: ?>

<div class="entity-grid" id="gridView" style="display:none;">
  <?php foreach ($varietals as $v): ?>
  <div class="entity-card filterable-row" data-filter-text="<?= sanitize($v['varietal_name']) ?>">
    <div class="thumb">
      <?php if (!empty($v['image_path'])): ?>
        <img src="<?= sanitize(upload_url($v['image_path'])) ?>" alt="" style="width:100%;height:100%;object-fit:cover;">
      <?php else: ?>
        <?= icon('grape') ?>
      <?php endif; ?>
    </div>
    <div class="body">
      <h4><?= sanitize($v['varietal_name']) ?></h4>
      <div class="meta-row"><span><?= sanitize($v['color_type']) ?></span><span><?= number_format((float) $v['entry_temperature_celsius'], 1) ?>&deg;C</span></div>
      <div class="meta-row"><span>Ages <?= (int) $v['min_typical_aging_yrs'] ?>–<?= (int) $v['max_typical_aging_yrs'] ?> yrs</span></div>
      <p style="font-size:12.5px;color:var(--ink-soft);margin-top:8px;"><?= sanitize($v['food_pairing_template']) ?></p>
    </div>
    <?php if ($canEdit && !$showArchived): ?>
    <div class="footer-actions">
      <button class="btn btn-outline btn-sm" data-open-modal="editVarietal<?= $v['varietal_id'] ?>"><?= icon('edit') ?> Edit</button>
      <form method="post" action="varietals.php" data-confirm="Archive this varietal?"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="varietal_id" value="<?= $v['varietal_id'] ?>"><button type="submit" class="btn btn-danger btn-sm"><?= icon('archive') ?> Archive</button></form>
    </div>
    <?php elseif ($canEdit): ?>
    <div class="footer-actions">
      <form method="post" action="varietals.php"><?= csrf_field() ?><input type="hidden" name="action" value="restore"><input type="hidden" name="varietal_id" value="<?= $v['varietal_id'] ?>"><button type="submit" class="btn btn-outline btn-sm"><?= icon('restore') ?> Restore</button></form>
    </div>
    <?php endif; ?>
  </div>
  <?php endforeach; ?>
</div>

<div class="table-wrap" id="tableView">
  <table>
    <thead><tr><th></th><th>Name</th><th>Color</th><th>Aging (yrs)</th><th>Serving Temp</th><th>Food Pairing</th><?php if ($canEdit): ?><th></th><?php endif; ?></tr></thead>
    <tbody>
      <?php foreach ($varietals as $v): ?>
      <tr class="filterable-row" data-filter-text="<?= sanitize($v['varietal_name']) ?>">
        <td>
          <div style="width:32px;height:32px;border-radius:6px;overflow:hidden;background:var(--cream);display:flex;align-items:center;justify-content:center;color:var(--wine-accent);flex-shrink:0;">
            <?php if (!empty($v['image_path'])): ?><img src="<?= sanitize(upload_url($v['image_path'])) ?>" alt="" style="width:100%;height:100%;object-fit:cover;"><?php else: ?><?= icon('grape') ?><?php endif; ?>
          </div>
        </td>
        <td><?= sanitize($v['varietal_name']) ?></td>
        <td><?= sanitize($v['color_type']) ?></td>
        <td><?= (int) $v['min_typical_aging_yrs'] ?>–<?= (int) $v['max_typical_aging_yrs'] ?></td>
        <td><?= number_format((float) $v['entry_temperature_celsius'], 1) ?>&deg;C</td>
        <td style="max-width:280px;"><?= sanitize($v['food_pairing_template']) ?></td>
        <?php if ($canEdit && !$showArchived): ?>
        <td class="table-actions">
          <button class="btn btn-outline btn-sm" data-open-modal="editVarietal<?= $v['varietal_id'] ?>">Edit</button>
          <form method="post" action="varietals.php" data-confirm="Archive this varietal?">
            <?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="varietal_id" value="<?= $v['varietal_id'] ?>">
            <button type="submit" class="btn btn-danger btn-sm">Archive</button>
          </form>
        </td>
        <?php elseif ($canEdit): ?>
        <td class="table-actions">
          <form method="post" action="varietals.php"><?= csrf_field() ?><input type="hidden" name="action" value="restore"><input type="hidden" name="varietal_id" value="<?= $v['varietal_id'] ?>"><button type="submit" class="btn btn-outline btn-sm">Restore</button></form>
        </td>
        <?php endif; ?>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

<?php if ($canEdit && !$showArchived): foreach ($varietals as $v): ?>
<div class="modal-overlay" id="editVarietal<?= $v['varietal_id'] ?>">
  <div class="modal modal-lg">
    <div class="modal-header"><h3>Edit Varietal</h3><button class="modal-close" data-close-modal>&times;</button></div>

    <?php if (!empty($v['image_path'])): ?>
    <div style="padding:16px 22px 0;display:flex;align-items:center;gap:12px;">
      <img src="<?= sanitize(upload_url($v['image_path'])) ?>" style="height:56px;width:56px;object-fit:cover;border-radius:6px;">
      <form method="post" action="varietals.php" data-confirm="Remove this varietal's photo?">
        <?= csrf_field() ?><input type="hidden" name="action" value="remove_image"><input type="hidden" name="varietal_id" value="<?= $v['varietal_id'] ?>">
        <button type="submit" class="btn btn-outline remove-image-btn btn-sm"><?= icon('trash') ?> Remove Image</button>
      </form>
    </div>
    <?php endif; ?>

    <form method="post" action="varietals.php" enctype="multipart/form-data">
      <div class="modal-body">
        <?= csrf_field() ?><input type="hidden" name="action" value="update"><input type="hidden" name="varietal_id" value="<?= $v['varietal_id'] ?>">
        <div class="form-grid">
          <div class="field"><label>Varietal Name <?= req() ?></label><input type="text" name="varietal_name" value="<?= sanitize($v['varietal_name']) ?>" required></div>
          <div class="field"><label>Color Type</label>
            <select name="color_type">
              <?php foreach (['Red', 'White', 'Rosé', 'Sparkling'] as $ct): ?><option value="<?= $ct ?>" <?= $v['color_type'] === $ct ? 'selected' : '' ?>><?= $ct ?></option><?php endforeach; ?>
            </select>
          </div>
          <div class="field"><label>Min Aging (yrs)</label><input type="number" name="min_typical_aging_yrs" value="<?= (int) $v['min_typical_aging_yrs'] ?>" required></div>
          <div class="field"><label>Max Aging (yrs)</label><input type="number" name="max_typical_aging_yrs" value="<?= (int) $v['max_typical_aging_yrs'] ?>" required></div>
          <div class="field"><label>Serving Temp (&deg;C)</label><input type="number" step="0.1" name="entry_temperature_celsius" value="<?= $v['entry_temperature_celsius'] ?>" required></div>
          <div class="field"><label><?= empty($v['image_path']) ? 'Photo' : 'Replace Photo' ?></label><input type="file" name="varietal_image" accept="image/*"></div>
          <div class="field field-span-2"><label>Food Pairing</label><textarea name="food_pairing_template" rows="2" required><?= sanitize($v['food_pairing_template']) ?></textarea></div>
        </div>
      </div>
      <div class="modal-footer"><button type="button" class="btn btn-outline" data-close-modal>Cancel</button><button type="submit" class="btn btn-primary">Save Changes</button></div>
    </form>
  </div>
</div>
<?php endforeach; endif; ?>

<?php foreach ($varietals as $v): ?>
<div class="modal-overlay" id="viewVarietal<?= $v['varietal_id'] ?>">
  <div class="modal">
    <div class="modal-header"><h3><?= sanitize($v['varietal_name']) ?></h3><button class="modal-close" data-close-modal>&times;</button></div>
    <div class="modal-body">
      <?php if (!empty($v['image_path'])): ?><img src="<?= sanitize(upload_url($v['image_path'])) ?>" style="border-radius:8px;margin-bottom:14px;max-height:220px;object-fit:cover;width:100%;"><?php endif; ?>
      <p><strong>Color Type:</strong> <?= sanitize($v['color_type']) ?></p>
      <p><strong>Aging:</strong> <?= (int) $v['min_typical_aging_yrs'] ?>–<?= (int) $v['max_typical_aging_yrs'] ?> years</p>
      <p><strong>Serving Temperature:</strong> <?= number_format((float) $v['entry_temperature_celsius'], 1) ?>&deg;C</p>
      <p><strong>Food Pairing:</strong> <?= sanitize($v['food_pairing_template']) ?></p>
    </div>
  </div>
</div>
<?php endforeach; ?>

<?= render_pagination($pageMeta) ?>

<?php endif; ?>

<?php if ($canEdit && !$showArchived): ?>
<div class="modal-overlay" id="addVarietalModal">
  <div class="modal modal-lg">
    <div class="modal-header"><h3>Add Wine Varietal</h3><button class="modal-close" data-close-modal>&times;</button></div>
    <form method="post" action="varietals.php" enctype="multipart/form-data">
      <div class="modal-body">
        <?= csrf_field() ?><input type="hidden" name="action" value="create">
        <div class="form-grid">
          <div class="field"><label>Varietal Name <?= req() ?></label><input type="text" name="varietal_name" required></div>
          <div class="field"><label>Color Type</label>
            <select name="color_type"><?php foreach (['Red', 'White', 'Rosé', 'Sparkling'] as $ct): ?><option value="<?= $ct ?>"><?= $ct ?></option><?php endforeach; ?></select>
          </div>
          <div class="field"><label>Min Aging (yrs)</label><input type="number" name="min_typical_aging_yrs" required></div>
          <div class="field"><label>Max Aging (yrs)</label><input type="number" name="max_typical_aging_yrs" required></div>
          <div class="field"><label>Serving Temp (&deg;C)</label><input type="number" step="0.1" name="entry_temperature_celsius" required></div>
          <div class="field"><label>Photo (optional)</label><input type="file" name="varietal_image" accept="image/*"></div>
          <div class="field field-span-2"><label>Food Pairing</label><textarea name="food_pairing_template" rows="2" required></textarea></div>
        </div>
      </div>
      <div class="modal-footer"><button type="button" class="btn btn-outline" data-close-modal>Cancel</button><button type="submit" class="btn btn-primary">Add Varietal</button></div>
    </form>
  </div>
</div>
<?php endif; ?>

<?php include __DIR__ . '/includes/footer.php'; ?>
