<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_login();

$user = current_user();
$account = Account::findById($user['account_id']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';

    if ($action === 'update_info') {
        $first = trim($_POST['first_name'] ?? '');
        $last  = trim($_POST['last_name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $phone = trim($_POST['phone_number'] ?? '');

        if ($first === '' || $last === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            flash('error', 'Please provide a valid name and email.');
        } else {
            try {
                Account::updateProfile($user['account_id'], $first, $last, $email, $phone);
                $_SESSION['first_name'] = $first;
                $_SESSION['last_name'] = $last;
                flash('success', 'Profile updated.');
            } catch (PDOException $e) {
                flash('error', friendly_db_error($e));
            }
        }
    } elseif ($action === 'change_password') {
        $current = $_POST['current_password'] ?? '';
        $new     = $_POST['new_password'] ?? '';
        $confirm = $_POST['confirm_password'] ?? '';

        if (!password_verify($current, $account['password'])) {
            flash('error', 'Current password is incorrect.');
        } elseif (strlen($new) < 8) {
            flash('error', 'New password must be at least 8 characters.');
        } elseif ($new !== $confirm) {
            flash('error', 'New password and confirmation do not match.');
        } else {
            Account::updatePassword($user['account_id'], password_hash($new, PASSWORD_DEFAULT));
            flash('success', 'Password changed successfully.');
        }
    } elseif ($action === 'upload_photo') {
        $err = null;
        $path = handle_upload('photo', 'profiles', ['jpg', 'jpeg', 'png', 'webp'], 4 * 1024 * 1024, $err);
        if ($err) {
            flash('error', $err);
        } elseif ($path) {
            delete_upload($account['photo_path'] ?? null);
            Account::updatePhoto($user['account_id'], $path);
            flash('success', 'Profile photo updated.');
        } else {
            flash('error', 'Please choose a photo to upload.');
        }
    } elseif ($action === 'remove_photo') {
        delete_upload($account['photo_path'] ?? null);
        Account::updatePhoto($user['account_id'], null);
        flash('success', 'Profile photo removed.');
    }

    redirect('profile.php');
}

$pageTitle = 'My Profile';
include __DIR__ . '/includes/header.php';
?>
<div class="page-header">
  <div><h1>My Profile</h1><p class="subtitle">Manage your account information</p></div>
</div>

<div class="chart-grid">
  <div class="chart-card">
    <h3>Profile Photo</h3>
    <div class="profile-hero" style="margin-bottom:0;">
      <div class="avatar-lg">
        <?php if (!empty($account['photo_path'])): ?>
          <img src="<?= sanitize(upload_url($account['photo_path'])) ?>" alt="">
        <?php else: ?>
          <?= strtoupper(substr($account['first_name'], 0, 1) . substr($account['last_name'], 0, 1)) ?>
        <?php endif; ?>
      </div>
      <div>
        <form method="post" action="profile.php" enctype="multipart/form-data" style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="upload_photo">
          <input type="file" name="photo" accept="image/*" required style="max-width:220px;">
          <button type="submit" class="btn btn-primary btn-sm"><?= icon('camera') ?> Upload</button>
        </form>
        <?php if (!empty($account['photo_path'])): ?>
          <form method="post" action="profile.php" data-confirm="Remove your profile photo?" style="margin-top:8px;">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="remove_photo">
            <button type="submit" class="btn btn-outline remove-image-btn btn-sm"><?= icon('trash') ?> Remove Photo</button>
          </form>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <div class="chart-card">
    <h3>Account Information</h3>
    <form method="post" action="profile.php">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="update_info">
      <div class="form-grid">
        <div class="field"><label>First Name</label><input type="text" name="first_name" value="<?= sanitize($account['first_name']) ?>" required></div>
        <div class="field"><label>Last Name</label><input type="text" name="last_name" value="<?= sanitize($account['last_name']) ?>" required></div>
        <div class="field field-span-2"><label>Email</label><input type="email" name="email" value="<?= sanitize($account['email']) ?>" required></div>
        <div class="field field-span-2"><label>Phone</label><input type="text" name="phone_number" value="<?= sanitize($account['phone_number']) ?>"></div>
      </div>
      <button type="submit" class="btn btn-primary" style="margin-top:6px;">Save Changes</button>
    </form>
  </div>

  <div class="chart-card">
    <h3>Change Password</h3>
    <p class="subtitle" style="margin-bottom:14px;">Requires your current password. Forgot it instead? <a href="logout.php">Sign out</a> and use "Forgot Password" on the login page.</p>
    <form method="post" action="profile.php">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="change_password">
      <div class="field"><label>Current Password</label><input type="password" name="current_password" required></div>
      <div class="field"><label>New Password</label><input type="password" name="new_password" minlength="8" required></div>
      <div class="field"><label>Confirm New Password</label><input type="password" name="confirm_password" minlength="8" required></div>
      <button type="submit" class="btn btn-primary" style="margin-top:6px;">Update Password</button>
    </form>
  </div>
</div>

<?php if ($user['role'] === 'sommelier'): ?>
  <p class="subtitle">Looking to update your certifications? Visit your <a href="sommelier_detail.php?id=<?= (int) $user['profile_id'] ?>">sommelier profile page</a>.</p>
<?php endif; ?>

<?php include __DIR__ . '/includes/footer.php'; ?>
