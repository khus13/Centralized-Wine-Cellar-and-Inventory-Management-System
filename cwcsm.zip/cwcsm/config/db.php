<?php
/**
 * CWCSM - Database Connection
 * Centralized Wine Cellar and Sommelier Management System
 *
 * Edit the constants below to match your local XAMPP / MySQL setup.
 * If MySQL is not listening on the default 3306 (e.g. XAMPP conflicts
 * with another MySQL install often land on 3307), change DB_PORT.
 */

define('DB_HOST', '127.0.0.1');
define('DB_PORT', '3307');          // change to 3307 etc. if your MySQL uses a different port
define('DB_NAME', 'wine_cellar_management');
define('DB_USER', 'root');
define('DB_PASS', '');

function getDB(): PDO
{
    static $pdo = null;

    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=utf8mb4';
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];

        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            http_response_code(500);
            die('Database connection failed: ' . htmlspecialchars($e->getMessage()));
        }
    }

    return $pdo;
}
