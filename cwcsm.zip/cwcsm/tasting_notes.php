<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_login();

require_once __DIR__ . '/controllers/tasting_notes_controller.php';

$pageTitle = 'Tasting Notes';
$showArchived = isset($_GET['archived']) && (is_admin() || is_sommelier());
$allNotes = $showArchived ? TastingNote::trashed() : TastingNote::all();
[$notes, $pageMeta] = paginate($allNotes, 9);
$bottles = Inventory::all();
$sommeliers = is_admin() ? Sommelier::all() : [];
$user = current_user();
$canCreate = (is_admin() || is_sommelier()) && !$showArchived;
$missingDeps = $canCreate && !$bottles;

include __DIR__ . '/includes/header.php';
?>
<div class="page-header">
  <div>
    <h1>Tasting Notes<?= $showArchived ? ' — Archived' : '' ?></h1>
    <p class="subtitle"><?= count($allNotes) ?> note<?= count($allNotes) === 1 ? '' : 's' ?> <?= $showArchived ? 'archived' : 'recorded across the cellar' ?></p>
  </div>
  <div style="display:flex;gap:10px;">
    <?php if (is_admin() || is_sommelier()): ?>
      <a class="btn btn-outline btn-sm" href="tasting_notes.php<?= $showArchived ? '' : '?archived=1' ?>"><?= icon('archive') ?> <?= $showArchived ? 'Back to Active' : 'View Archived' ?></a>
    <?php endif; ?>
    <?php if ($canCreate): ?>
      <button class="btn btn-primary" <?= $missingDeps ? 'disabled' : '' ?> data-open-modal="addNoteModal"><?= icon('plus') ?> New Tasting Note</button>
    <?php endif; ?>
  </div>
</div>

<?php if ($missingDeps): ?>
  <div class="flash flash-info" style="margin-bottom:18px;">Add a bottle to the <a href="wine_cellar.php">Wine Cellar</a> before recording tasting notes.</div>
<?php endif; ?>

<div class="toolbar">
  <div class="filter-bar">
    <input type="text" placeholder="Search wine or sommelier..." data-filter-input=".filterable-row" style="width:280px;">
  </div>
  <div class="view-toggle">
    <button type="button" class="active" data-view="grid"><?= icon('grid') ?> Grid</button>
    <button type="button" data-view="table"><?= icon('list') ?> Table</button>
  </div>
</div>

<?php if (!$notes): ?>
  <div class="empty-state card"><div class="icon"><?= icon('notes') ?></div><p><?= $showArchived ? 'No archived tasting notes.' : 'No tasting notes yet.' ?></p></div>
<?php else: ?>
<div class="entity-grid" id="gridView">
  <?php foreach ($notes as $n):
    $isOwner = is_sommelier() && (int) $user['profile_id'] === (int) $n['sommelier_id'];
    $canEditThis = (is_admin() || $isOwner) && !$showArchived;
    $canRestoreThis = (is_admin() || $isOwner) && $showArchived;
  ?>
    <div class="entity-card filterable-row" data-filter-text="<?= sanitize($n['vineyard_name'] . ' ' . $n['varietal_name'] . ' ' . $n['sommelier_first_name'] . ' ' . $n['sommelier_last_name']) ?>" style="min-height:auto;">
      <div class="body">
        <h4><?= sanitize($n['vineyard_name'] . ' ' . $n['varietal_name']) ?> <span style="color:#5c4d4f;font-weight:400;">'<?= sanitize($n['vintage_year']) ?></span></h4>
        <p style="font-size:12.5px;color:#5c4d4f;margin:2px 0 10px;">by <?= sanitize($n['sommelier_first_name'] . ' ' . $n['sommelier_last_name']) ?> &middot; <?= format_date($n['tasting_date']) ?></p>
        <p style="font-size:13px;"><strong>Aroma:</strong> <?= sanitize($n['aroma_notes']) ?></p>
        <p style="font-size:13px;"><strong>Flavor:</strong> <?= sanitize($n['flavor_notes']) ?></p>
        <?php if (!empty($n['remarks'])): ?>
          <p style="font-size:13px;"><strong>Remarks:</strong> <?= sanitize($n['remarks']) ?></p>
        <?php endif; ?>
        <div class="meta-row" style="margin-top:10px;">
          <span>Body <?= star_rating((int) $n['body_rating']) ?></span>
        </div>
        <div class="meta-row"><span>Acidity <?= star_rating((int) $n['acidity_rating']) ?></span></div>
        <div class="meta-row"><span>Tannin <?= star_rating((int) $n['tannin_rating']) ?></span></div>
        <p style="font-size:12px;color:#5c4d4f;margin-top:8px;">Peak drinking: <?= (int) $n['peak_drinking_start_year'] ?>–<?= (int) $n['peak_drinking_end_year'] ?></p>
      </div>
      <?php if ($canEditThis): ?>
      <div class="footer-actions">
        <button class="btn btn-outline btn-sm" data-open-modal="editNote<?= $n['note_id'] ?>"><?= icon('edit') ?> Edit</button>
        <form method="post" action="tasting_notes.php" data-confirm="Archive this tasting note?" style="display:inline;">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="delete">
          <input type="hidden" name="note_id" value="<?= $n['note_id'] ?>">
          <button type="submit" class="btn btn-danger btn-sm"><?= icon('archive') ?> Archive</button>
        </form>
      </div>
      <?php elseif ($canRestoreThis): ?>
      <div class="footer-actions">
        <form method="post" action="tasting_notes.php" style="display:inline;">
          <?= csrf_field() ?><input type="hidden" name="action" value="restore"><input type="hidden" name="note_id" value="<?= $n['note_id'] ?>">
          <button type="submit" class="btn btn-outline btn-sm"><?= icon('restore') ?> Restore</button>
        </form>
      </div>
      <?php endif; ?>
    </div>
  <?php endforeach; ?>
</div>

<div class="table-wrap" id="tableView" style="display:none;">
  <table>
    <thead><tr><th>Wine</th><th>Sommelier</th><th>Date</th><th>Body</th><th>Acidity</th><th>Tannin</th><th></th></tr></thead>
    <tbody>
      <?php foreach ($notes as $n):
        $isOwner = is_sommelier() && (int) $user['profile_id'] === (int) $n['sommelier_id'];
        $canEditThis = (is_admin() || $isOwner) && !$showArchived;
      ?>
      <tr class="filterable-row" data-filter-text="<?= sanitize($n['vineyard_name'] . ' ' . $n['varietal_name'] . ' ' . $n['sommelier_first_name'] . ' ' . $n['sommelier_last_name']) ?>">
        <td><?= sanitize($n['vineyard_name'] . ' ' . $n['varietal_name'] . ' (' . $n['vintage_year'] . ')') ?></td>
        <td><?= sanitize($n['sommelier_first_name'] . ' ' . $n['sommelier_last_name']) ?></td>
        <td><?= format_date($n['tasting_date']) ?></td>
        <td><?= star_rating((int) $n['body_rating']) ?></td>
        <td><?= star_rating((int) $n['acidity_rating']) ?></td>
        <td><?= star_rating((int) $n['tannin_rating']) ?></td>
        <td class="table-actions"><?php if ($canEditThis): ?><button class="btn btn-outline btn-sm" data-open-modal="editNote<?= $n['note_id'] ?>">Edit</button><?php endif; ?></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

<?= render_pagination($pageMeta) ?>

<?php foreach ($notes as $n):
  $isOwner = is_sommelier() && (int) $user['profile_id'] === (int) $n['sommelier_id'];
  if ($showArchived || (!is_admin() && !$isOwner)) continue;
?>
<div class="modal-overlay" id="editNote<?= $n['note_id'] ?>">
  <div class="modal modal-lg">
    <div class="modal-header"><h3>Edit Tasting Note</h3><button class="modal-close" data-close-modal>&times;</button></div>
    <form method="post" action="tasting_notes.php">
      <div class="modal-body">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="update">
        <input type="hidden" name="note_id" value="<?= $n['note_id'] ?>">
        <div class="form-grid">
          <div class="field"><label>Wine (Bottle)</label>
            <select name="bottle_id" required>
              <?php foreach ($bottles as $b): ?>
                <option value="<?= $b['bottle_id'] ?>" <?= $b['bottle_id'] == $n['bottle_id'] ? 'selected' : '' ?>><?= sanitize($b['vineyard_name'] . ' ' . $b['varietal_name'] . ' (' . $b['vintage_year'] . ') — Bin ' . $b['storage_bin_number']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="field"><label>Tasting Date <?= req() ?></label><input type="date" name="tasting_date" value="<?= sanitize($n['tasting_date']) ?>" required></div>
          <div class="field field-span-2"><label>Aroma Notes <?= req() ?></label><textarea name="aroma_notes" rows="2" required><?= sanitize($n['aroma_notes']) ?></textarea></div>
          <div class="field field-span-2"><label>Flavor Notes <?= req() ?></label><textarea name="flavor_notes" rows="2" required><?= sanitize($n['flavor_notes']) ?></textarea></div>
          <div class="field field-span-2"><label>Remarks</label><textarea name="remarks" rows="2" placeholder="The reasoning behind your review — why you scored it this way"><?= sanitize($n['remarks'] ?? '') ?></textarea></div>
          <div class="field"><label>Body Rating (1–5) <?= req() ?></label><input type="number" name="body_rating" min="1" max="5" value="<?= (int) $n['body_rating'] ?>" required></div>
          <div class="field"><label>Acidity Rating (1–5) <?= req() ?></label><input type="number" name="acidity_rating" min="1" max="5" value="<?= (int) $n['acidity_rating'] ?>" required></div>
          <div class="field"><label>Tannin Rating (1–5) <?= req() ?></label><input type="number" name="tannin_rating" min="1" max="5" value="<?= (int) $n['tannin_rating'] ?>" required></div>
          <div class="field"><label>Peak Start Year <?= req() ?></label><input type="number" name="peak_drinking_start_year" value="<?= (int) $n['peak_drinking_start_year'] ?>" required></div>
          <div class="field"><label>Peak End Year <?= req() ?></label><input type="number" name="peak_drinking_end_year" value="<?= (int) $n['peak_drinking_end_year'] ?>" required></div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline" data-close-modal>Cancel</button>
        <button type="submit" class="btn btn-primary">Save Changes</button>
      </div>
    </form>
  </div>
</div>
<?php endforeach; ?>

<?php endif; ?>

<?php if ($canCreate && !$missingDeps): ?>
<div class="modal-overlay" id="addNoteModal">
  <div class="modal modal-lg">
    <div class="modal-header"><h3>New Tasting Note</h3><button class="modal-close" data-close-modal>&times;</button></div>
    <form method="post" action="tasting_notes.php">
      <div class="modal-body">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="create">
        <div class="form-grid">
          <div class="field field-span-2"><label>Wine (Bottle) <?= req() ?></label>
            <select name="bottle_id" required>
              <option value="" disabled selected>Select a bottle</option>
              <?php foreach ($bottles as $b): ?>
                <option value="<?= $b['bottle_id'] ?>"><?= sanitize($b['vineyard_name'] . ' ' . $b['varietal_name'] . ' (' . $b['vintage_year'] . ') — Bin ' . $b['storage_bin_number']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <?php if (is_admin()): ?>
          <div class="field field-span-2"><label>Sommelier <?= req() ?></label>
            <select name="sommelier_id" required>
              <option value="" disabled selected>Select sommelier</option>
              <?php foreach ($sommeliers as $s): ?><option value="<?= $s['sommelier_id'] ?>"><?= sanitize($s['first_name'] . ' ' . $s['last_name']) ?></option><?php endforeach; ?>
            </select>
          </div>
          <?php endif; ?>
          <div class="field"><label>Tasting Date <?= req() ?></label><input type="date" name="tasting_date" value="<?= date('Y-m-d') ?>" required></div>
          <div class="field field-span-2"><label>Aroma Notes <?= req() ?></label><textarea name="aroma_notes" rows="2" required placeholder="e.g. Blackcurrant, cedar, a touch of vanilla"></textarea></div>
          <div class="field field-span-2"><label>Flavor Notes <?= req() ?></label><textarea name="flavor_notes" rows="2" required placeholder="e.g. Ripe dark fruit with firm structure"></textarea></div>
          <div class="field field-span-2"><label>Remarks</label><textarea name="remarks" rows="2" placeholder="Your reasoning behind this review"></textarea></div>
          <div class="field"><label>Body Rating (1–5) <?= req() ?></label><input type="number" name="body_rating" min="1" max="5" value="3" required></div>
          <div class="field"><label>Acidity Rating (1–5) <?= req() ?></label><input type="number" name="acidity_rating" min="1" max="5" value="3" required></div>
          <div class="field"><label>Tannin Rating (1–5) <?= req() ?></label><input type="number" name="tannin_rating" min="1" max="5" value="3" required></div>
          <div class="field"><label>Peak Start Year <?= req() ?></label><input type="number" name="peak_drinking_start_year" value="<?= date('Y') ?>" required></div>
          <div class="field"><label>Peak End Year <?= req() ?></label><input type="number" name="peak_drinking_end_year" value="<?= date('Y') + 5 ?>" required></div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline" data-close-modal>Cancel</button>
        <button type="submit" class="btn btn-primary">Save Note</button>
      </div>
    </form>
  </div>
</div>
<?php endif; ?>

<?php include __DIR__ . '/includes/footer.php'; ?>
